package com.docera.parwez

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After a reboot, start the blocker again if any block is still running. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try { if (BackTapService.isOn(context)) BackTapService.start(context) } catch (_: Throwable) {}
        try {
            if (BlockStore.active(context).isEmpty()) return
            if (BlockGuardService.ready(context)) BlockGuardService.start(context)
            BlockStore.tryEnableService(context)
        } catch (_: Throwable) {
        }
    }
}
