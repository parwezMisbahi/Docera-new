package com.docera.parwez

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * App blocker.
 *
 * How it works (does NOT rely on "Home" alone, because floating / split windows ignore it):
 *  1. Looks at which app windows are on screen (package name + position only, no content read).
 *  2. EVERY window that belongs to a blocked app gets its own solid "Blocked by Docera" cover drawn
 *     exactly over THAT window (full-screen app -> whole screen, split-screen half / floating window
 *     -> only that window). So 2 split-screen + 2 floating apps (4 at once) are all covered.
 *     The cover swallows every touch, so the blocked app cannot be used.
 *  3. A full-screen blocked app is also sent to the home screen.
 *  4. The cover disappears by itself when the window is gone or the block time is over.
 *
 * Docera itself, Settings, Phone, the launcher and the keyboard are never covered, so Docera is
 * unaffected and stays open and usable (also next to a floating blocked window).
 */
class AppBlockService : AccessibilityService() {

    companion object {
        /** True while Android has this service bound and running. */
        @Volatile
        var connected: Boolean = false

        @Volatile
        private var instance: AppBlockService? = null
        private var lastShot = 0L

        /** Back Tap outside Docera: screenshot the screen (Accessibility), then open Docera with the note box. */
        fun captureAndOpenDocera(ctx: android.content.Context) {
            val svc = instance
            val now = SystemClock.elapsedRealtime()
            if (now - lastShot < 1500) return
            lastShot = now
            if (svc == null || android.os.Build.VERSION.SDK_INT < 30) {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(ctx, "Back Tap in other apps: turn on Docera App Blocker in Accessibility settings", Toast.LENGTH_LONG).show()
                }
                return
            }
            svc.shoot(ctx.applicationContext)
        }

        private const val POLL_MS = 400L
        private const val PROTECTED_TTL_MS = 60_000L
    }

    private data class Hit(val id: Int, val pkg: String, val remMs: Long, val rect: Rect)

    /** One cover per blocked window (key = accessibility window id). */
    private class Cover(val view: View, val time: TextView, val em: Button, val pkg: String) {
        var armedAt = 0L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val covers = HashMap<Int, Cover>()
    private var lastToast = 0L
    private var lastHome = 0L

    private var protectedCache: Set<String> = emptySet()
    private var protectedAt = 0L

    private val evalRunnable = Runnable { evaluate() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        instance = null
        handler.removeCallbacksAndMessages(null)
        removeAllCovers()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        instance = null
        handler.removeCallbacksAndMessages(null)
        removeAllCovers()
        super.onDestroy()
    }

    private fun protectedSet(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (protectedCache.isEmpty() || now - protectedAt > PROTECTED_TTL_MS) {
            protectedCache = BlockStore.protectedPackages(this)
            protectedAt = now
        }
        return protectedCache
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Never let an exception escape: a crash here would take Docera's process down with it.
        try {
            if (event == null) return
            val t = event.eventType
            if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                t != AccessibilityEvent.TYPE_WINDOWS_CHANGED
            ) return
            handler.removeCallbacks(evalRunnable)
            handler.postDelayed(evalRunnable, 60L)
        } catch (_: Throwable) {
        }
    }

    /** ALL on-screen app windows that belong to a blocked app (split-screen + floating). */
    private fun findBlockedWindows(): List<Hit> {
        val list = try {
            windows
        } catch (_: Throwable) {
            null
        } ?: return emptyList()
        val prot = protectedSet()
        val res = ArrayList<Hit>()
        for (w in list) {
            try {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val root = w.root ?: continue
                val p = root.packageName?.toString()
                try {
                    root.recycle()
                } catch (_: Throwable) {
                }
                if (p == null || p == packageName || p in prot) continue
                val rem = BlockStore.blockedRemaining(this, p)
                if (rem <= 0L) continue
                val r = Rect()
                w.getBoundsInScreen(r)
                if (r.width() <= 0 || r.height() <= 0) continue
                res.add(Hit(w.id, p, rem, r))
            } catch (_: Throwable) {
            }
        }
        return res
    }

    private fun evaluate() {
        try {
            val hits = findBlockedWindows()

            // Drop covers whose window is gone / no longer blocked.
            val liveIds = hits.map { it.id }.toSet()
            for (id in covers.keys.toList()) {
                if (id !in liveIds) removeCover(id)
            }

            var anyCreated = false
            var toastRem = 0L
            var fullScreenNew = false
            for (hit in hits) {
                try {
                    val created = showOrUpdateCover(hit)
                    if (created) {
                        anyCreated = true
                        toastRem = hit.remMs
                        if (isFullScreen(hit.rect)) fullScreenNew = true
                    }
                } catch (_: Throwable) {
                }
            }

            if (anyCreated) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastToast > 2500L) {
                    lastToast = now
                    Toast.makeText(
                        this,
                        "Blocked by Docera · ${BlockStore.format(toastRem)} left",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                if (fullScreenNew) goHome()
            }
        } catch (_: Throwable) {
        } finally {
            // Keep checking while any cover is up (windows may move / close / time may end).
            handler.removeCallbacks(evalRunnable)
            if (covers.isNotEmpty() || BlockStore.anyPass(this)) handler.postDelayed(evalRunnable, POLL_MS)
        }
    }

    private fun isFullScreen(r: Rect): Boolean {
        val dm = resources.displayMetrics
        return r.width() >= dm.widthPixels * 0.9f && r.height() >= dm.heightPixels * 0.8f
    }

    private fun goHome() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastHome < 500L) return
        lastHome = now
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun buildCover(pkg: String): Cover {
        val dp = resources.displayMetrics.density
        val title = TextView(this).apply {
            text = "Blocked by Docera"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
        }
        val time = TextView(this).apply {
            setTextColor(0xFFD4A857.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, (8 * dp).toInt(), 0, (16 * dp).toInt())
        }
        val btn = Button(this).apply {
            text = "Go home"
            setOnClickListener { performGlobalAction(GLOBAL_ACTION_HOME) }
        }
        val em = Button(this).apply {
            text = "Emergency open"
            setOnClickListener { onEmergencyTap(pkg) }
        }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF111111.toInt())
            isClickable = true
            setPadding((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt())
            addView(title)
            addView(time)
            addView(btn)
            addView(em)
        }
        return Cover(v, time, em, pkg)
    }

    /** Draws or moves the cover of one window. Returns true if a NEW cover was created. */
    private fun showOrUpdateCover(hit: Hit): Boolean {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            hit.rect.width(),
            hit.rect.height(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = hit.rect.left
        lp.y = hit.rect.top

        val existing = covers[hit.id]
        val created: Boolean
        val c: Cover
        if (existing == null) {
            c = buildCover(hit.pkg)
            wm.addView(c.view, lp)
            covers[hit.id] = c
            created = true
        } else {
            c = existing
            wm.updateViewLayout(c.view, lp)
            created = false
        }
        c.time.text = "${BlockStore.format(hit.remMs)} left"
        updateEmergencyButton(c)
        return created
    }

    private fun updateEmergencyButton(c: Cover) {
        val left = BlockStore.emergencyLeft(this, c.pkg)
        val mins = BlockStore.emergencyMinutes(this, c.pkg)
        val armed = c.armedAt != 0L && SystemClock.elapsedRealtime() - c.armedAt < 4000L
        if (!armed) c.armedAt = 0L
        if (left <= 0) {
            c.em.text = "No emergency opens left"
            c.em.isEnabled = false
        } else {
            c.em.isEnabled = true
            c.em.text = if (armed) "Tap again to open for $mins min" else "Emergency open · $mins min ($left left)"
        }
    }

    /** Two taps (within 4 s) so it can not happen by accident: the app opens for the pass length, the block keeps running. */
    private fun onEmergencyTap(pkg: String) {
        try {
            val c = covers.values.firstOrNull { it.pkg == pkg } ?: return
            val now = SystemClock.elapsedRealtime()
            if (c.armedAt == 0L || now - c.armedAt >= 4000L) {
                c.armedAt = now
                updateEmergencyButton(c)
                return
            }
            c.armedAt = 0L
            val r = BlockStore.useEmergency(this, pkg)
            if (r == "ok") {
                Toast.makeText(
                    this,
                    "Emergency: open for ${BlockStore.emergencyMinutes(this, pkg)} min · ${BlockStore.emergencyLeft(this, pkg)} left",
                    Toast.LENGTH_LONG
                ).show()
                handler.removeCallbacks(evalRunnable)
                handler.post(evalRunnable)
            } else {
                updateEmergencyButton(c)
            }
        } catch (_: Throwable) {
        }
    }

    private fun removeCover(id: Int) {
        val c = covers.remove(id) ?: return
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(c.view)
        } catch (_: Throwable) {
        }
    }

    private fun removeAllCovers() {
        for (id in covers.keys.toList()) removeCover(id)
    }

    @android.annotation.SuppressLint("NewApi")
    private fun shoot(app: android.content.Context) {
        try {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY, app.mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(r: ScreenshotResult) {
                        Thread {
                            try {
                                val hw = android.graphics.Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                                val bmp = hw?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                r.hardwareBuffer.close()
                                if (bmp == null) throw IllegalStateException()
                                val f = java.io.File(app.filesDir, "bt_pending.jpg")
                                f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }
                                handler.post { openDocera(app) }
                            } catch (_: Throwable) {
                                handler.post { Toast.makeText(app, "Could not take the screenshot", Toast.LENGTH_SHORT).show() }
                            }
                        }.start()
                    }
                    override fun onFailure(code: Int) {
                        Toast.makeText(app, "Could not take the screenshot here", Toast.LENGTH_SHORT).show()
                    }
                })
        } catch (_: Throwable) {
            Toast.makeText(app, "Could not take the screenshot", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openDocera(app: android.content.Context) {
        try {
            val i = Intent(app, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                .putExtra("bt_shot", true)
            app.startActivity(i)
        } catch (_: Throwable) {
        }
    }

    override fun onInterrupt() {}
}
