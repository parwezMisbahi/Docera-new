package com.docera.parwez

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.max

/**
 * "Back double-tap" detector (like Pixel Quick Tap / MIUI Back Tap).
 * Android has no public API for it, so this listens to the accelerometer while Docera is on screen:
 * a tap on the back of the phone is a short, sharp jolt along the screen's normal (z) axis.
 * Two such jolts 120-450 ms apart, on an otherwise quiet phone, call [onDoubleTap].
 */
class BackTapDetector(ctx: Context, private val onDoubleTap: () -> Unit) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var running = false
    private var threshold = 4.0f

    // slow (gravity) estimate per axis, high-pass = value - slow
    private var gx = 0f; private var gy = 0f; private var gz = 0f
    private var primed = false
    private var energy = 0f            // smoothed |high-pass| of all axes: "is the phone being moved?"
    private var firstAt = 0L
    private var lastSpike = 0L
    private var cooldownUntil = 0L

    val available: Boolean get() = acc != null

    /** sens: 0 = low (needs a firmer tap), 1 = normal, 2 = high (light tap) */
    fun start(sens: Int) {
        threshold = when (sens) { 0 -> 4.6f; 2 -> 2.0f; else -> 3.0f }
        if (running || acc == null) return
        primed = false; energy = 0f; firstAt = 0L; lastSpike = 0L
        running = try { sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_FASTEST) } catch (_: Throwable) { false }   // ~100 Hz
    }

    fun stop() {
        if (!running) return
        try { sm.unregisterListener(this) } catch (_: Throwable) {}
        running = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
        if (!primed) { gx = x; gy = y; gz = z; primed = true; return }
        gx = 0.9f * gx + 0.1f * x; gy = 0.9f * gy + 0.1f * y; gz = 0.9f * gz + 0.1f * z
        val hx = x - gx; val hy = y - gy; val hz = z - gz
        val now = e.timestamp / 1_000_000L                      // ms
        val side = max(abs(hx), abs(hy))
        // quiet-phone check uses the energy BEFORE this sample
        val quiet = energy < 2.2f
        energy = 0.97f * energy + 0.03f * (abs(hx) + abs(hy) + abs(hz))

        if (now < cooldownUntil) return
        val spike = abs(hz) > threshold && abs(hz) > 1.25f * side
        if (!spike || now - lastSpike < 60) return               // same jolt still ringing
        lastSpike = now

        if (firstAt != 0L && now - firstAt in 90..650) {
            firstAt = 0L
            cooldownUntil = now + 1500
            onDoubleTap()
        } else if (quiet) {
            firstAt = now                                        // possible first tap
        } else {
            firstAt = 0L
        }
    }
}


/**
 * Keeps Back Tap alive everywhere (home screen, other apps): a small foreground service that listens
 * to the accelerometer while the screen is on. Docera open -> the in-app flow; any other app -> the
 * Accessibility service takes the screenshot and Docera opens with the note box.
 */
class BackTapService : android.app.Service() {
    companion object {
        @Volatile var running = false
        private const val CHANNEL = "docera_backtap"
        private const val NOTIF_ID = 4102
        private const val PREFS = "docera_backtap"

        fun saveConfig(ctx: Context, on: Boolean, sens: Int) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("on", on).putInt("sens", sens).apply()
        }
        fun isOn(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("on", false)
        fun sens(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("sens", 1)

        fun start(ctx: Context) {
            try {
                val i = android.content.Intent(ctx, BackTapService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) {}
        }
        fun stop(ctx: Context) {
            try { ctx.stopService(android.content.Intent(ctx, BackTapService::class.java)) } catch (_: Throwable) {}
        }
    }

    private var det: BackTapDetector? = null
    private var screenRx: android.content.BroadcastReceiver? = null

    override fun onBind(intent: android.content.Intent?): android.os.IBinder? = null

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        showForeground()
        if (!isOn(this)) { stopSelf(); return START_NOT_STICKY }
        running = true
        val d = det ?: BackTapDetector(this) { onTap() }.also { det = it }
        d.stop()
        val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        if (pm.isInteractive) d.start(sens(this))
        if (screenRx == null) {
            screenRx = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context, i: android.content.Intent) {
                    if (i.action == android.content.Intent.ACTION_SCREEN_ON) det?.start(sens(c)) else det?.stop()
                }
            }
            val f = android.content.IntentFilter().apply {
                addAction(android.content.Intent.ACTION_SCREEN_ON); addAction(android.content.Intent.ACTION_SCREEN_OFF)
            }
            registerReceiver(screenRx, f)
        }
        return START_STICKY
    }

    private fun onTap() {
        val act = MainActivity.front
        if (act != null) {
            act.runOnUiThread { act.fireBackTap() }
        } else {
            AppBlockService.captureAndOpenDocera(this)
        }
    }

    override fun onDestroy() {
        running = false
        try { det?.stop() } catch (_: Throwable) {}
        try { screenRx?.let { unregisterReceiver(it) } } catch (_: Throwable) {}
        screenRx = null
        super.onDestroy()
    }

    private fun showForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(android.app.NotificationChannel(CHANNEL, "Back Tap", android.app.NotificationManager.IMPORTANCE_MIN))
        }
        val pi = android.app.PendingIntent.getActivity(
            this, 0, android.content.Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = androidx.core.app.NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Docera Back Tap is on")
            .setContentText("Double-tap the back of the phone to take a screenshot note.")
            .setOngoing(true)
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MIN)
            .setContentIntent(pi)
            .build()
        if (android.os.Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
