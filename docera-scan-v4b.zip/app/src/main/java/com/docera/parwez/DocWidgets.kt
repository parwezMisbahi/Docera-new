package com.docera.parwez

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

private fun widgetIntent(ctx: Context, action: String, code: Int): PendingIntent {
    val i = Intent(ctx, MainActivity::class.java)
        .setAction(Intent.ACTION_MAIN)
        .putExtra("wa", action)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

/** Opens Docera as a brand-new window: every tap adds one more Docera card in Recents (each can hold its own PDF). */
private fun newWindowIntent(ctx: Context, code: Int): PendingIntent {
    val i = Intent(ctx, MainActivity::class.java)
        .setAction(Intent.ACTION_MAIN)
        .addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT or
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK
        )
    return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

/** Home-screen widget with four shortcuts: new note, scan to PDF, new Docera window, continue reading. */
class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_quick)
            rv.setOnClickPendingIntent(R.id.wNote, widgetIntent(ctx, "note", 11))
            rv.setOnClickPendingIntent(R.id.wScan, widgetIntent(ctx, "scan", 12))
            rv.setOnClickPendingIntent(R.id.wTabs, newWindowIntent(ctx, 13))
            rv.setOnClickPendingIntent(R.id.wLast, widgetIntent(ctx, "last", 14))
            mgr.updateAppWidget(id, rv)
        }
    }
}

/** Home-screen widget that shows the PDF you were reading last; tap to continue. */
class ReadWidget : AppWidgetProvider() {
    companion object {
        private const val PREFS = "docera_widget"
        private var lastPush = 0L

        fun save(ctx: Context, name: String, page: Int, total: Int) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val changed = sp.getString("name", "") != name || sp.getInt("page", 0) != page
            if (!changed) return
            sp.edit().putString("name", name).putInt("page", page).putInt("total", total).apply()
            val now = System.currentTimeMillis()
            if (now - lastPush < 5000) return
            lastPush = now
            refresh(ctx)
        }

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ReadWidget::class.java))
            if (ids.isNotEmpty()) push(ctx, mgr, ids)
        }

        fun push(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val name = sp.getString("name", "") ?: ""
            val page = sp.getInt("page", 0)
            val total = sp.getInt("total", 0)
            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_read)
                if (name.isEmpty()) {
                    rv.setTextViewText(R.id.wrName, "No PDF read yet")
                    rv.setTextViewText(R.id.wrPage, "Open a PDF in Docera")
                } else {
                    rv.setTextViewText(R.id.wrName, name.removeSuffix(".pdf"))
                    rv.setTextViewText(R.id.wrPage, if (total > 0) "Page $page of $total" else "Page $page")
                }
                rv.setOnClickPendingIntent(R.id.wrRoot, widgetIntent(ctx, "last", 21))
                mgr.updateAppWidget(id, rv)
            }
        }
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = push(ctx, mgr, ids)
}

/** One-tap widget: each tap opens another Docera window (separate card in Recents) so many PDFs can stay open side by side. */
class WindowWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_window)
            rv.setOnClickPendingIntent(R.id.wwRoot, newWindowIntent(ctx, 31))
            mgr.updateAppWidget(id, rv)
        }
    }
}
