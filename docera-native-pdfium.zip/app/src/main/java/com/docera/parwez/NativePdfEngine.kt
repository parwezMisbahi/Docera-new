package com.docera.parwez

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Native PDF engine. Android's PdfRenderer is PDFium (the Chromium engine) under the hood, so PDFs are
 * rasterised natively: no JS worker, no file:// worker problems, much less memory than pdf.js.
 *
 * The WebView talks to it in two ways:
 *  - [PdfEngineBridge] (window.AndroidPdfEngine): small calls to stage + open a document.
 *  - https://docera.pdf/... requests, answered by [handle] from WebViewClient.shouldInterceptRequest:
 *        /size?k=KEY&p=PAGE     -> JSON [widthPt,heightPt]
 *        /sizes?k=KEY           -> JSON [[w,h],...] for every page
 *        /img?k=KEY&p=PAGE&w=PX -> JPEG of the page, PX pixels wide
 */
object NativePdfEngine {
    const val HOST = "docera.pdf"
    private const val MAX_OPEN = 3
    private const val MAX_PIXELS = 12_000_000L

    private class Doc(val key: String, val file: File, val pfd: ParcelFileDescriptor, val renderer: PdfRenderer) {
        val sizes = HashMap<Int, IntArray>()
        val lock = Any()
    }

    private class Pending(val file: File, val out: FileOutputStream)

    private val docs = LinkedHashMap<String, Doc>()      // access-ordered by hand (see touch())
    private val pending = HashMap<String, Pending>()
    private val global = Any()

    private fun dir(ctx: Context): File = File(ctx.cacheDir, "nativepdf").apply { mkdirs() }

    /** Called once at app start: removes files left over from a previous run. */
    fun cleanup(ctx: Context) {
        synchronized(global) {
            docs.values.forEach { closeDoc(it) }
            docs.clear()
            pending.values.forEach { try { it.out.close() } catch (_: Throwable) {} }
            pending.clear()
        }
        try { dir(ctx).listFiles()?.forEach { it.delete() } } catch (_: Throwable) {}
    }

    private fun safeName(key: String): String =
        Integer.toHexString(key.hashCode()) + "_" + key.length + ".pdf"

    fun has(key: String): Int = synchronized(global) {
        val d = docs[key] ?: return 0
        docs.remove(key); docs[key] = d            // touch: most recently used goes last
        d.renderer.pageCount
    }

    fun begin(ctx: Context, key: String): String = synchronized(global) {
        try {
            pending.remove(key)?.let { try { it.out.close() } catch (_: Throwable) {} }
            val f = File(dir(ctx), safeName(key))
            pending[key] = Pending(f, FileOutputStream(f, false))
            "ok"
        } catch (e: Throwable) {
            "ERR:" + (e.message ?: "begin failed")
        }
    }

    fun append(key: String, b64: String): String = synchronized(global) {
        try {
            val p = pending[key] ?: return "ERR:unknown"
            p.out.write(Base64.decode(b64, Base64.DEFAULT))
            "ok"
        } catch (e: Throwable) {
            "ERR:" + (e.message ?: "write failed")
        }
    }

    /** Opens the staged file. Returns the page count as text, or "ERR:...". */
    fun open(key: String): String = synchronized(global) {
        val p = pending.remove(key) ?: return "ERR:unknown"
        try {
            try { p.out.flush(); p.out.close() } catch (_: Throwable) {}
            docs.remove(key)?.let { closeDoc(it) }
            val pfd = ParcelFileDescriptor.open(p.file, ParcelFileDescriptor.MODE_READ_ONLY)
            val r = try {
                PdfRenderer(pfd)
            } catch (e: Throwable) {
                try { pfd.close() } catch (_: Throwable) {}
                throw e
            }
            docs[key] = Doc(key, p.file, pfd, r)
            while (docs.size > MAX_OPEN) {
                val oldest = docs.keys.first()
                docs.remove(oldest)?.let { closeDoc(it) }
            }
            r.pageCount.toString()
        } catch (e: Throwable) {
            try { p.file.delete() } catch (_: Throwable) {}
            "ERR:" + (e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
    }

    fun close(key: String) = synchronized(global) {
        docs.remove(key)?.let { closeDoc(it) }
        Unit
    }

    private fun closeDoc(d: Doc) {
        synchronized(d.lock) {
            try { d.renderer.close() } catch (_: Throwable) {}
            try { d.pfd.close() } catch (_: Throwable) {}
            try { d.file.delete() } catch (_: Throwable) {}
        }
    }

    private fun docOf(key: String): Doc? = synchronized(global) { docs[key] }

    private fun sizeOf(d: Doc, page: Int): IntArray = synchronized(d.lock) {
        d.sizes[page] ?: run {
            val pg = d.renderer.openPage(page - 1)
            try {
                val s = intArrayOf(pg.width, pg.height)
                d.sizes[page] = s
                s
            } finally {
                pg.close()
            }
        }
    }

    private fun renderJpeg(d: Doc, page: Int, widthPx: Int): ByteArray = synchronized(d.lock) {
        val pg = d.renderer.openPage(page - 1)
        try {
            val pw = pg.width.coerceAtLeast(1)
            val ph = pg.height.coerceAtLeast(1)
            d.sizes[page] = intArrayOf(pw, ph)
            var w = widthPx.coerceIn(16, 8000)
            var h = (w.toLong() * ph / pw).toInt().coerceAtLeast(1)
            if (w.toLong() * h > MAX_PIXELS) {
                val k = Math.sqrt(MAX_PIXELS.toDouble() / (w.toDouble() * h))
                w = (w * k).toInt().coerceAtLeast(16)
                h = (h * k).toInt().coerceAtLeast(1)
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            try {
                bmp.eraseColor(Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                val bos = ByteArrayOutputStream(w * h / 6)
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos)
                bos.toByteArray()
            } finally {
                bmp.recycle()
            }
        } finally {
            pg.close()
        }
    }

    private fun reply(mime: String, status: Int, body: ByteArray): WebResourceResponse {
        val headers = HashMap<String, String>()
        headers["Access-Control-Allow-Origin"] = "*"
        headers["Cache-Control"] = "no-store"
        return WebResourceResponse(
            mime, "utf-8", status, if (status == 200) "OK" else "Error", headers, ByteArrayInputStream(body)
        )
    }

    /** Answers one intercepted https://docera.pdf/... request. Runs on a WebView worker thread. */
    fun handle(u: Uri): WebResourceResponse {
        return try {
            val key = u.getQueryParameter("k") ?: return reply("text/plain", 400, "no key".toByteArray())
            val d = docOf(key) ?: return reply("text/plain", 404, "not open".toByteArray())
            when (u.path) {
                "/size" -> {
                    val p = (u.getQueryParameter("p") ?: "1").toInt().coerceIn(1, d.renderer.pageCount)
                    val s = sizeOf(d, p)
                    reply("application/json", 200, "[${s[0]},${s[1]}]".toByteArray())
                }
                "/sizes" -> {
                    val sb = StringBuilder("[")
                    for (i in 1..d.renderer.pageCount) {
                        val s = sizeOf(d, i)
                        if (i > 1) sb.append(',')
                        sb.append('[').append(s[0]).append(',').append(s[1]).append(']')
                    }
                    sb.append(']')
                    reply("application/json", 200, sb.toString().toByteArray())
                }
                "/img" -> {
                    val p = (u.getQueryParameter("p") ?: "1").toInt().coerceIn(1, d.renderer.pageCount)
                    val w = (u.getQueryParameter("w") ?: "800").toInt()
                    reply("image/jpeg", 200, renderJpeg(d, p, w))
                }
                else -> reply("text/plain", 404, "bad path".toByteArray())
            }
        } catch (e: Throwable) {
            reply("text/plain", 500, (e.message ?: e.javaClass.simpleName).toByteArray())
        }
    }
}

/** window.AndroidPdfEngine — see NativePdfEngine. */
class PdfEngineBridge(private val ctx: Context) {
    @JavascriptInterface
    fun has(key: String): Int = NativePdfEngine.has(key)

    @JavascriptInterface
    fun begin(key: String): String = NativePdfEngine.begin(ctx, key)

    @JavascriptInterface
    fun append(key: String, b64: String): String = NativePdfEngine.append(key, b64)

    @JavascriptInterface
    fun open(key: String): String = NativePdfEngine.open(key)

    @JavascriptInterface
    fun close(key: String) = NativePdfEngine.close(key)
}
