package com.docera.parwez

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.max

/**
 * "Back double-tap" detector (like Pixel Quick Tap / MIUI Back Tap).
 * Android has no public API for it, so this listens to the accelerometer while Docera is on screen:
 * a tap on the back of the phone is a short, sharp jolt along the screen's normal (z) axis.
 * Two such jolts 120-450 ms apart, on an otherwise quiet phone, call [onDoubleTap].
 */
class BackTapDetector(ctx: Context, private val onDoubleTap: () -> Unit) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var running = false
    private var threshold = 4.0f

    // slow (gravity) estimate per axis, high-pass = value - slow
    private var gx = 0f; private var gy = 0f; private var gz = 0f
    private var primed = false
    private var energy = 0f            // smoothed |high-pass| of all axes: "is the phone being moved?"
    private var firstAt = 0L
    private var lastSpike = 0L
    private var cooldownUntil = 0L

    val available: Boolean get() = acc != null

    /** sens: 0 = low (needs a firmer tap), 1 = normal, 2 = high (light tap) */
    fun start(sens: Int) {
        threshold = when (sens) { 0 -> 6.0f; 2 -> 2.8f; else -> 4.0f }
        if (running || acc == null) return
        primed = false; energy = 0f; firstAt = 0L; lastSpike = 0L
        running = try { sm.registerListener(this, acc, 10_000) } catch (_: Throwable) { false }   // ~100 Hz
    }

    fun stop() {
        if (!running) return
        try { sm.unregisterListener(this) } catch (_: Throwable) {}
        running = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
        if (!primed) { gx = x; gy = y; gz = z; primed = true; return }
        gx = 0.92f * gx + 0.08f * x; gy = 0.92f * gy + 0.08f * y; gz = 0.92f * gz + 0.08f * z
        val hx = x - gx; val hy = y - gy; val hz = z - gz
        val now = e.timestamp / 1_000_000L                      // ms
        val side = max(abs(hx), abs(hy))
        // quiet-phone check uses the energy BEFORE this sample
        val quiet = energy < 1.3f
        energy = 0.97f * energy + 0.03f * (abs(hx) + abs(hy) + abs(hz))

        if (now < cooldownUntil) return
        val spike = abs(hz) > threshold && abs(hz) > 1.6f * side
        if (!spike || now - lastSpike < 70) return               // same jolt still ringing
        lastSpike = now

        if (firstAt != 0L && now - firstAt in 120..450) {
            firstAt = 0L
            cooldownUntil = now + 1500
            onDoubleTap()
        } else if (quiet) {
            firstAt = now                                        // possible first tap
        } else {
            firstAt = 0L
        }
    }
}
