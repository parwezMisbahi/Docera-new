package com.docera.parwez

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * App blocker.
 *
 * How it works (does NOT rely on "Home" alone, because floating / split windows ignore it):
 *  1. Looks at which app windows are on screen (package name + position only, no content read).
 *  2. If one of them belongs to a blocked app, a solid "Blocked by Docera" cover is drawn exactly
 *     over THAT window (full-screen app -> whole screen, floating window -> only that window).
 *     The cover swallows every touch, so the blocked app cannot be used.
 *  3. A full-screen blocked app is also sent to the home screen.
 *  4. The cover disappears by itself when the window is gone or the block time is over.
 *
 * Docera itself, Settings, Phone, the launcher and the keyboard are never covered, so Docera is
 * unaffected and stays open and usable (also next to a floating blocked window).
 */
class AppBlockService : AccessibilityService() {

    companion object {
        /** True while Android has this service bound and running. */
        @Volatile
        var connected: Boolean = false

        private const val POLL_MS = 700L
        private const val PROTECTED_TTL_MS = 60_000L
    }

    private data class Hit(val pkg: String, val remMs: Long, val rect: Rect)

    private val handler = Handler(Looper.getMainLooper())
    private var cover: View? = null
    private var coverTime: TextView? = null
    private var lastToast = 0L
    private var lastHome = 0L

    private var protectedCache: Set<String> = emptySet()
    private var protectedAt = 0L

    private val evalRunnable = Runnable { evaluate() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        handler.removeCallbacksAndMessages(null)
        removeCover()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        handler.removeCallbacksAndMessages(null)
        removeCover()
        super.onDestroy()
    }

    private fun protectedSet(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (protectedCache.isEmpty() || now - protectedAt > PROTECTED_TTL_MS) {
            protectedCache = BlockStore.protectedPackages(this)
            protectedAt = now
        }
        return protectedCache
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Never let an exception escape: a crash here would take Docera's process down with it.
        try {
            if (event == null) return
            val t = event.eventType
            if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                t != AccessibilityEvent.TYPE_WINDOWS_CHANGED
            ) return
            handler.removeCallbacks(evalRunnable)
            handler.postDelayed(evalRunnable, 60L)
        } catch (_: Throwable) {
        }
    }

    /** First on-screen app window that belongs to a blocked app, or null. */
    private fun findBlockedWindow(): Hit? {
        val list = try {
            windows
        } catch (_: Throwable) {
            null
        } ?: return null
        val prot = protectedSet()
        for (w in list) {
            try {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val root = w.root ?: continue
                val p = root.packageName?.toString()
                try {
                    root.recycle()
                } catch (_: Throwable) {
                }
                if (p == null || p == packageName || p in prot) continue
                val rem = BlockStore.remainingFor(this, p)
                if (rem <= 0L) continue
                val r = Rect()
                w.getBoundsInScreen(r)
                if (r.width() <= 0 || r.height() <= 0) continue
                return Hit(p, rem, r)
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun evaluate() {
        try {
            val hit = findBlockedWindow()
            if (hit == null) {
                removeCover()
                return
            }
            val created = cover == null
            showOrUpdateCover(hit)

            if (created) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastToast > 2500L) {
                    lastToast = now
                    Toast.makeText(
                        this,
                        "Blocked by Docera · ${BlockStore.format(hit.remMs)} left",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                if (isFullScreen(hit.rect)) goHome()
            }
        } catch (_: Throwable) {
        } finally {
            // Keep checking while a cover is up (window may move / close / time may end).
            handler.removeCallbacks(evalRunnable)
            if (cover != null) handler.postDelayed(evalRunnable, POLL_MS)
        }
    }

    private fun isFullScreen(r: Rect): Boolean {
        val dm = resources.displayMetrics
        return r.width() >= dm.widthPixels * 0.9f && r.height() >= dm.heightPixels * 0.8f
    }

    private fun goHome() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastHome < 500L) return
        lastHome = now
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun buildCover(): View {
        val dp = resources.displayMetrics.density
        val title = TextView(this).apply {
            text = "Blocked by Docera"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
        }
        val time = TextView(this).apply {
            setTextColor(0xFFD4A857.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, (8 * dp).toInt(), 0, (16 * dp).toInt())
        }
        coverTime = time
        val btn = Button(this).apply {
            text = "Go home"
            setOnClickListener { performGlobalAction(GLOBAL_ACTION_HOME) }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF111111.toInt())
            isClickable = true
            setPadding((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt())
            addView(title)
            addView(time)
            addView(btn)
        }
    }

    private fun showOrUpdateCover(hit: Hit) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            hit.rect.width(),
            hit.rect.height(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = hit.rect.left
        lp.y = hit.rect.top

        val existing = cover
        if (existing == null) {
            val v = buildCover()
            wm.addView(v, lp)
            cover = v
        } else {
            wm.updateViewLayout(existing, lp)
        }
        coverTime?.text = "${BlockStore.format(hit.remMs)} left"
    }

    private fun removeCover() {
        val v = cover ?: return
        cover = null
        coverTime = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Throwable) {
        }
    }

    override fun onInterrupt() {}
}
