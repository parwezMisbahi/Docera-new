package com.docera.parwez

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Watches which app comes to the foreground. If that app is currently blocked, it is pushed away.
 * It only looks at the package/class name of the opening window; it does not read the screen.
 *
 * Docera-safe behaviour:
 *  - Only a REAL app screen (an Activity) can trigger a block. Pop-ups, floating chat heads,
 *    dialogs, keyboards or notifications from a blocked app used to look like "the app opened"
 *    and made the service kick the user (and Docera) to the home screen.
 *  - If the blocked app was opened while the user was inside Docera, Docera is brought back to
 *    the front instead of throwing the user to the home screen. Docera stays open.
 *  - Docera itself, Settings, phone, launcher etc. are never touched.
 */
class AppBlockService : AccessibilityService() {

    companion object {
        /** True while Android has this service bound and running. */
        @Volatile
        var connected: Boolean = false

        private const val ACTION_COOLDOWN_MS = 700L
        private const val PROTECTED_TTL_MS = 60_000L
    }

    private var lastToast = 0L
    private var lastAction = 0L

    /** Package of the last real app screen the user was on (before the current event). */
    private var lastForeground: String? = null

    private var protectedCache: Set<String> = emptySet()
    private var protectedAt = 0L
    private val activityCache = HashMap<String, Boolean>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        super.onDestroy()
    }

    private fun protectedSet(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (protectedCache.isEmpty() || now - protectedAt > PROTECTED_TTL_MS) {
            protectedCache = BlockStore.protectedPackages(this)
            protectedAt = now
        }
        return protectedCache
    }

    /** True only if [cls] is a real Activity of [pkg] (not a dialog, pop-up, IME or overlay window). */
    private fun isRealActivity(pkg: String, cls: String): Boolean {
        val key = "$pkg/$cls"
        activityCache[key]?.let { return it }
        val ok = try {
            packageManager.getActivityInfo(ComponentName(pkg, cls), 0)
            true
        } catch (_: android.content.pm.PackageManager.NameNotFoundException) {
            // Package/class not visible to us: fall back to a name check so blocking still works.
            cls.startsWith(pkg)
        } catch (_: Throwable) {
            false
        }
        if (activityCache.size > 500) activityCache.clear()
        activityCache[key] = ok
        return ok
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Never let an exception escape: a crash here would take Docera's process down with it.
        try {
            if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
            val pkg = event.packageName?.toString() ?: return
            val cls = event.className?.toString() ?: return

            // Docera's own screens: remember we are in Docera, never touch anything.
            if (pkg == packageName) {
                lastForeground = pkg
                return
            }

            // Pop-ups / dialogs / keyboards / floating windows are not "an app opening".
            if (!isRealActivity(pkg, cls)) return

            // Essential apps (phone, settings, launcher...) are never blocked.
            if (pkg in protectedSet()) {
                lastForeground = pkg
                return
            }

            val rem = BlockStore.remainingFor(this, pkg)
            if (rem <= 0L) {
                lastForeground = pkg
                return
            }

            // ---- pkg is blocked and its screen is really opening ----
            val cameFromDocera = lastForeground == packageName
            val now = SystemClock.elapsedRealtime()
            if (now - lastAction < ACTION_COOLDOWN_MS) return
            lastAction = now

            if (cameFromDocera) {
                // Keep Docera open: put it straight back on screen.
                var back = false
                try {
                    startActivity(
                        Intent(this, MainActivity::class.java).addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                        )
                    )
                    back = true
                } catch (_: Throwable) {
                }
                if (!back) performGlobalAction(GLOBAL_ACTION_HOME)
                lastForeground = packageName
            } else {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }

            if (now - lastToast > 2500L) {
                lastToast = now
                Toast.makeText(
                    this,
                    "Blocked by Docera · ${BlockStore.format(rem)} left",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } catch (_: Throwable) {
        }
    }

    override fun onInterrupt() {}
}
