package com.docera.parwez

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import android.provider.Settings
import org.json.JSONObject

/**
 * Stores which apps are blocked and until when. There is deliberately NO remove/unblock
 * function here: an entry only disappears when its time has run out.
 *
 * Time is measured with elapsedRealtime() while the phone has not rebooted, so changing the
 * system clock does not shorten a block. After a reboot it falls back to the wall clock.
 */
object BlockStore {
    private const val PREFS = "docera_blocker"
    private const val KEY = "blocks"
    const val MAX_MINUTES = 7 * 24 * 60

    data class Entry(
        val pkg: String,
        val durationMs: Long,
        val startElapsed: Long,
        val startWall: Long,
        val boot: Int
    )

    private fun bootCount(ctx: Context): Int = try {
        Settings.Global.getInt(ctx.contentResolver, "boot_count", -1)
    } catch (_: Exception) {
        -1
    }

    private fun read(ctx: Context): MutableMap<String, Entry> {
        val out = mutableMapOf<String, Entry>()
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return out
        try {
            val o = JSONObject(raw)
            for (k in o.keys()) {
                val j = o.getJSONObject(k)
                out[k] = Entry(k, j.getLong("d"), j.getLong("e"), j.getLong("w"), j.getInt("b"))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun write(ctx: Context, map: Map<String, Entry>) {
        val o = JSONObject()
        for ((k, v) in map) {
            o.put(
                k,
                JSONObject().put("d", v.durationMs).put("e", v.startElapsed)
                    .put("w", v.startWall).put("b", v.boot)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun remainingMs(ctx: Context, e: Entry): Long {
        val nowEl = SystemClock.elapsedRealtime()
        val boot = bootCount(ctx)
        val rem = if (boot != -1 && boot == e.boot && nowEl >= e.startElapsed) {
            e.durationMs - (nowEl - e.startElapsed)
        } else {
            e.startWall + e.durationMs - System.currentTimeMillis()
        }
        return rem.coerceAtMost(e.durationMs)
    }

    fun remainingFor(ctx: Context, pkg: String): Long {
        val e = read(ctx)[pkg] ?: return 0L
        return remainingMs(ctx, e).coerceAtLeast(0L)
    }

    /** Blocks that are still running (expired ones are cleaned out). */
    @Synchronized
    fun active(ctx: Context): List<Pair<Entry, Long>> {
        val map = read(ctx)
        val res = ArrayList<Pair<Entry, Long>>()
        var changed = false
        val it = map.entries.iterator()
        while (it.hasNext()) {
            val e = it.next().value
            val rem = remainingMs(ctx, e)
            if (rem <= 0L) {
                it.remove()
                changed = true
            } else {
                res.add(e to rem)
            }
        }
        if (changed) write(ctx, map)
        return res
    }

    /** Starts (or extends) a block. An existing longer block is never shortened. */
    @Synchronized
    fun add(ctx: Context, pkgs: Collection<String>, durationMs: Long) {
        val map = read(ctx)
        val nowEl = SystemClock.elapsedRealtime()
        val wall = System.currentTimeMillis()
        val boot = bootCount(ctx)
        for (p in pkgs) {
            val old = map[p]
            if (old != null && remainingMs(ctx, old) >= durationMs) continue
            map[p] = Entry(p, durationMs, nowEl, wall, boot)
        }
        write(ctx, map)
    }

    /** Apps that can never be blocked, so the phone always stays usable (calls, emergency, settings, home). */
    fun protectedPackages(ctx: Context): Set<String> {
        val s = mutableSetOf(
            ctx.packageName,
            "com.android.settings",
            "com.android.systemui",
            "com.android.phone",
            "com.android.server.telecom",
            "com.android.dialer",
            "com.google.android.dialer",
            "com.samsung.android.dialer",
            "com.samsung.android.incallui",
            "com.android.emergency",
            "com.google.android.apps.safetyhub"
        )
        val pm = ctx.packageManager
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.queryIntentActivities(home, 0).forEach { s.add(it.activityInfo.packageName) }
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) {
        }
        try {
            pm.resolveActivity(Intent(Intent.ACTION_DIAL), PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) {
        }
        return s
    }

    fun format(ms: Long): String {
        val totalMin = (ms + 59_999L) / 60_000L
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}
