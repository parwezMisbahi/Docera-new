package com.msam.notchcmd

import android.content.Intent
import android.content.pm.PackageManager
import java.util.Locale

/**
 * Short spoken/typed form -> the long command the parser already understands.
 *   "whatsapp pe mbfg ko assalamualaikum bhejo"        -> "whatsapp kholo aur search mbfg aur assalamualaikum bhejo"
 *   "whatsapp business par mbfg ko salam send karo"    -> "whatsapp business kholo aur search mbfg aur salam bhejo"
 *   "mbfg ko whatsapp pe assalamualaikum bhejdo"       -> same idea
 *   "mbfg ko assalamualaikum bhejo"                    -> uses the default (last used) app
 */
object ShortCmd {
    private const val VERB = "(?:bhej\\s*do|bhej\\s*de|bhejdo|bhejde|bhejiye|bhejo|bhej|send\\s*kar\\s*do|send\\s*karo|send\\s*kar|send|likh\\s*do|likho)"
    private val tailRe = Regex("^(.*?)\\s+$VERB$", RegexOption.IGNORE_CASE)
    private val koRe = Regex("\\s+ko\\s+", RegexOption.IGNORE_CASE)
    private val postRe = Regex("\\s+(?:pe|par|per|mein|me|men|se)\\s+", RegexOption.IGNORE_CASE)
    private val appPostRe = Regex("^(.+?)\\s+(?:pe|par|per|mein|me|men|se)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val longForm = Regex("\\b(search|kholo|khol|open|call|channel|post|research|translate|summarize|schedule)\\b", RegexOption.IGNORE_CASE)
    private val appWords = setOf("whatsapp", "business", "telegram", "messages", "message", "sms", "instagram", "insta", "messenger", "facebook", "signal", "wa", "watsapp", "whatsap")
    private val bad = setOf("open", "kholo", "khol", "search", "karo", "kar", "aur", "phir", "and", "then", "call", "usi", "usko", "unko", "isko", "inko", "wahi", "wohi", "pe", "par", "per", "mein", "me", "men", "se")

    fun build(app: String, name: String, msg: String) = "$app kholo aur search $name aur $msg bhejo"

    private var labelCache: List<String> = emptyList()
    private var labelAt = 0L

    /** is this phrase the name of an app installed on the phone? (strict: exact name, or the name contains every word) */
    fun installed(pm: PackageManager): (String) -> Boolean = { phrase ->
        val now = System.currentTimeMillis()
        if (now - labelAt > 60_000L || labelCache.isEmpty()) {
            labelCache = try {
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .map { it.loadLabel(pm).toString().lowercase(Locale.ROOT) }
            } catch (_: Exception) { emptyList() }
            labelAt = now
        }
        val q = phrase.trim().lowercase(Locale.ROOT)
        val toks = q.split(" ").filter { it.length >= 3 }
        q.length >= 3 && toks.isNotEmpty() && labelCache.any { n -> n == q || toks.all { n.contains(it) } }
    }

    private fun isApp(s: String, extra: ((String) -> Boolean)?): Boolean {
        val w = s.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (w.isEmpty() || w.size > 3) return false
        return w.all { it in appWords } || extra?.invoke(s) == true
    }

    /** null = not a short send command (leave the text as it is) */
    fun expand(raw: String, defApp: String = "whatsapp", appCheck: ((String) -> Boolean)? = null): String? {
        val s = raw.trim().trim('.', '!', '?', ',').replace(Regex("\\s+"), " ")
        if (s.isEmpty() || longForm.containsMatchIn(s)) return null
        val tail = tailRe.find(s) ?: return null
        val body = tail.groupValues[1].trim()
        val ko = koRe.find(body) ?: return null
        val left = body.substring(0, ko.range.first).trim()
        val right = body.substring(ko.range.last + 1).trim()
        var app: String? = null
        var name = left
        var msg = right
        val lp = postRe.find(left)
        if (lp != null && isApp(left.substring(0, lp.range.first), appCheck)) {
            app = left.substring(0, lp.range.first).trim()
            name = left.substring(lp.range.last + 1).trim()
        } else {
            val rp = appPostRe.find(right)
            if (rp != null && isApp(rp.groupValues[1], appCheck)) { app = rp.groupValues[1].trim(); msg = rp.groupValues[2].trim() }
        }
        val nw = name.split(" ").filter { it.isNotEmpty() }
        if (nw.isEmpty() || nw.size > 3 || nw.any { it.lowercase() in bad }) return null
        if (msg.isBlank()) return null
        return build(app ?: defApp, name, msg)
    }
}
