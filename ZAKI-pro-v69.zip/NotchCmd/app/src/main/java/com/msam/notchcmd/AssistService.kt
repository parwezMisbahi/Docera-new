package com.msam.notchcmd

import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService

/** Power button long-press -> system default assistant ko bulata hai -> yahan se panel khulta hai */
class AssistService : VoiceInteractionService()

class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = object : VoiceInteractionSession(this) {
        override fun onShow(args: Bundle?, showFlags: Int) {
            super.onShow(args, showFlags)
            try { startForegroundService(Intent(this@AssistSessionService, OverlayService::class.java).putExtra("show", true)) } catch (_: Exception) {}
            finish()   // koi system UI nahi, sirf apna panel
        }
    }
}

/** Assistant banne ke liye zaroori dummy; asli voice Google ke recognizer se hi chalti hai */
class AssistRecognitionService : RecognitionService() {
    override fun onStartListening(i: Intent?, cb: Callback?) { try { cb?.error(android.speech.SpeechRecognizer.ERROR_CLIENT) } catch (_: Exception) {} }
    override fun onCancel(cb: Callback?) {}
    override fun onStopListening(cb: Callback?) {}
}
