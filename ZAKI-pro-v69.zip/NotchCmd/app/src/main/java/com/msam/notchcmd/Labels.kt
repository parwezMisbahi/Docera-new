package com.msam.notchcmd

import android.content.Context

/**
 * Button names the automation looks for in Facebook / WhatsApp. Editable in Settings (L1), so when an app update
 * renames a button there is no new APK to build: change the comma separated list and run again.
 * Matching is lower-case; most lists match a whole name (or "name, more text"), a few match a part (see the notes).
 */
object Labels {
    val NOTES: LinkedHashMap<String, String> = linkedMapOf(
        "fb_composer" to "Facebook: the \"What's on your mind?\" box (part of the name)",
        "fb_next" to "Facebook: Next button on the New post screen",
        "fb_post" to "Facebook: Post button",
        "fb_share" to "Facebook: SHARE button on the Post settings screen",
        "fb_dismiss" to "Facebook: Not now / Skip buttons of popups",
        "fb_home_tab" to "Facebook: Home / Feed tab (starts with)",
        "fb_create" to "Facebook: top + Create button (part of the name)",
        "fb_menu_post" to "Facebook: Post option in the + menu",
        "fb_menu_tab" to "Facebook: Menu tab (starts with)",
        "fb_switcher" to "Facebook: profile switcher button on the Menu tab (part of the name)",
        "fb_share_target" to "Facebook: Feed option when a shared photo asks where to post",
        "wa_updates" to "WhatsApp: Updates / Status tab",
        "wa_forward" to "WhatsApp: Forward button under a channel post (part of the name)",
        "wa_my_status" to "WhatsApp: My status row on the Forward screen (starts with)",
        "wa_search" to "WhatsApp: Search button on the Send to / Forward screen (part of the name)",
        "gpt_stop" to "ChatGPT: Stop button while the image is being created (whole name)",
        "gpt_save" to "ChatGPT: Save / Download button on the full-screen image (whole name)",
        "gpt_close" to "ChatGPT: Close button of the full-screen image (whole name)"
    )

    val DEFAULTS: LinkedHashMap<String, String> = linkedMapOf(
        "fb_composer" to "what's on your mind, whats on your mind, on your mind, write something, create a post, create post, write a post, मन में क्या, सोच रहे, ذہن میں",
        "fb_next" to "next",
        "fb_post" to "post, पोस्ट, پوسٹ",
        "fb_share" to "share, share now, शेयर, شیئر",
        "fb_dismiss" to "not now, skip, maybe later, no thanks, remind me later, got it, dismiss, later, अभी नहीं, ابھی نہیں",
        "fb_home_tab" to "home, feed",
        "fb_create" to "create, new post",
        "fb_menu_post" to "post, create post, new post",
        "fb_menu_tab" to "menu",
        "fb_switcher" to "switch profile, switch account, profiles, accounts, switch",
        "fb_share_target" to "feed, news feed, share to feed",
        "wa_updates" to "updates, update, status, अपडेट, स्टेटस, اپ ڈیٹس, اپڈیٹس, اسٹیٹس, سٹیٹس",
        "wa_forward" to "forward",
        "wa_my_status" to "my status",
        "wa_search" to "search",
        "gpt_stop" to "stop, stop generating",
        "gpt_save" to "save, download, save image",
        "gpt_close" to "close"
    )

    private fun p(c: Context) = c.getSharedPreferences("labels", Context.MODE_PRIVATE)

    fun raw(c: Context, key: String): String = p(c).getString(key, null) ?: DEFAULTS[key] ?: ""
    fun isCustom(c: Context, key: String): Boolean = p(c).contains(key)
    fun set(c: Context, key: String, v: String) { p(c).edit().putString(key, v).apply() }
    fun reset(c: Context, key: String) { p(c).edit().remove(key).apply() }
    fun resetAll(c: Context) { p(c).edit().clear().apply() }

    /** lower-case names of one button */
    fun list(c: Context, key: String): List<String> =
        raw(c, key).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    // ---------- last failure dump (saved automatically when a post flow fails, copied from Settings L2) ----------
    fun saveDump(c: Context, tag: String, text: String) {
        val stamp = java.text.SimpleDateFormat("d MMM HH:mm:ss", java.util.Locale.ENGLISH).format(java.util.Date())
        p(c).edit().putString("_dump", "[" + tag + " failed " + stamp + "]\n" + text.take(24000)).apply()
    }
    fun lastDump(c: Context): String = p(c).getString("_dump", "") ?: ""
}
