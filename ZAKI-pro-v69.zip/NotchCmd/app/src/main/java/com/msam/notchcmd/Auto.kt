package com.msam.notchcmd

import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale

/** Routines: a name for a list of commands. Say "routine <name>" (or just the name) to run it. */
object RoutineStore {
    private fun p(c: Context) = c.getSharedPreferences("routines", Context.MODE_PRIVATE)

    fun all(c: Context): Map<String, List<String>> {
        val out = LinkedHashMap<String, List<String>>()
        try {
            val o = JSONObject(p(c).getString("r", "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                val a = o.getJSONArray(k)
                val l = ArrayList<String>()
                for (i in 0 until a.length()) l.add(a.getString(i))
                out[k] = l
            }
        } catch (_: Exception) {}
        return out
    }

    private fun write(c: Context, m: Map<String, List<String>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        p(c).edit().putString("r", o.toString()).apply()
    }

    fun put(c: Context, name: String, lines: List<String>) {
        val m = LinkedHashMap(all(c)); m[name.trim()] = lines; write(c, m)
    }

    fun remove(c: Context, name: String) {
        val m = LinkedHashMap(all(c)); m.remove(name); write(c, m)
    }

    fun find(c: Context, spoken: String): Pair<String, List<String>>? {
        val s = spoken.trim().lowercase(Locale.ROOT)
        if (s.isEmpty()) return null
        val e = all(c).entries.firstOrNull { it.key.trim().lowercase(Locale.ROOT) == s } ?: return null
        return Pair(e.key, e.value)
    }
}

/** Triggers: when something happens on the phone, run a command (one trigger per event type). */
data class Trigger(val type: String, val cmd: String, val on: Boolean, val arg: Int)

object TriggerStore {
    val TYPES = listOf(
        "charger_on" to "Charger connected",
        "charger_off" to "Charger disconnected",
        "battery_full" to "Battery reaches 100% (while charging)",
        "battery_low" to "Battery drops to a low %",
        "wifi_on" to "Wi-Fi connected",
        "wifi_off" to "Wi-Fi disconnected",
        "headset_on" to "Headphones plugged in",
        "headset_off" to "Headphones unplugged"
    )

    fun label(type: String): String = TYPES.firstOrNull { it.first == type }?.second ?: type

    private fun p(c: Context) = c.getSharedPreferences("triggers", Context.MODE_PRIVATE)

    fun load(c: Context): List<Trigger> {
        val out = ArrayList<Trigger>()
        try {
            val a = JSONArray(p(c).getString("l", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Trigger(o.getString("type"), o.getString("cmd"), o.optBoolean("on", true), o.optInt("arg", 20)))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(c: Context, l: List<Trigger>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("type", it.type).put("cmd", it.cmd).put("on", it.on).put("arg", it.arg)) }
        p(c).edit().putString("l", a.toString()).apply()
    }

    fun set(c: Context, type: String, cmd: String, arg: Int) {
        val l = ArrayList(load(c).filter { it.type != type })
        l.add(Trigger(type, cmd, true, arg)); save(c, l)
    }

    fun setOn(c: Context, type: String, on: Boolean) { save(c, load(c).map { if (it.type == type) it.copy(on = on) else it }) }
    fun remove(c: Context, type: String) { save(c, load(c).filter { it.type != type }) }
}

/** Notifications collected for the daily digest (kept on the phone only; one-time codes and ongoing ones are skipped). */
object DigestStore {
    private fun p(c: Context) = c.getSharedPreferences("digest", Context.MODE_PRIVATE)

    fun on(c: Context): Boolean = p(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }

    private fun read(c: Context): JSONArray = try { JSONArray(p(c).getString("l", "[]")) } catch (_: Exception) { JSONArray() }

    @Synchronized fun add(c: Context, app: String, title: String, text: String) {
        val a = read(c)
        if (a.length() > 0) {
            val last = a.getJSONObject(a.length() - 1)
            if (last.optString("a") == app && last.optString("ti") == title && last.optString("tx") == text) return
        }
        a.put(JSONObject().put("t", System.currentTimeMillis()).put("a", app).put("ti", title.take(80)).put("tx", text.take(240)))
        val keep = JSONArray()
        val from = maxOf(0, a.length() - 300)
        for (i in from until a.length()) keep.put(a.get(i))
        p(c).edit().putString("l", keep.toString()).apply()
    }

    fun count(c: Context): Int = read(c).length()
    fun clear(c: Context) { p(c).edit().remove("l").apply() }

    fun buildText(c: Context): String {
        val a = read(c)
        val limit = System.currentTimeMillis() - 36 * 3600_000L
        val tf = SimpleDateFormat("HH:mm", Locale.ENGLISH)
        val groups = LinkedHashMap<String, MutableList<String>>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optLong("t") < limit) continue
            val line = "- " + tf.format(o.optLong("t")) + " " + (if (o.optString("ti").isNotBlank()) o.optString("ti") + ": " else "") + o.optString("tx")
            groups.getOrPut(o.optString("a")) { ArrayList() }.add(line)
        }
        val sb = StringBuilder()
        groups.forEach { (app, lines) -> sb.append("== ").append(app).append(" ==\n"); lines.forEach { sb.append(it).append('\n') } }
        return sb.toString().take(6000)
    }
}

object AutoReplyPrefs {
    private fun p(c: Context) = c.getSharedPreferences("autoreply", Context.MODE_PRIVATE)
    fun on(c: Context): Boolean = p(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }
    fun skipGroups(c: Context): Boolean = p(c).getBoolean("skipg", true)
    fun setSkipGroups(c: Context, v: Boolean) { p(c).edit().putBoolean("skipg", v).apply() }
    fun t1(c: Context): String = p(c).getString("t1", "I'm busy right now, I will reply soon.") ?: ""
    fun t2(c: Context): String = p(c).getString("t2", "Thanks for your message, I will get back to you.") ?: ""
    fun setTexts(c: Context, a: String, b: String) { p(c).edit().putString("t1", a).putString("t2", b).apply() }
}

/** Incoming WhatsApp messages waiting for your decision (kept in memory only), and the AI drafts. */
object ReplyHub {
    class Pending(val sender: String, val msg: String, val action: Notification.Action, val ri: RemoteInput, val pkg: String = "com.whatsapp")

    val pending = LinkedHashMap<Int, Pending>()
    val drafts = HashMap<Int, String>()
    private var next = 1

    @Synchronized fun add(p: Pending): Int {
        val id = next++
        pending[id] = p
        while (pending.size > 40) pending.remove(pending.keys.first())
        return id
    }

    fun send(c: Context, id: Int, text: String): Boolean {
        val p = pending[id] ?: return false
        if (text.isBlank()) return false
        return try {
            val i = Intent()
            val b = Bundle()
            b.putCharSequence(p.ri.resultKey, text)
            RemoteInput.addResultsToIntent(arrayOf(p.ri), i, b)
            p.action.actionIntent.send(c, 0, i)
            true
        } catch (_: Exception) { false }
    }

    fun nid(id: Int): Int = 8000 + id % 1000

    private fun show(c: Context, id: Int, title: String, text: String, actions: List<Pair<String, String>>) {
        try {
            Notify.channel(c)
            val b = Notification.Builder(c, Notify.CH)
                .setSmallIcon(R.drawable.ic_stat_robot)
                .setContentTitle(title).setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
            actions.forEachIndexed { k, pair ->
                val pi = PendingIntent.getBroadcast(c, 400000 + id * 4 + k,
                    Intent(c, ReplyReceiver::class.java).putExtra("id", id).putExtra("act", pair.second),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                b.addAction(Notification.Action.Builder(0, pair.first, pi).build())
            }
            c.getSystemService(NotificationManager::class.java).notify(nid(id), b.build())
        } catch (_: Exception) {}
    }

    fun showOffer(c: Context, id: Int) {
        val p = pending[id] ?: return
        show(c, id, "Reply to " + p.sender + "?",
            p.msg + "\n\n1: " + AutoReplyPrefs.t1(c) + "\n2: " + AutoReplyPrefs.t2(c),
            listOf("Send 1" to "t1", "Send 2" to "t2", "AI draft" to "ai"))
    }

    fun showDraft(c: Context, id: Int, draft: String) {
        val p = pending[id] ?: return
        show(c, id, "AI draft for " + p.sender, draft, listOf("Send" to "send", "Cancel" to "cancel"))
    }

    fun showText(c: Context, id: Int, title: String, text: String) = show(c, id, title, text, emptyList())
}

class ReplyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", -1)
        val act = i.getStringExtra("act") ?: return
        val nm = c.getSystemService(NotificationManager::class.java)
        fun fail() = Notify.show(c, 6200, "Could not send the reply", "The original WhatsApp notification is gone. Reply from WhatsApp.")
        when (act) {
            "t1", "t2" -> {
                val ok = ReplyHub.send(c, id, if (act == "t1") AutoReplyPrefs.t1(c) else AutoReplyPrefs.t2(c))
                nm.cancel(ReplyHub.nid(id))
                if (!ok) fail()
            }
            "send" -> {
                val ok = ReplyHub.send(c, id, ReplyHub.drafts[id] ?: "")
                nm.cancel(ReplyHub.nid(id))
                if (!ok) fail()
            }
            "cancel" -> nm.cancel(ReplyHub.nid(id))
            "autostop" -> { AutoChat.clear(c); Notify.show(c, 6305, "Auto reply stopped", "ZAKI will not answer messages by itself any more.") }
            "ai" -> {
                ReplyHub.showText(c, id, "Writing a draft...", "The AI app opens for a moment. Do not touch the screen.")
                try { c.startForegroundService(Intent(c, OverlayService::class.java).putExtra("reply_ai", id)) } catch (_: Exception) {}
            }
        }
    }
}

/** Reads notifications (only if you gave notification access): feeds the digest and offers WhatsApp replies. */
class NotifService : NotificationListenerService() {
    private var lastKey = ""

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try { handle(sbn) } catch (_: Exception) {}
    }

    private fun handle(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT) ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim() ?: ""
        if (text.isEmpty()) return
        val wa = pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b"
        val handled = wa && AutoChat.active(this) && AutoChat.onMessage(this, sbn, title, text)
        if (!handled && AutoReplyPrefs.on(this) && wa) offerReply(sbn, title, text)
        if (DigestStore.on(this)) digest(sbn, pkg, title, text)
    }

    private fun offerReply(sbn: StatusBarNotification, title: String, text: String) {
        val n = sbn.notification
        if (n.category != null && n.category != Notification.CATEGORY_MESSAGE) return
        if (AutoReplyPrefs.skipGroups(this) && n.extras.getBoolean("android.isGroupConversation", false)) return
        val key = sbn.key + "|" + text
        if (key == lastKey) return
        lastKey = key
        val acts = n.actions ?: return
        var act: Notification.Action? = null
        var ri: RemoteInput? = null
        for (a in acts) {
            val r = a.remoteInputs
            if (r != null && r.isNotEmpty()) { act = a; ri = r[0]; break }
        }
        if (act == null || ri == null) return
        val id = ReplyHub.add(ReplyHub.Pending(title.ifBlank { "contact" }, text, act, ri))
        ReplyHub.showOffer(this, id)
    }

    private val skipCats = setOf(Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS, Notification.CATEGORY_CALL,
        Notification.CATEGORY_ALARM, Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS,
        Notification.CATEGORY_NAVIGATION, Notification.CATEGORY_STOPWATCH)

    private fun digest(sbn: StatusBarNotification, pkg: String, title: String, text: String) {
        val n = sbn.notification
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.category != null && n.category in skipCats) return
        if (pkg == "android" || pkg == "com.android.systemui") return
        val low = (title + " " + text).lowercase(Locale.ROOT)
        if (low.contains("otp") || low.contains("verification code") || low.contains("one-time") || low.contains("password") || low.contains("passcode")) return
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg.substringAfterLast('.') }
        DigestStore.add(this, app, title, text)
    }
}

/** Share text or a link from any app to ZAKI: pick what the assistant should do with it. */
class ShareActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        val act = intent?.action
        val type = intent?.type ?: ""
        // Docera's "Assistant" button: runs the chosen action straight away (only Docera may do this; checked with callingPackage)
        val dc = intent?.getStringExtra("nc_cmd")
        if (dc != null && callingPackage == "com.docera.parwez") { fromDocera(dc, text, type); return }
        if (type.startsWith("image/") && (act == Intent.ACTION_SEND || act == Intent.ACTION_SEND_MULTIPLE)) { takeImages(text); return }
        if (act != Intent.ACTION_SEND || text.isEmpty()) { finish(); return }
        val labels = arrayOf("Summarize (Docera note)", "Translate (Docera note)", "Explain (Docera note)", "Research this",
            "Post to WhatsApp channel", "Post to Facebook", "Post everywhere", "Open in the command box")
        val cmds = arrayOf("plug|summarize|", "plug|translate|", "plug|explain|", "plug|research|",
            "sharepost|channel|", "sharepost|facebook|", "sharepost|everywhere|", "")
        AlertDialog.Builder(this).setTitle("ZAKI").setItems(labels) { _, w ->
            try {
                if (w == labels.size - 1) startForegroundService(Intent(this, OverlayService::class.java).putExtra("box_text", text))
                else startForegroundService(Intent(this, OverlayService::class.java).putExtra("cmd", cmds[w] + text))
            } catch (_: Exception) {}
            finish()
        }.setOnCancelListener { finish() }.show()
    }

    /** dc = "plug|translate:Hindi" / "plug|summarize" / "sharepost|channel" / "box" ; text = page text (may be empty when photos are sent) */
    private fun fromDocera(dc: String, text: String, type: String) {
        val key = dc.substringAfter("|", "box").substringBefore(":")
        val lang = if (dc.contains(":")) dc.substringAfter(":") else ""
        val kind = dc.substringBefore("|")
        if (type.startsWith("image/")) {
            val uris = ArrayList<android.net.Uri>()
            try {
                if (intent.action == Intent.ACTION_SEND_MULTIPLE) uris.addAll(streamList()) else streamOne()?.let { uris.add(it) }
                val cd = intent.clipData
                if (uris.isEmpty() && cd != null) for (k in 0 until cd.itemCount) cd.getItemAt(k).uri?.let { uris.add(it) }
            } catch (_: Exception) {}
            if (uris.isEmpty()) { Toast.makeText(this, "No page received", Toast.LENGTH_SHORT).show(); finish(); return }
            if (!android.provider.Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Give ZAKI the overlay permission first (Setup)", Toast.LENGTH_LONG).show(); finish(); return
            }
            Toast.makeText(this, "Sending the page to the assistant…", Toast.LENGTH_SHORT).show()
            val use = uris.take(6)
            Thread {
                val out = ArrayList<String>()
                for (u in use) Plugins.importPicked(this, u)?.let { out.add(it) }
                Handler(Looper.getMainLooper()).post {
                    if (out.isEmpty()) Toast.makeText(this, "Could not read the page", Toast.LENGTH_LONG).show()
                    else try {
                        val svc = Intent(this, OverlayService::class.java)
                        if (kind == "plug") svc.putExtra("cmd", "plugimg|" + key + "|" + lang + "|" + out.joinToString("|"))
                        else svc.putExtra("imgs", out.toTypedArray()).putExtra("pre_text", text)
                        startForegroundService(svc)
                    } catch (_: Exception) {}
                    finish()
                }
            }.start()
            return
        }
        if (text.isBlank()) { Toast.makeText(this, "No text received", Toast.LENGTH_SHORT).show(); finish(); return }
        try {
            val svc = Intent(this, OverlayService::class.java)
            if (kind == "box") svc.putExtra("box_text", text) else svc.putExtra("cmd", dc + "|" + text)
            startForegroundService(svc)
        } catch (_: Exception) {}
        finish()
    }

    @Suppress("DEPRECATION")
    private fun streamList(): List<android.net.Uri> =
        (if (android.os.Build.VERSION.SDK_INT >= 33) intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java)
         else intent.getParcelableArrayListExtra<android.net.Uri>(Intent.EXTRA_STREAM)) ?: emptyList()

    @Suppress("DEPRECATION")
    private fun streamOne(): android.net.Uri? =
        if (android.os.Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java)
        else intent.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)

    /** photos shared from Gallery / WhatsApp / any app (up to 6): copy them, then open the command box with them attached */
    private fun takeImages(text: String) {
        val uris = ArrayList<android.net.Uri>()
        try {
            if (intent.action == Intent.ACTION_SEND_MULTIPLE) uris.addAll(streamList())
            else streamOne()?.let { uris.add(it) }
            val cd = intent.clipData
            if (uris.isEmpty() && cd != null) for (k in 0 until cd.itemCount) cd.getItemAt(k).uri?.let { uris.add(it) }
        } catch (_: Exception) {}
        if (uris.isEmpty()) { Toast.makeText(this, "No photo received", Toast.LENGTH_SHORT).show(); finish(); return }
        if (!android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Give ZAKI the overlay permission first (Setup)", Toast.LENGTH_LONG).show(); finish(); return
        }
        val extra = if (uris.size > 6) " (only the first 6 are used)" else ""
        Toast.makeText(this, "Adding photos…$extra", Toast.LENGTH_SHORT).show()
        val use = uris.take(6)
        Thread {
            val out = ArrayList<String>()
            for (u in use) Plugins.importPicked(this, u)?.let { out.add(it) }
            Handler(Looper.getMainLooper()).post {
                if (out.isEmpty()) Toast.makeText(this, "Could not read the photos", Toast.LENGTH_LONG).show()
                else try {
                    startForegroundService(Intent(this, OverlayService::class.java).putExtra("imgs", out.toTypedArray()).putExtra("pre_text", text))
                } catch (_: Exception) {}
                finish()
            }
        }.start()
    }
}
