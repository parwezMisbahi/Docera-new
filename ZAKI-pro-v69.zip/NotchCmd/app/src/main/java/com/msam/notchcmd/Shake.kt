package com.msam.notchcmd

import android.content.Context

/** Shake-to-open settings: on/off, how many shakes, normal or hard shake. */
object ShakePrefs {
    private fun p(c: Context) = c.getSharedPreferences("shake", Context.MODE_PRIVATE)

    fun on(c: Context): Boolean = p(c).getBoolean("on", false)
    fun setOn(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }

    fun count(c: Context): Int = p(c).getInt("count", 3).coerceIn(2, 6)
    fun setCount(c: Context, n: Int) { p(c).edit().putInt("count", n).apply() }

    fun hard(c: Context): Boolean = p(c).getBoolean("hard", false)
    fun setHard(c: Context, v: Boolean) { p(c).edit().putBoolean("hard", v).apply() }

    /** acceleration beyond gravity (m/s2) that counts as one shake */
    fun threshold(c: Context): Float = if (hard(c)) 22f else 13f
}
