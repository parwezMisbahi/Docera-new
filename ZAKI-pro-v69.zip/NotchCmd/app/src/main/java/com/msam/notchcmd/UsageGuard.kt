package com.msam.notchcmd

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import org.json.JSONObject
import java.util.Calendar

/** Roz ka screen limit + app-wise limit, aur awaaz ke jawab ki settings. Sirf yaad dilata hai, kuch band nahi karta. */
object UsageGuard {
    class Snap(val total: Long, val perApp: Map<String, Long>, val fg: String?)

    private fun p(c: Context) = c.getSharedPreferences("usage", Context.MODE_PRIVATE)
    private fun n(c: Context) = c.getSharedPreferences("n", Context.MODE_PRIVATE)

    // ---- awaaz ke jawab ----
    fun voiceOn(c: Context): Boolean = n(c).getBoolean("vreply", true)
    fun setVoiceOn(c: Context, v: Boolean) { n(c).edit().putBoolean("vreply", v).apply() }
    /** Naam set nahi hai to "muhtaram"; set hai to wahi naam bolta hai */
    fun userName(c: Context): String = (n(c).getString("uname", "") ?: "").trim().ifBlank { "muhtaram" }
    fun setUserName(c: Context, v: String) { n(c).edit().putString("uname", v.trim()).apply() }
    fun hasName(c: Context): Boolean = (n(c).getString("uname", "") ?: "").isNotBlank()

    // ---- limits ----
    fun screenLimit(c: Context): Int = p(c).getInt("screen", 0)
    fun setScreenLimit(c: Context, m: Int) { p(c).edit().putInt("screen", m.coerceAtLeast(0)).apply() }

    fun limits(c: Context): Map<String, Int> {
        val j = try { JSONObject(p(c).getString("apps", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val m = HashMap<String, Int>()
        for (k in j.keys()) m[k] = j.optInt(k, 0)
        return m
    }

    fun setLimit(c: Context, pkg: String, min: Int) {
        val j = try { JSONObject(p(c).getString("apps", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        if (min <= 0) j.remove(pkg) else j.put(pkg, min)
        p(c).edit().putString("apps", j.toString()).apply()
    }

    // ---- aaj ka istemal ----
    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }

    /** Aaj raat 12 baje se ab tak: har app ka foreground samay, kul samay, aur abhi kaunsa app khula hai */
    fun snapshot(c: Context): Snap? {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(cal.timeInMillis, now) ?: return null
        val e = UsageEvents.Event()
        val per = HashMap<String, Long>()
        val open = HashMap<String, Long>()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val pkg = e.packageName ?: continue
            when (e.eventType) {
                1 -> open[pkg] = e.timeStamp                                   // ACTIVITY_RESUMED
                2 -> { val t = open.remove(pkg); if (t != null) per[pkg] = (per[pkg] ?: 0L) + (e.timeStamp - t) }   // ACTIVITY_PAUSED
            }
        }
        var fg: String? = null
        var fgT = 0L
        for ((k, t) in open) {
            per[k] = (per[k] ?: 0L) + (now - t)
            if (t >= fgT) { fgT = t; fg = k }
        }
        per.remove("com.android.systemui"); per.remove("android"); per.remove(c.packageName)
        return Snap(per.values.sum(), per, if (fg == c.packageName) null else fg)
    }
}
