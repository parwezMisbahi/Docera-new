package com.example.callmsg

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.ContentProviderOperation
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.telecom.TelecomManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

val PERMS: Array<String> = buildList {
    add(Manifest.permission.CALL_PHONE)
    add(Manifest.permission.READ_PHONE_STATE)
    add(Manifest.permission.READ_CONTACTS)
    add(Manifest.permission.WRITE_CONTACTS)
    add(Manifest.permission.READ_CALL_LOG)
    add(Manifest.permission.READ_SMS)
    add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS)
    if (Build.VERSION.SDK_INT >= 33) add("android.permission.POST_NOTIFICATIONS")
}.toTypedArray()

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    companion object {
        // bahar se aaya tel: / sms: intent, JS ke uthane tak yahan rakha rehta hai
        @Volatile var pending: String = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.setBackgroundColor(0xFF111111.toInt())
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        // pinch zoom band
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p!!.createIntent(), 77)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")
        if (savedInstanceState == null) parseIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        parseIntent(intent)
    }

    // tel:9876543210 -> keypad mein number; sms:/smsto: -> message compose
    private fun parseIntent(i: Intent?) {
        if (i == null) return
        if ((i.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return
        val data = i.data ?: return
        val scheme = (data.scheme ?: "").lowercase()
        val raw = Uri.decode(data.schemeSpecificPart ?: "").substringBefore('?').trim()
        val o = JSONObject()
        when (scheme) {
            "tel" -> o.put("k", "dial").put("n", raw)
            "sms", "smsto", "mms", "mmsto" -> {
                val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                o.put("k", "sms").put("n", raw).put("b", body)
            }
            else -> return
        }
        pending = o.toString()
        i.data = null // dobara na chale (rotate / wapas aane par)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else if (requestCode == 78 || requestCode == 79) {
            // default Phone / SMS app ka jawab aa gaya
            web.evaluateJavascript("if(window.refreshAll)refreshAll()", null)
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript(
            "if(window.refreshAll)refreshAll();if(window.handleExternal)handleExternal()", null
        )
    }

    // back dabane par pehle page ke andar ka layer band ho (keypad / thread), phir app
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.handleBack?handleBack():false") { r ->
            if (r != "true") finish()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("onPermissionResult()", null)
    }
}

// JavaScript se yeh functions Android.xxx() naam se call hote hain
class Bridge(private val act: Activity) {

    // Har 5 sec ki polling par baar-baar poori query na chale: data badle tabhi dobara padho
    private class Cache {
        @Volatile var v = ""
        @Volatile var ok = false
        @Volatile var t = 0L
        @Volatile var gen = 0
    }
    private val cContacts = Cache()
    private val cCalls = Cache()
    private val cSms = Cache()

    private fun watch(uri: Uri, c: Cache) {
        try {
            act.contentResolver.registerContentObserver(uri, true,
                object : ContentObserver(Handler(Looper.getMainLooper())) {
                    override fun onChange(selfChange: Boolean) { c.gen++; c.ok = false }
                })
        } catch (e: Exception) { }
    }

    init {
        watch(ContactsContract.Contacts.CONTENT_URI, cContacts)
        watch(ContactsContract.Data.CONTENT_URI, cContacts)
        watch(CallLog.Calls.CONTENT_URI, cCalls)
        watch(Telephony.Sms.CONTENT_URI, cSms)
    }

    private fun cached(c: Cache, q: () -> String): String {
        if (c.ok && System.currentTimeMillis() - c.t < 30000) return c.v
        val g = c.gen
        val v = q()
        if (granted() && g == c.gen) { c.v = v; c.t = System.currentTimeMillis(); c.ok = true }
        return v
    }

    private fun granted() = PERMS.all {
        act.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun hasPermission(): Boolean = granted()

    @JavascriptInterface
    fun takePending(): String {
        val p = MainActivity.pending
        MainActivity.pending = ""
        return p
    }

    // ---- default Phone / SMS app ----
    @JavascriptInterface
    fun isDefaultDialer(): Boolean = try {
        act.getSystemService(TelecomManager::class.java).defaultDialerPackage == act.packageName
    } catch (e: Exception) { false }

    @JavascriptInterface
    fun isDefaultSms(): Boolean = SmsHelper.isDefaultSms(act)

    @JavascriptInterface
    fun requestDefaultDialer() {
        act.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val rm = act.getSystemService(RoleManager::class.java)
                    if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER))
                        act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 78)
                } else {
                    act.startActivityForResult(
                        Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                            .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, act.packageName), 78
                    )
                }
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun requestDefaultSms() {
        act.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val rm = act.getSystemService(RoleManager::class.java)
                    if (rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS))
                        act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 79)
                } else {
                    act.startActivityForResult(
                        Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                            .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, act.packageName), 79
                    )
                }
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun requestPermission() {
        act.runOnUiThread { act.requestPermissions(PERMS, 1) }
    }

    @JavascriptInterface
    fun getContacts(): String = cached(cContacts) { queryContacts() }

    private fun queryContacts(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            val name = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            val num = ContactsContract.CommonDataKinds.Phone.NUMBER
            act.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(name, num), null, null, "$name ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    arr.put(JSONObject().put("n", c.getString(0) ?: "").put("p", c.getString(1) ?: ""))
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    // Phone + jo accounts (Gmail/Outlook etc) contacts mein maujood hain, unki list
    @JavascriptInterface
    fun getAccounts(): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("n", "").put("t", ""))
        if (!granted()) return arr.toString()
        val skip = listOf("whatsapp", "telegram", "signal", "thoughtcrime", "viber", "facebook",
            "instagram", "skype", "linkedin", "tachyon", "truecaller", ".sim", "contact.sim")
        val seen = HashSet<String>()
        try {
            act.contentResolver.query(
                ContactsContract.RawContacts.CONTENT_URI,
                arrayOf(ContactsContract.RawContacts.ACCOUNT_NAME, ContactsContract.RawContacts.ACCOUNT_TYPE),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: ""
                    val t = c.getString(1) ?: ""
                    if (n.isEmpty() || t.isEmpty()) continue
                    if (skip.any { t.lowercase().contains(it) }) continue
                    if (seen.add("$t|$n")) arr.put(JSONObject().put("n", n).put("t", t))
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    // naya contact: at/an = account type/name (khali ho to sirf phone mein)
    @JavascriptInterface
    fun saveContact(json: String): String {
        if (!granted()) return "Error: permission nahi hai"
        return try {
            val o = JSONObject(json)
            val name = o.optString("n").trim()
            val phone = o.optString("p").trim()
            val email = o.optString("e").trim()
            val org = o.optString("o").trim()
            val note = o.optString("note").trim()
            val at = o.optString("at")
            val an = o.optString("an")
            if (name.isEmpty() && phone.isEmpty() && email.isEmpty()) return "Error: naam ya number daalo"
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, at.ifEmpty { null })
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, an.ifEmpty { null })
                    .build()
            )
            fun data(mime: String, vararg kv: Pair<String, Any>) {
                val b = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, mime)
                kv.forEach { b.withValue(it.first, it.second) }
                ops.add(b.build())
            }
            if (name.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME to name
            )
            if (phone.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Phone.NUMBER to phone,
                ContactsContract.CommonDataKinds.Phone.TYPE to ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
            )
            if (email.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Email.ADDRESS to email,
                ContactsContract.CommonDataKinds.Email.TYPE to ContactsContract.CommonDataKinds.Email.TYPE_HOME
            )
            if (org.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Organization.COMPANY to org
            )
            if (note.isNotEmpty()) data(
                ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Note.NOTE to note
            )
            act.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            cContacts.gen++; cContacts.ok = false
            "ok"
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    // a=number, c=saved name, d=time, t=type (1 in, 2 out, 3 missed...), du=seconds
    @JavascriptInterface
    fun getCalls(): String = cached(cCalls) { queryCalls() }

    private fun queryCalls(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            act.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE,
                    CallLog.Calls.TYPE, CallLog.Calls.DURATION
                ),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext() && arr.length() < 200) {
                    arr.put(
                        JSONObject()
                            .put("a", c.getString(0) ?: "")
                            .put("c", c.getString(1) ?: "")
                            .put("d", c.getLong(2))
                            .put("t", c.getInt(3))
                            .put("du", c.getLong(4))
                    )
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    @JavascriptInterface
    fun getSms(): String = cached(cSms) { querySms() }

    private fun querySms(): String {
        val arr = JSONArray()
        if (!granted()) return arr.toString()
        try {
            act.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
                null, null, "date DESC"
            )?.use { c ->
                while (c.moveToNext() && arr.length() < 600) {
                    arr.put(
                        JSONObject()
                            .put("a", c.getString(0) ?: "")
                            .put("b", c.getString(1) ?: "")
                            .put("d", c.getLong(2))
                            .put("s", c.getInt(3) == Telephony.Sms.MESSAGE_TYPE_SENT)
                    )
                }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    @JavascriptInterface
    fun sendSms(to: String, text: String): String = try {
        SmsHelper.send(act, to, text)
        cSms.gen++; cSms.ok = false
        "ok"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }

    // WhatsApp chat kholo. 10 digit number par India ka code 91 lagta hai (doosre desh ho to yahan badlo)
    @JavascriptInterface
    fun whatsapp(number: String): String {
        var d = number.filter { it.isDigit() }
        if (!number.trim().startsWith("+")) {
            d = d.trimStart('0')
            if (d.length == 10) d = "91$d"
        }
        val uri = Uri.parse("https://wa.me/$d")
        return try {
            act.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
            "ok"
        } catch (e: Exception) {
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW, uri))
                "ok"
            } catch (e2: Exception) {
                "Error: ${e2.message}"
            }
        }
    }

    @JavascriptInterface
    fun call(number: String): String = try {
        act.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
        "ok"
    } catch (e: Exception) {
        "Error: ${e.message}"
    }
}
