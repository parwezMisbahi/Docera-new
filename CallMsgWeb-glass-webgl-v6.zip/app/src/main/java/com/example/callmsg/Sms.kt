package com.example.callmsg

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager

object SmsHelper {
    const val CH_SMS = "sms"

    fun isDefaultSms(ctx: Context) = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    @Suppress("DEPRECATION")
    fun send(ctx: Context, to: String, text: String) {
        val sm: SmsManager =
            if ((Build.VERSION.SDK_INT >= 31)) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
        // default SMS app ko apna bheja hua message khud provider mein likhna padta hai
        if (isDefaultSms(ctx)) {
            try {
                ctx.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, to)
                    put(Telephony.Sms.BODY, text)
                    put(Telephony.Sms.DATE, System.currentTimeMillis())
                    put(Telephony.Sms.READ, 1)
                    put(Telephony.Sms.SEEN, 1)
                })
            } catch (e: Exception) { }
        }
    }

    fun nameFor(ctx: Context, number: String): String {
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) return it.getString(0) ?: number }
        } catch (e: Exception) { }
        return number
    }

    fun notify(ctx: Context, addr: String, body: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if ((Build.VERSION.SDK_INT >= 26)) nm.createNotificationChannel(
            NotificationChannel(CH_SMS, "Messages", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = Intent(ctx, MainActivity::class.java)
            .setAction(Intent.ACTION_SENDTO)
            .setData(Uri.parse("smsto:" + Uri.encode(addr)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, addr.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val b = if ((Build.VERSION.SDK_INT >= 26)) android.app.Notification.Builder(ctx, CH_SMS)
        else android.app.Notification.Builder(ctx).setPriority(android.app.Notification.PRIORITY_HIGH)
        b.setSmallIcon(android.R.drawable.sym_action_email)
            .setContentTitle(nameFor(ctx, addr))
            .setContentText(body)
            .setStyle(android.app.Notification.BigTextStyle().bigText(body))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setCategory(android.app.Notification.CATEGORY_MESSAGE)
        try { nm.notify(addr.hashCode(), b.build()) } catch (e: Exception) { }
    }
}

// Naya SMS aaya: sirf default SMS app ko yeh broadcast milta hai, isliye inbox mein likhna hamara kaam hai
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val addr = msgs[0].originatingAddress ?: ""
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        try {
            ctx.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
                put(Telephony.Sms.ADDRESS, addr)
                put(Telephony.Sms.BODY, body)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.DATE_SENT, msgs[0].timestampMillis)
                put(Telephony.Sms.READ, 0)
                put(Telephony.Sms.SEEN, 0)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
            })
        } catch (e: Exception) { }
        SmsHelper.notify(ctx, addr, body)
    }
}

// MMS: default SMS app banne ke liye receiver hona zaroori hai (MMS abhi support nahi)
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { }
}

// Call aane par "Message bhejo" quick reply
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val num = intent?.data?.schemeSpecificPart?.substringBefore('?')?.let { Uri.decode(it) }
            val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
            if (!num.isNullOrEmpty() && !text.isNullOrEmpty()) SmsHelper.send(this, num, text)
        } catch (e: Exception) { }
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
