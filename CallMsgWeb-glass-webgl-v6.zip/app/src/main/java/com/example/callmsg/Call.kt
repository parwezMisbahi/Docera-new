package com.example.callmsg

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.InCallService
import android.telecom.VideoProfile

// Chalti hui calls ki list + service ka handle (InCallActivity yahin se padhti hai)
object CallHolder {
    val calls = ArrayList<Call>()
    var service: InCallService? = null
    var listener: (() -> Unit)? = null

    // pehle ringing call, warna sabse nayi
    fun primary(): Call? = calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.lastOrNull()

    fun numberOf(c: Call): String = c.details?.handle?.schemeSpecificPart ?: ""
}

object CallNotif {
    const val CH = "calls"
    const val ID = 4242

    fun show(ctx: Context, call: Call) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(CH, "Calls", NotificationManager.IMPORTANCE_HIGH)
        )
        val num = CallHolder.numberOf(call)
        val name = if (num.isEmpty()) "Unknown" else SmsHelper.nameFor(ctx, num)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH)
        else Notification.Builder(ctx).setPriority(Notification.PRIORITY_HIGH)
        b.setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(name)
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
        if (call.state == Call.STATE_RINGING) {
            b.setContentText("Incoming call")
            b.setFullScreenIntent(open, true)
            b.addAction(action(ctx, "Decline", "reject", 1))
            b.addAction(action(ctx, "Answer", "answer", 2))
        } else {
            b.setContentText("Call chal rahi hai")
            b.addAction(action(ctx, "End", "reject", 3))
        }
        try { nm.notify(ID, b.build()) } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun action(ctx: Context, label: String, act: String, rc: Int): Notification.Action {
        val pi = PendingIntent.getBroadcast(
            ctx, rc, Intent(ctx, CallActionReceiver::class.java).putExtra("act", act),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(0, label, pi).build()
    }

    fun cancel(ctx: Context) = ctx.getSystemService(NotificationManager::class.java).cancel(ID)
}

// Notification ke Answer / Decline / End buttons
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val c = CallHolder.primary() ?: return
        when (intent.getStringExtra("act")) {
            "answer" -> {
                c.answer(VideoProfile.STATE_AUDIO_ONLY)
                ctx.startActivity(
                    Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            else -> if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
        }
    }
}

// System is service ko har call (aane wali / jaane wali) bhejta hai jab hum default Phone app hote hain
class CallService : InCallService() {

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state != Call.STATE_DISCONNECTED) CallNotif.show(this@CallService, call)
            CallHolder.listener?.invoke()
        }
    }

    override fun onCreate() {
        super.onCreate()
        CallHolder.service = this
    }

    override fun onDestroy() {
        if (CallHolder.service === this) CallHolder.service = null
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        CallHolder.calls.add(call)
        call.registerCallback(cb)
        CallNotif.show(this, call)
        // aane wali call: notification ka full-screen intent screen kholega.
        // jaane wali call: seedha call screen kholo
        if (call.state != Call.STATE_RINGING) {
            try {
                startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { }
        }
        CallHolder.listener?.invoke()
    }

    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        CallHolder.calls.remove(call)
        val next = CallHolder.primary()
        if (next == null) CallNotif.cancel(this) else CallNotif.show(this, next)
        CallHolder.listener?.invoke()
    }
}
