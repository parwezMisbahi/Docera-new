@file:Suppress("DEPRECATION")

package com.example.callmsg

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

// Call screen: naam, number, timer, Answer / Decline, Mute, Speaker, End
class InCallActivity : Activity() {

    private lateinit var nameTv: TextView
    private lateinit var numTv: TextView
    private lateinit var stateTv: TextView
    private lateinit var answerBtn: Button
    private lateinit var declineBtn: Button
    private lateinit var endBtn: Button
    private lateinit var muteBtn: Button
    private lateinit var spkBtn: Button
    private lateinit var ongoingRow: LinearLayout
    private lateinit var ringRow: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private var lastNumber = "\u0000"
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, color: Int): Button = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 16f
        isAllCaps = false
        background = GradientDrawable().apply { cornerRadius = dp(40).toFloat(); setColor(color) }
        layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply { setMargins(dp(8), 0, dp(8), 0) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
                window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#12141c"))
            setPadding(dp(16), dp(96), dp(16), dp(48))
        }
        nameTv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 32f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        numTv = TextView(this).apply { setTextColor(Color.parseColor("#aab0c0")); textSize = 16f; gravity = Gravity.CENTER }
        stateTv = TextView(this).apply {
            setTextColor(Color.parseColor("#7fd1a0")); textSize = 18f; gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, 0, 1f) }

        answerBtn = btn("Answer", Color.parseColor("#2e9e5b")).apply {
            setOnClickListener { CallHolder.primary()?.answer(VideoProfile.STATE_AUDIO_ONLY) }
        }
        declineBtn = btn("Decline", Color.parseColor("#d0443a")).apply {
            setOnClickListener { CallHolder.primary()?.reject(false, null) }
        }
        ringRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; addView(declineBtn); addView(answerBtn)
        }

        muteBtn = btn("Mute", Color.parseColor("#2b2f3d")).apply {
            setOnClickListener {
                val s = CallHolder.service ?: return@setOnClickListener
                s.setMuted(!(s.callAudioState?.isMuted ?: false))
                h.postDelayed({ refresh() }, 150)
            }
        }
        spkBtn = btn("Speaker", Color.parseColor("#2b2f3d")).apply {
            setOnClickListener {
                val s = CallHolder.service ?: return@setOnClickListener
                val on = s.callAudioState?.route == CallAudioState.ROUTE_SPEAKER
                s.setAudioRoute(if (on) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER)
                h.postDelayed({ refresh() }, 150)
            }
        }
        endBtn = btn("End call", Color.parseColor("#d0443a")).apply {
            setOnClickListener { CallHolder.primary()?.disconnect() }
        }
        ongoingRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val top = LinearLayout(this@InCallActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(muteBtn); addView(spkBtn)
            }
            val bottom = LinearLayout(this@InCallActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(20), 0, 0)
                addView(endBtn)
            }
            addView(top); addView(bottom)
        }

        root.addView(nameTv); root.addView(numTv); root.addView(stateTv)
        root.addView(spacer); root.addView(ringRow); root.addView(ongoingRow)
        setContentView(root)

        CallHolder.listener = { refresh() }
        handle(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: android.content.Intent?) {
        if (i?.getStringExtra("act") == "answer") CallHolder.primary()?.answer(VideoProfile.STATE_AUDIO_ONLY)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        CallHolder.listener = { refresh() }
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        CallHolder.listener = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { moveTaskToBack(true) }

    private fun refresh() {
        val c = CallHolder.primary()
        if (c == null) { finish(); return }
        val num = CallHolder.numberOf(c)
        if (num != lastNumber) {
            lastNumber = num
            nameTv.text = if (num.isEmpty()) "Unknown" else SmsHelper.nameFor(this, num)
            numTv.text = if (num.isEmpty() || nameTv.text == num) "" else num
        }
        val ringing = c.state == Call.STATE_RINGING
        ringRow.visibility = if (ringing) View.VISIBLE else View.GONE
        ongoingRow.visibility = if (ringing) View.GONE else View.VISIBLE
        stateTv.text = when (c.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_PULLING_CALL -> "Calling…"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Call khatam"
            Call.STATE_ACTIVE -> {
                val t = c.details?.connectTimeMillis ?: 0L
                if (t > 0) {
                    val s = ((System.currentTimeMillis() - t) / 1000).coerceAtLeast(0)
                    String.format("%02d:%02d", s / 60, s % 60)
                } else "Connected"
            }
            else -> ""
        }
        val st = CallHolder.service?.callAudioState
        muteBtn.text = if (st?.isMuted == true) "Unmute" else "Mute"
        spkBtn.text = if (st?.route == CallAudioState.ROUTE_SPEAKER) "Speaker off" else "Speaker"
    }
}
