package com.docera.parwez

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Watches which app comes to the foreground. If that app is currently blocked, the user is
 * sent straight back to the home screen. It only looks at the package name of the opening
 * window; it does not read anything on the screen.
 */
class AppBlockService : AccessibilityService() {

    companion object {
        /** True while Android has this service bound and running. */
        @Volatile
        var connected: Boolean = false
    }

    private var lastToast = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        connected = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Never let an exception escape: a crash here makes Android mark the service "malfunctioning".
        try {
            if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
            val pkg = event.packageName?.toString() ?: return
            if (pkg == packageName) return
            val rem = BlockStore.remainingFor(this, pkg)
            if (rem <= 0L) return
            // Safety net: never bounce essential apps, even if one somehow got into the list.
            if (pkg in BlockStore.protectedPackages(this)) return

            performGlobalAction(GLOBAL_ACTION_HOME)

            val now = SystemClock.elapsedRealtime()
            if (now - lastToast > 2500L) {
                lastToast = now
                Toast.makeText(
                    this,
                    "Blocked by Docera · ${BlockStore.format(rem)} left",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } catch (_: Throwable) {
        }
    }

    override fun onInterrupt() {}
}
