package com.docera.parwez

import android.content.ClipboardManager
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Command receiver for the NotchCmd assistant (com.msam.notchcmd).
 *
 * NotchCmd calls  contentResolver.call(content://com.docera.parwez.cmd, "cmd", null, Bundle{json})
 * and gets back  Bundle{ok:Boolean, msg:String}.
 *
 * Supported actions
 *   block_app  {app, pkg?, minutes}  -> starts a normal Docera block (same rules as the Blocker screen:
 *                                 protected apps are refused, there is still NO unblock)
 *   new_note   {text | clip:true, title?}  -> creates a note (clip = take the text from the clipboard)
 *   append_note{name, text}    -> adds a line to an existing (unlocked) note
 *   open_note  {name}          -> opens a note
 *   open_page  {page}          -> home | notes | folders | library
 *
 * Only NotchCmd may call this: anything else is refused.
 */
class CmdProvider : ContentProvider() {

    override fun onCreate(): Boolean = true
    override fun query(u: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    private fun callerOk(ctx: Context): Boolean {
        if (callingPackage == ALLOWED) return true
        return try {
            ctx.packageManager.getPackagesForUid(Binder.getCallingUid())?.contains(ALLOWED) == true
        } catch (_: Exception) {
            false
        }
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        val ctx = context ?: return reply(false, "Docera taiyar nahi hai")
        if (method != "cmd") return reply(false, "Command samajh nahi aayi")
        if (!callerOk(ctx)) return reply(false, "Sirf NotchCmd ko ijazat hai")
        val o = try {
            JSONObject(extras?.getString("json") ?: "")
        } catch (_: Exception) {
            return reply(false, "Command samajh nahi aayi")
        }
        return try {
            when (o.optString("action")) {
                "block_app" -> blockApp(ctx, o.optString("app"), o.optInt("minutes", 30), o.optString("pkg"))
                "new_note" -> {
                    val clip = o.optBoolean("clip")
                    if (!clip && o.optString("text").isBlank()) return reply(false, "Note ka text khali hai")
                    queue(ctx, o, if (clip) "Clipboard se naya note ban raha hai" else "Naya note ban raha hai")
                }
                "append_note" -> {
                    if (o.optString("name").isBlank() || o.optString("text").isBlank()) return reply(false, "Note ka naam ya text khali hai")
                    queue(ctx, o, "Note mein likh raha hoon")
                }
                "open_note" -> {
                    if (o.optString("name").isBlank()) return reply(false, "Note ka naam batao")
                    queue(ctx, o, "Note khol raha hoon")
                }
                "open_page" -> {
                    val pg = o.optString("page")
                    if (pg !in PAGES) reply(false, "Docera ka \"$pg\" page abhi supported nahi")
                    else queue(ctx, o, "Docera $pg khol raha hoon")
                }
                else -> reply(false, "Docera ka ye command abhi supported nahi hai")
            }
        } catch (e: Throwable) {
            reply(false, "Docera error: " + (e.message ?: ""))
        }
    }

    // ---------- note / page commands: saved in a small queue, the web UI picks them up ----------
    private fun queue(ctx: Context, o: JSONObject, msg: String): Bundle {
        CmdQueue.add(ctx, o)
        MainActivity.pullHook?.invoke()
        return reply(true, msg)
    }

    // ---------- block_app ----------
    private fun blockApp(ctx: Context, name: String, minutes: Int, pkg: String): Bundle {
        if (name.isBlank() && pkg.isBlank()) return reply(false, "Kaunsa app block karna hai?")
        if (minutes < 1 || minutes > BlockStore.MAX_MINUTES) return reply(false, "Time 1 minute se 7 din ke beech rakho")
        if (!(BlockGuardService.ready(ctx) || AppBlockService.connected)) {
            BlockStore.tryEnableService(ctx)
            if (!(BlockGuardService.ready(ctx) || AppBlockService.connected))
                return reply(false, "Docera ka blocker band hai - Accessibility mein Docera App Blocker ON karo")
        }
        // NotchCmd already matched the spoken name to an installed app and sends its package; fall back to our own name match
        val byPkg = if (pkg.isNotBlank()) try {
            pkg to ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            null
        } else null
        val hit = byPkg ?: findApp(ctx, name) ?: return reply(false, "App nahi mila: $name")
        if (hit.first in BlockStore.protectedPackages(ctx)) return reply(false, "${hit.second} block nahi ho sakta (zaroori app hai)")
        BlockStore.add(ctx, listOf(hit.first), minutes.toLong() * 60_000L)
        if (BlockGuardService.ready(ctx)) BlockGuardService.start(ctx)
        return reply(true, "${hit.second} ${fmt(minutes)} ke liye block ho gaya")
    }

    private fun fmt(m: Int): String = when {
        m >= 1440 && m % 1440 == 0 -> "${m / 1440} din"
        m >= 60 -> "${m / 60} ghante" + if (m % 60 != 0) " ${m % 60} minute" else ""
        else -> "$m minute"
    }

    /** (package, label) of the best launcher-app match for a spoken name */
    private fun findApp(ctx: Context, name: String): Pair<String, String>? {
        val pm = ctx.packageManager
        val q = name.lowercase(Locale.ROOT).trim().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ")
        val qc = q.replace(" ", "")
        val toks = q.split(" ").filter { it.isNotBlank() }
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Triple(it.loadLabel(pm).toString(), it.activityInfo.packageName, 0) }
            .distinctBy { it.second }
        fun rank(label: String): Int {
            val l = label.lowercase(Locale.ROOT)
            val lc = l.replace(Regex("[^\\p{L}\\p{N}]"), "")
            return when {
                l == q || lc == qc -> 0
                lc.startsWith(qc) -> 1
                lc.contains(qc) -> 2
                toks.isNotEmpty() && toks.all { l.contains(it) } -> 3
                lc.length >= 4 && qc.contains(lc) -> 4
                else -> 9
            }
        }
        val best = apps.map { it to rank(it.first) }.filter { it.second < 9 }
            .minWithOrNull(compareBy({ it.second }, { it.first.first.length }))?.first ?: return null
        return best.second to best.first
    }

    private fun reply(ok: Boolean, msg: String) = Bundle().apply { putBoolean("ok", ok); putString("msg", msg) }

    companion object {
        const val ALLOWED = "com.msam.notchcmd"
        val PAGES = setOf("home", "notes", "folders", "library")
    }
}

/** Notes/page commands waiting for the web UI. Old ones (10+ min) are dropped. */
object CmdQueue {
    private const val PREFS = "docera_cmd"
    private const val KEY = "q"
    private const val MAX_AGE_MS = 10 * 60 * 1000L

    private fun read(ctx: Context): JSONArray = try {
        JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
    } catch (_: Exception) {
        JSONArray()
    }

    private fun write(ctx: Context, a: JSONArray) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    @Synchronized
    fun add(ctx: Context, o: JSONObject) {
        val a = read(ctx)
        o.put("t", System.currentTimeMillis())
        a.put(o)
        // keep the queue small
        val out = JSONArray()
        for (i in maxOf(0, a.length() - 20) until a.length()) out.put(a.get(i))
        write(ctx, out)
    }

    /**
     * Returns the waiting commands as a JSON array string and removes them.
     * "clip" notes need the clipboard, which Android only lets a focused app read - if Docera
     * is not focused yet they stay queued and are handed out on the next pull.
     */
    @Synchronized
    fun take(ctx: Context, focused: Boolean): String {
        val now = System.currentTimeMillis()
        val keep = JSONArray()
        val out = JSONArray()
        val a = read(ctx)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (now - o.optLong("t", now) > MAX_AGE_MS) continue
            if (o.optBoolean("clip") && !o.has("text")) {
                if (!focused) {
                    keep.put(o)
                    continue
                }
                o.put("text", clipText(ctx))
            }
            out.put(o)
        }
        write(ctx, keep)
        return out.toString()
    }

    private fun clipText(ctx: Context): String = try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val c = cm.primaryClip
        if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(ctx).toString() else ""
    } catch (_: Throwable) {
        ""
    }
}
