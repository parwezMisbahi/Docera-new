package com.docera.parwez

import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Online reading of archive.org books WITHOUT downloading them first.
 *
 * The viewer (pdf.js) asks for  https://docera.arc/pdf?id=<archive identifier>  with HTTP "Range" headers
 * (only the pieces it needs for the page on screen). This object answers those requests from
 * WebViewClient.shouldInterceptRequest by forwarding the same Range to archive.org and streaming the reply back,
 * so only the pages that are really read use data. A WebView fetch straight to archive.org would be blocked by CORS,
 * which is why it goes through here.
 */
object ArchiveStream {
    const val HOST = "docera.arc"
    private const val UA = "Docera/1.0 (Android PDF reader)"
    private val names = ConcurrentHashMap<String, String>()   // archive identifier -> PDF file name inside the item

    private fun open(url: String, range: String?): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        // identity: a gzip-encoded reply would break the byte offsets of a Range request
        c.setRequestProperty("Accept-Encoding", "identity")
        if (!range.isNullOrBlank()) c.setRequestProperty("Range", range)
        return c
    }

    /** Same choice the download uses: Text PDF first, then Image Container PDF, then any PDF. */
    private fun pdfName(identifier: String): String {
        names[identifier]?.let { return it }
        val enc = URLEncoder.encode(identifier, "UTF-8")
        val c = open("https://archive.org/metadata/$enc", null)
        val text = try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            try { c.disconnect() } catch (_: Throwable) {}
        }
        val meta = JSONObject(text)
        val md = meta.optJSONObject("metadata")
        if (md != null && md.optString("access-restricted-item") == "true")
            throw IllegalStateException("lending-only")
        val files = meta.optJSONArray("files") ?: throw IllegalStateException("no files")
        var best: String? = null
        var bestScore = -1
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val name = f.optString("name")
            val fmt = f.optString("format")
            if (f.optString("private") == "true") continue
            if (!name.endsWith(".pdf", true) && !fmt.contains("PDF", true)) continue
            val score = when {
                fmt.equals("Text PDF", true) -> 3
                fmt.equals("Image Container PDF", true) -> 2
                else -> 1
            }
            if (score > bestScore) { bestScore = score; best = name }
        }
        val n = best ?: throw IllegalStateException("no pdf")
        names[identifier] = n
        return n
    }

    private val commonsUrls = ConcurrentHashMap<String, String>()   // "wc:File:Name.pdf" -> direct upload.wikimedia.org url

    private fun getText(url: String): String {
        val c = open(url, null)
        try {
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            try { c.disconnect() } catch (_: Throwable) {}
        }
    }

    /** Free scanned books on Wikimedia Commons (direct PDF files that support Range requests). */
    fun searchCommons(words: List<String>): org.json.JSONArray {
        val out = org.json.JSONArray()
        val q = words.joinToString(" ") + " filemime:pdf"
        val url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=15" +
            "&gsrsearch=" + URLEncoder.encode(q, "UTF-8") +
            "&prop=imageinfo&iiprop=url%7Cmime%7Cextmetadata&iiurlwidth=300&iiextmetadatafilter=ObjectName%7CArtist%7CDateTimeOriginal"
        val pages = JSONObject(getText(url)).optJSONObject("query")?.optJSONObject("pages") ?: return out
        val list = ArrayList<JSONObject>()
        val keys = pages.keys()
        while (keys.hasNext()) list.add(pages.getJSONObject(keys.next()))
        list.sortBy { it.optInt("index", 999) }
        for (p in list) {
            val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            if (ii.optString("mime") != "application/pdf") continue
            val title = p.optString("title")
            val fileUrl = ii.optString("url")
            if (title.isBlank() || fileUrl.isBlank()) continue
            val key = "wc:$title"
            commonsUrls[key] = fileUrl
            val em = ii.optJSONObject("extmetadata")
            fun meta(n: String) = em?.optJSONObject(n)?.optString("value").orEmpty().replace(Regex("<[^>]*>"), "").trim()
            val nice = title.removePrefix("File:").removeSuffix(".pdf").removeSuffix(".PDF").replace('_', ' ')
            out.put(
                JSONObject().put("id", key).put("title", meta("ObjectName").ifBlank { nice })
                    .put("creator", meta("Artist")).put("year", meta("DateTimeOriginal").take(4).takeIf { it.all(Char::isDigit) } ?: "")
                    .put("pages", "").put("lang", "").put("src", "commons")
                    .put("cover", ii.optString("thumburl"))
            )
        }
        return out
    }

    fun commonsUrl(key: String): String {
        commonsUrls[key]?.let { return it }
        val title = key.removePrefix("wc:")
        val url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&prop=imageinfo&iiprop=url&titles=" +
            URLEncoder.encode(title, "UTF-8")
        val pages = JSONObject(getText(url)).getJSONObject("query").getJSONObject("pages")
        val first = pages.getJSONObject(pages.keys().next())
        val u = first.optJSONArray("imageinfo")?.optJSONObject(0)?.optString("url").orEmpty()
        if (u.isBlank()) throw IllegalStateException("no pdf")
        commonsUrls[key] = u
        return u
    }

    private fun cors(extra: Map<String, String> = emptyMap()): HashMap<String, String> {
        val h = HashMap<String, String>()
        h["Access-Control-Allow-Origin"] = "*"
        h["Access-Control-Allow-Headers"] = "Range"
        h["Access-Control-Allow-Methods"] = "GET, HEAD, OPTIONS"
        h["Access-Control-Expose-Headers"] = "Content-Range, Content-Length, Accept-Ranges"
        h["Cache-Control"] = "no-store"
        h.putAll(extra)
        return h
    }

    private fun fail(status: Int, msg: String) = WebResourceResponse(
        "text/plain", "utf-8", status, "Error", cors(), ByteArrayInputStream(msg.toByteArray())
    )

    fun handle(req: WebResourceRequest): WebResourceResponse {
        if (req.method.equals("OPTIONS", true))
            return WebResourceResponse("text/plain", "utf-8", 204, "No Content", cors(), ByteArrayInputStream(ByteArray(0)))
        return try {
            val u: Uri = req.url
            val id = u.getQueryParameter("id")?.takeIf { it.isNotBlank() } ?: return fail(400, "no id")
            val enc = URLEncoder.encode(id, "UTF-8")
            val url = if (id.startsWith("wc:")) commonsUrl(id) else {
                val file = pdfName(id)
                "https://archive.org/download/$enc/" +
                    file.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
            }
            val range = req.requestHeaders?.entries?.firstOrNull { it.key.equals("Range", true) }?.value
            val c = open(url, range)
            val code = c.responseCode
            if (code !in 200..299) {
                val m = "HTTP $code"
                try { c.disconnect() } catch (_: Throwable) {}
                return fail(if (code in 400..599) code else 502, m)
            }
            val h = cors()
            c.getHeaderField("Content-Range")?.let { h["Content-Range"] = it }
            c.getHeaderField("Content-Length")?.let { h["Content-Length"] = it }
            h["Accept-Ranges"] = "bytes"
            val stream = object : java.io.FilterInputStream(c.inputStream) {
                override fun close() {
                    try { super.close() } finally { try { c.disconnect() } catch (_: Throwable) {} }
                }
            }
            WebResourceResponse(
                "application/pdf", null, code, if (code == 206) "Partial Content" else "OK", h, stream
            )
        } catch (e: IllegalStateException) {
            fail(403, e.message ?: "blocked")
        } catch (e: Throwable) {
            fail(502, e.message ?: e.javaClass.simpleName)
        }
    }
}
