package com.docera.parwez

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Bitmap
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ClipData
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.net.Uri
import android.widget.Toast
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import android.view.accessibility.AccessibilityManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.FileOutputStream
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.InputStream
import java.io.RandomAccessFile

// FragmentActivity (a subclass of ComponentActivity) is required by BiometricPrompt.
class MainActivity : FragmentActivity() {

    companion object {
        /** Set while MainActivity is alive: lets CmdProvider tell the web UI that a NotchCmd command is waiting. */
        @Volatile
        var pullHook: (() -> Unit)? = null
        private const val STORAGE_PREFS = "vaultnotes_storage_prefs"
        private const val KEY_FOLDER_URIS = "pdf_folder_tree_uris"
        private const val MAX_FOLDER_DEPTH = 8
        private const val MAX_ENTRIES_PER_FOLDER = 20000
        private const val MAX_TOTAL_ALL_FILES_SCAN = 60000
        private const val SCAN_BUDGET_MS = 75_000L
        // Folders that only hold photos / videos / voice notes. Telegram and WhatsApp keep tens of thousands of files in them;
        // walking them used up the scan limit before the document folders (where the PDFs are) were reached.
        private val MEDIA_DIR_NAMES = setOf(
            "dcim", "movies", "music", "ringtones", "alarms", "notifications", "podcasts", "thumbnails", "cache", "stickers",
            "sent", "private", "wallpaper", "profile photos"
        )
        private val MEDIA_DIR_PREFIXES = listOf(
            "whatsapp images", "whatsapp video", "whatsapp audio", "whatsapp voice", "whatsapp animated", "whatsapp stickers",
            "whatsapp profile", "whatsapp wallpaper", "whatsapp business images", "whatsapp business video",
            "whatsapp business audio", "whatsapp business voice", "telegram images", "telegram video", "telegram audio",
            "telegram stories", "telegram stickers"
        )
        fun isMediaOnlyDir(name: String): Boolean {
            val l = name.lowercase()
            return l in MEDIA_DIR_NAMES || MEDIA_DIR_PREFIXES.any { l.startsWith(it) }
        }
    }

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Incoming PDF state
    @Volatile
    private var hasIncomingPdf: Boolean = false
    @Volatile
    private var incomingPdfName: String? = null
    @Volatile
    private var incomingPdfSize: Long = 0L
    @Volatile
    private var incomingPdfError: String? = null
    @Volatile
    private var currentTempFile: File? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris: Array<Uri>? = if (result.resultCode == RESULT_OK && result.data != null) {
            val clipData = result.data?.clipData
            if (clipData != null && clipData.itemCount > 0) {
                Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
            } else {
                result.data?.data?.let { arrayOf(it) }
            }
        } else {
            null
        }
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    @Volatile
    private var biometricActive: Boolean = false

    private var pendingWebPermission: PermissionRequest? = null

    // ---- "Save as": the system file manager picker, the user chooses the folder and name ----
    private val stagedFiles = HashMap<String, Pair<File, String>>()   // id -> (temp file, mime)
    private var pendingSaveId: String? = null

    private class SaveAsContract : ActivityResultContract<Pair<String, String>, Uri?>() {
        override fun createIntent(context: Context, input: Pair<String, String>): Intent =
            Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType(input.second.ifBlank { "application/octet-stream" })
                .putExtra(Intent.EXTRA_TITLE, input.first)

        override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
            if (resultCode == Activity.RESULT_OK) intent?.data else null
    }

    private val saveAsLauncher = registerForActivityResult(SaveAsContract()) { uri ->
        val id = pendingSaveId
        pendingSaveId = null
        val item = if (id != null) synchronized(stagedFiles) { stagedFiles.remove(id) } else null
        var ok = false
        var msg = ""
        if (item == null) {
            msg = "file missing"
        } else if (uri == null) {
            msg = "cancelled"
        } else {
            try {
                contentResolver.openOutputStream(uri, "w")?.use { out ->
                    item.first.inputStream().use { it.copyTo(out) }
                } ?: throw FileNotFoundException("cannot write")
                ok = true
            } catch (e: Exception) {
                msg = e.localizedMessage ?: "write failed"
            }
        }
        try { item?.first?.parentFile?.deleteRecursively() } catch (_: Exception) {}
        try {
            webView.evaluateJavascript(
                "if(window.__saveAsDone){window.__saveAsDone($ok,${JSONObject.quote(msg)})}", null
            )
        } catch (_: Throwable) {
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val req = pendingWebPermission
        pendingWebPermission = null
        if (req != null) {
            val allowed = req.resources.filter { res ->
                when (res) {
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                        result[Manifest.permission.RECORD_AUDIO] == true ||
                            hasPerm(Manifest.permission.RECORD_AUDIO)
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                        result[Manifest.permission.CAMERA] == true ||
                            hasPerm(Manifest.permission.CAMERA)
                    else -> false
                }
            }.toTypedArray()
            try {
                if (allowed.isNotEmpty()) req.grant(allowed) else req.deny()
            } catch (_: Exception) {
            }
        }
    }

    private fun hasPerm(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // --- Auto-import from device storage: folder picker (Storage Access Framework) ---
    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val treeUri = if (result.resultCode == RESULT_OK) result.data?.data else null
        if (treeUri == null) {
            notifyFolderPickResult(false, null)
            return@registerForActivityResult
        }
        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Some providers (or File Managers) don't support persistable permission.
            // We still remember the folder below; it just may need to be re-picked
            // later if the OS revokes temporary access. Never crash here.
        }
        val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
        val current = (prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()).toMutableSet()
        current.add(treeUri.toString())
        prefs.edit().putStringSet(KEY_FOLDER_URIS, current).apply()
        notifyFolderPickResult(true, folderDisplayName(treeUri))
    }

    // --- Auto-import from device storage: "All files access" (whole storage scan) ---
    private val allFilesAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> notifyAllFilesAccessChanged() }

    private val legacyStoragePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> notifyAllFilesAccessChanged() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NativePdfEngine.cleanup(applicationContext)

        // Camera / microphone permissions are now requested only when a feature
        // actually needs them (see onPermissionRequest below), not at app start.

        // Process incoming intent (e.g. Open with from File Manager)
        handleIntent(intent)

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                useWideViewPort = true
                loadWithOverviewMode = false
                // Native WebView pinch-zoom OFF: it zoomed the whole app UI. PDF zoom is
                // handled by the app's own JS pinch-to-zoom inside the PDF viewer only.
                displayZoomControls = false
                setSupportZoom(false)
                builtInZoomControls = false
                textZoom = 100
                mediaPlaybackRequiresUserGesture = false
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    safeBrowsingEnabled = false
                }
            }

            webViewClient = object : WebViewClient() {
                // Native PDF engine: https://docera.pdf/... is answered in-app (never touches the network)
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val u = request?.url
                    if (u != null && u.host == NativePdfEngine.HOST) return NativePdfEngine.handle(u)
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (hasIncomingPdf) {
                        view?.evaluateJavascript(
                            "if (typeof window.checkIncomingPdf === 'function') { window.checkIncomingPdf(); }",
                            null
                        )
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val needed = mutableListOf<String>()
                        for (res in request.resources) {
                            when (res) {
                                PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                                    if (!hasPerm(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO)
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                                    if (!hasPerm(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA)
                            }
                        }
                        val supported = request.resources.filter {
                            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                                it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                        }.toTypedArray()
                        if (supported.isEmpty()) {
                            request.deny()
                        } else if (needed.isEmpty()) {
                            request.grant(supported)
                        } else {
                            pendingWebPermission?.let { try { it.deny() } catch (_: Exception) {} }
                            pendingWebPermission = request
                            permissionLauncher.launch(needed.toTypedArray())
                        }
                    }
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    if (fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }

                    try {
                        filePickerLauncher.launch(intent)
                    } catch (e: Exception) {
                        this@MainActivity.filePathCallback?.onReceiveValue(null)
                        this@MainActivity.filePathCallback = null
                        return false
                    }
                    return true
                }
            }

            // Register bridge for passing incoming PDF data securely into WebView
            addJavascriptInterface(AndroidPdfBridge(), "AndroidPdfBridge")
            addJavascriptInterface(PdfEngineBridge(applicationContext), "AndroidPdfEngine")
            // Register bridge for auto-discovering PDFs already on the device (no import/copy needed)
            addJavascriptInterface(AndroidStorageBridge(), "AndroidStorageBridge")
            // Register bridge so the WebView's About screen can open mailto:/wa.me/Play Store
            // links in the user's actual Gmail/WhatsApp/Play Store app — plain <a href> links
            // to these schemes don't leave the WebView on their own since no
            // shouldOverrideUrlLoading is set up (intentionally, so normal in-app navigation
            // is left untouched everywhere else).
            addJavascriptInterface(AndroidLinkBridge(), "AndroidLinkBridge")
            // Biometric (fingerprint / face) unlock for the app lock screen
            addJavascriptInterface(AndroidBiometricBridge(), "AndroidBiometricBridge")
            // App Blocker (block chosen apps for a fixed time; there is no unblock call)
            addJavascriptInterface(AndroidBlockerBridge(), "AndroidBlockerBridge")
            // Saves exported/downloaded files (PDFs, images) into the real Downloads folder
            addJavascriptInterface(AndroidSaveBridge(), "AndroidSaveBridge")
            // Commands from the NotchCmd assistant (new note, open note/page) waiting in CmdQueue
            addJavascriptInterface(AndroidCmdBridge(), "AndroidCmdBridge")
            addJavascriptInterface(AndroidAssistBridge(), "AndroidAssistBridge")
            addJavascriptInterface(AndroidArchiveBridge(), "AndroidArchive")
            pullHook = { runOnUiThread { pullCmds() } }

            loadUrl("file:///android_asset/index.html")
        }

        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        try {
            webView.onResume()
            webView.resumeTimers()
        } catch (_: Throwable) {
        }
        // If the phone killed the blocker while blocks are still running, switch it back on.
        try {
            if (BlockStore.active(this).isNotEmpty()) {
                if (BlockGuardService.ready(this) && !BlockGuardService.running) BlockGuardService.start(this)
                if (!AppBlockService.connected) BlockStore.tryEnableService(this)
            }
        } catch (_: Throwable) {
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) pullCmds()
    }

    /** Asks the web UI to fetch waiting NotchCmd commands (it ignores the call until it has finished starting). */
    private fun pullCmds() {
        try {
            webView.evaluateJavascript("if (window.docCmdPull) { window.docCmdPull(); }", null)
        } catch (_: Throwable) {
        }
    }

    /** "Assistant" button of the PDF viewer: hands the page text / page photos to NotchCmd together with the chosen action. */
    inner class AndroidAssistBridge {
        @JavascriptInterface
        fun available(): Boolean = try { packageManager.getPackageInfo("com.msam.notchcmd", 0); true } catch (_: Throwable) { false }

        /** cmd e.g. "plug|translate:Hindi", "plug|summarize", "sharepost|channel", "box"; imgsB64Json = JSON array of JPEG base64 (page photos) or "[]" */
        @JavascriptInterface
        fun send(cmd: String, text: String, imgsB64Json: String): String {
            return try {
                val arr = org.json.JSONArray(imgsB64Json)
                val uris = ArrayList<Uri>()
                if (arr.length() > 0) {
                    val dir = File(cacheDir, "shared").apply { mkdirs() }
                    dir.listFiles()?.filter { it.name.startsWith("asst_") }?.forEach { it.delete() }
                    for (k in 0 until minOf(arr.length(), 6)) {
                        val f = File(dir, "asst_" + System.currentTimeMillis() + "_" + k + ".jpg")
                        f.writeBytes(android.util.Base64.decode(arr.getString(k), android.util.Base64.DEFAULT))
                        uris.add(FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f))
                    }
                }
                val i = if (uris.isEmpty()) Intent(Intent.ACTION_SEND).setType("text/plain")
                        else if (uris.size == 1) Intent(Intent.ACTION_SEND).setType("image/jpeg").putExtra(Intent.EXTRA_STREAM, uris[0])
                        else Intent(Intent.ACTION_SEND_MULTIPLE).setType("image/jpeg").putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                i.setClassName("com.msam.notchcmd", "com.msam.notchcmd.ShareActivity")
                    .putExtra("nc_cmd", cmd).putExtra(Intent.EXTRA_TEXT, text)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (uris.isNotEmpty()) {
                    val cd = ClipData.newRawUri("pages", uris[0])
                    for (k in 1 until uris.size) cd.addItem(ClipData.Item(uris[k]))
                    i.clipData = cd
                }
                runOnUiThread {
                    try { startActivityForResult(i, 7711) }   // a result-style start lets NotchCmd verify that Docera sent it
                    catch (_: Throwable) { Toast.makeText(this@MainActivity, "NotchCmd could not be opened", Toast.LENGTH_SHORT).show() }
                }
                "ok"
            } catch (e: Throwable) { "error: " + (e.message ?: "unknown") }
        }
    }

    inner class AndroidCmdBridge {
        @JavascriptInterface
        fun takePending(): String = try {
            CmdQueue.take(this@MainActivity, hasWindowFocus())
        } catch (_: Throwable) {
            "[]"
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            webView.onPause()
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        pullHook = null
        try {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidPdfBridge")
            webView.removeJavascriptInterface("AndroidStorageBridge")
            webView.removeJavascriptInterface("AndroidLinkBridge")
            webView.removeJavascriptInterface("AndroidBiometricBridge")
            webView.removeJavascriptInterface("AndroidBlockerBridge")
            webView.removeJavascriptInterface("AndroidCmdBridge")
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        pullCmds()
        if (hasIncomingPdf) {
            webView.evaluateJavascript(
                "if (typeof window.checkIncomingPdf === 'function') { window.checkIncomingPdf(); }",
                null
            )
        }
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type

        val uri: Uri? = when (action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: intent.data
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM) ?: intent.data
                }
            }
            else -> null
        }

        if (uri == null) return

        // Verify if it is a PDF or generic file view intent
        val isPdf = type?.equals("application/pdf", ignoreCase = true) == true ||
                uri.toString().endsWith(".pdf", ignoreCase = true) ||
                uri.lastPathSegment?.endsWith(".pdf", ignoreCase = true) == true ||
                try {
                    contentResolver.getType(uri)?.equals("application/pdf", ignoreCase = true) == true
                } catch (_: Exception) {
                    false
                }

        if (!isPdf && action != Intent.ACTION_VIEW) return

        copyPdfToCache(uri)
    }

    private fun copyPdfToCache(uri: Uri) {
        incomingPdfError = null
        hasIncomingPdf = false

        // Extract display name
        var resolvedName: String? = null
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx != -1 && cursor.moveToFirst()) {
                        resolvedName = cursor.getString(nameIdx)
                    }
                }
            } catch (_: Exception) {
                // Ignore cursor query error and fall back
            }
        }
        if (resolvedName.isNullOrBlank()) {
            resolvedName = uri.lastPathSegment?.let { segment ->
                val lastSlash = segment.lastIndexOf('/')
                if (lastSlash != -1) segment.substring(lastSlash + 1) else segment
            }
        }
        if (resolvedName.isNullOrBlank()) {
            resolvedName = "Document.pdf"
        } else if (!resolvedName!!.endsWith(".pdf", ignoreCase = true)) {
            resolvedName = "$resolvedName.pdf"
        }
        incomingPdfName = resolvedName

        // Safely open stream using ContentResolver with permission handling
        try {
            val inputStream: InputStream = try {
                contentResolver.openInputStream(uri)
            } catch (e: Exception) {
                if (uri.scheme == "file" && uri.path != null) {
                    FileInputStream(File(uri.path!!))
                } else {
                    throw e
                }
            } ?: throw FileNotFoundException("Unable to open input stream for: $uri")

            val safePrefix = "open_with_" + System.currentTimeMillis()
            val targetFile = File(cacheDir, "$safePrefix.pdf")

            // Clean up any old temporary open_with_ files
            cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("open_with_") && file.name.endsWith(".pdf")) {
                    file.delete()
                }
            }

            inputStream.use { input ->
                targetFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            if (!targetFile.exists() || targetFile.length() == 0L) {
                targetFile.delete()
                incomingPdfError = "The selected PDF file is empty or could not be read."
                hasIncomingPdf = true
                return
            }

            currentTempFile = targetFile
            incomingPdfSize = targetFile.length()
            hasIncomingPdf = true
        } catch (e: SecurityException) {
            incomingPdfError = "Permission denied to read this PDF file."
            hasIncomingPdf = true
        } catch (e: FileNotFoundException) {
            incomingPdfError = "The selected PDF file could not be found or opened."
            hasIncomingPdf = true
        } catch (e: Exception) {
            incomingPdfError = "Failed to open PDF: ${e.localizedMessage ?: "File inaccessible"}"
            hasIncomingPdf = true
        }
    }

    // ================= Biometric lock =================

    private fun notifyBiometricResult(success: Boolean, code: Int, msg: String) {
        biometricActive = false
        runOnUiThread {
            webView.evaluateJavascript(
                "if (typeof window.onBiometricResult === 'function') { window.onBiometricResult($success, $code, \"${jsonEscape(msg)}\"); }",
                null
            )
        }
    }

    private fun startBiometric(title: String, subtitle: String) {
        if (biometricActive) return
        biometricActive = true
        try {
            val callback = object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    notifyBiometricResult(true, 0, "")
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    notifyBiometricResult(false, errorCode, errString.toString())
                }
                // onAuthenticationFailed (a non-matching finger) is ignored: the prompt stays open.
            }
            val builder = BiometricPrompt.PromptInfo.Builder()
                .setTitle(if (title.isBlank()) "Unlock Docera" else title)
            if (subtitle.isNotBlank()) builder.setSubtitle(subtitle)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Biometrics, with the phone's own PIN/pattern as a fallback so the user can never be locked out.
                builder.setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_WEAK or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            } else {
                builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                    .setNegativeButtonText("Cancel")
            }
            BiometricPrompt(this, ContextCompat.getMainExecutor(this), callback)
                .authenticate(builder.build())
        } catch (e: Exception) {
            notifyBiometricResult(false, -1, e.localizedMessage ?: "Biometric error")
        }
    }

    inner class AndroidBiometricBridge {
        /** "ok" | "none_enrolled" | "no_hardware" | "unavailable" */
        @JavascriptInterface
        fun status(): String {
            return try {
                when (BiometricManager.from(this@MainActivity)
                    .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
                    BiometricManager.BIOMETRIC_SUCCESS -> "ok"
                    BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "none_enrolled"
                    BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "no_hardware"
                    else -> "unavailable"
                }
            } catch (_: Exception) {
                "unavailable"
            }
        }

        /** Result comes back through window.onBiometricResult(success, code, message). */
        @JavascriptInterface
        fun authenticate(title: String, subtitle: String) {
            runOnUiThread { startBiometric(title, subtitle) }
        }
    }

    // ================= App Blocker =================

    private fun isBlockerServiceEnabled(): Boolean = try {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == AppBlockService::class.java.name
        }
    } catch (_: Exception) {
        false
    }

    /**
     * "running"        - Android has the service bound and working
     * "on_not_running" - switched on in Accessibility settings but not running (crashed / killed by the phone)
     * "off"            - not switched on
     */
    private fun blockerServiceState(): String {
        if (BlockGuardService.ready(this)) return "running"
        if (AppBlockService.connected || isBlockerServiceEnabled()) return "running"
        return try {
            val me = ComponentName(this, AppBlockService::class.java)
            val raw = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            val on = raw?.split(':')?.any { ComponentName.unflattenFromString(it) == me } == true
            if (on) "on_not_running" else "off"
        } catch (_: Exception) {
            "off"
        }
    }

    inner class AndroidBlockerBridge {

        @JavascriptInterface
        fun serviceEnabled(): Boolean = blockerServiceState() == "running"

        @JavascriptInterface
        fun serviceState(): String = blockerServiceState()

        /** Last crash stack trace (top part) if the app ever crashed, else "". */
        @JavascriptInterface
        fun getLastCrash(): String = try {
            getSharedPreferences("docera_diag", MODE_PRIVATE).getString("crash", "") ?: ""
        } catch (_: Exception) {
            ""
        }

        /** JSON {usage, overlay, a11y}: which blocker permissions are already given. */
        @JavascriptInterface
        fun perms(): String = try {
            JSONObject()
                .put("usage", BlockGuardService.hasUsageAccess(this@MainActivity))
                .put("overlay", BlockGuardService.hasOverlay(this@MainActivity))
                .put("a11y", AppBlockService.connected || isBlockerServiceEnabled())
                .toString()
        } catch (_: Throwable) {
            "{}"
        }

        @JavascriptInterface
        fun openUsageAccess() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    } catch (_: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun openOverlaySettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun requestNotifications() {
            runOnUiThread {
                try {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9101)
                    }
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
        }

        /** Asks Android to let Docera run in the background (needed on phones that kill background apps). */
        @JavascriptInterface
        fun requestIgnoreBattery() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (_: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {
                }
            }
        }

        /** JSON [{p: package, n: label}] of installed apps that can be blocked. */
        @JavascriptInterface
        fun getApps(): String {
            val pm = packageManager
            val protectedSet = BlockStore.protectedPackages(this@MainActivity)
            val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val items = ArrayList<Pair<String, String>>()
            try {
                for (ri in pm.queryIntentActivities(launch, 0)) {
                    val p = ri.activityInfo.packageName
                    if (p in protectedSet || !seen.add(p)) continue
                    items.add(p to ri.loadLabel(pm).toString())
                }
            } catch (_: Exception) {
            }
            items.sortBy { it.second.lowercase() }
            val ja = JSONArray()
            for ((p, n) in items) ja.put(JSONObject().put("p", p).put("n", n))
            return ja.toString()
        }

        /** Small PNG (base64) of an app's icon, or null. */
        @JavascriptInterface
        fun getIcon(pkg: String): String? {
            return try {
                val bmp = packageManager.getApplicationIcon(pkg).toBitmap(72, 72, Bitmap.Config.ARGB_8888)
                val bos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
                Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            } catch (_: Exception) {
                null
            }
        }

        /** JSON [{p, n, rem (ms left), dur (ms)}] of blocks that are running now. */
        @JavascriptInterface
        fun getBlocks(): String {
            val pm = packageManager
            val ja = JSONArray()
            for ((e, rem) in BlockStore.active(this@MainActivity)) {
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(e.pkg, 0)).toString()
                } catch (_: Exception) {
                    e.pkg
                }
                ja.put(
                    JSONObject().put("p", e.pkg).put("n", label).put("rem", rem).put("dur", e.durationMs)
                        .put("emMin", e.emMin).put("emMax", e.emMax).put("emUsed", e.emUsed)
                        .put("pass", BlockStore.passLeftMs(this@MainActivity, e))
                )
            }
            return ja.toString()
        }

        /**
         * Blocks the given apps for [minutes]. Returns "ok", "no_service", "bad_duration",
         * "bad_input" or "no_apps". There is intentionally no function to stop a block.
         */
        @JavascriptInterface
        fun startBlock(pkgsJson: String, minutes: Int): String {
            if (blockerServiceState() != "running") return "no_service"
            if (minutes < 1 || minutes > BlockStore.MAX_MINUTES) return "bad_duration"
            val protectedSet = BlockStore.protectedPackages(this@MainActivity)
            val pkgs = try {
                val a = JSONArray(pkgsJson)
                (0 until a.length()).map { a.getString(it) }.filter { it.isNotBlank() && it !in protectedSet }
            } catch (_: Exception) {
                return "bad_input"
            }
            if (pkgs.isEmpty()) return "no_apps"
            BlockStore.add(this@MainActivity, pkgs, minutes.toLong() * 60_000L)
            if (BlockGuardService.ready(this@MainActivity)) BlockGuardService.start(this@MainActivity)
            return "ok"
        }
    }

    // Opens a mailto:/https:// (WhatsApp, Play Store, etc.) link in the user's real
    // Gmail/WhatsApp/Play Store app, since the WebView itself can't handle those.
    inner class AndroidLinkBridge {
        @JavascriptInterface
        fun openExternal(url: String) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: Exception) {
                // No app installed that can handle this link — silently ignore.
            }
        }
    }

    inner class AndroidPdfBridge {
        @JavascriptInterface
        fun hasIncomingPdf(): Boolean {
            return this@MainActivity.hasIncomingPdf
        }

        @JavascriptInterface
        fun getIncomingPdfError(): String? {
            return this@MainActivity.incomingPdfError
        }

        @JavascriptInterface
        fun getIncomingPdfInfo(): String? {
            if (!this@MainActivity.hasIncomingPdf || this@MainActivity.incomingPdfError != null) return null
            val name = this@MainActivity.incomingPdfName ?: "Document.pdf"
            val size = this@MainActivity.incomingPdfSize
            val escapedName = name.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
            return """{"name":"$escapedName","size":$size}"""
        }

        @JavascriptInterface
        fun readPdfChunk(offset: Int, length: Int): String? {
            val file = this@MainActivity.currentTempFile ?: return null
            if (!file.exists() || offset >= file.length() || offset < 0) return null
            return try {
                RandomAccessFile(file, "r").use { raf ->
                    raf.seek(offset.toLong())
                    val remaining = file.length() - offset
                    val toRead = if (remaining < length) remaining.toInt() else length
                    val buffer = ByteArray(toRead)
                    val bytesRead = raf.read(buffer)
                    if (bytesRead > 0) {
                        Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP)
                    } else {
                        null
                    }
                }
            } catch (_: Exception) {
                null
            }
        }

        @JavascriptInterface
        fun clearIncomingPdf() {
            this@MainActivity.hasIncomingPdf = false
            this@MainActivity.incomingPdfError = null
        }
    }

    // ================= Auto-import from device storage (no manual import needed) =================

    private fun notifyFolderPickResult(success: Boolean, folderName: String?) {
        runOnUiThread {
            val nameArg = if (folderName != null) "\"${jsonEscape(folderName)}\"" else "null"
            webView.evaluateJavascript(
                "if (typeof window.onFolderAdded === 'function') { window.onFolderAdded($success, $nameArg); }",
                null
            )
        }
    }

    private fun notifyAllFilesAccessChanged() {
        val granted = hasAllFilesAccessInternal()
        runOnUiThread {
            webView.evaluateJavascript(
                "if (typeof window.onAllFilesAccessChanged === 'function') { window.onAllFilesAccessChanged($granted); }",
                null
            )
        }
    }

    private fun hasAllFilesAccessInternal(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun folderDisplayName(uri: Uri): String {
        return try {
            val last = uri.lastPathSegment?.let { Uri.decode(it) } ?: return uri.toString()
            val afterColon = last.substringAfterLast(':')
            if (afterColon.isBlank()) last else afterColon
        } catch (_: Exception) {
            uri.toString()
        }
    }

    private fun jsonEscape(s: String): String = s
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")

    /**
     * Recursively lists PDF files under a Storage Access Framework folder tree,
     * without copying any bytes. [treeRootUri] stays the same across recursive calls
     * (it identifies the granted tree); only [docId] changes as we descend.
     */
    private fun scanTreeForPdfs(
        treeRootUri: Uri,
        docId: String,
        depth: Int,
        dirPath: String,
        emit: (key: String, name: String, size: Long, lastModified: Long, source: String, folder: String) -> Unit
    ) {
        if (depth > MAX_FOLDER_DEPTH) return
        val childrenUri = try {
            DocumentsContract.buildChildDocumentsUriUsingTree(treeRootUri, docId)
        } catch (_: Exception) {
            return
        }
        try {
            contentResolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                ),
                null, null, null
            )?.use { cursor ->
                var count = 0
                while (cursor.moveToNext() && count < MAX_ENTRIES_PER_FOLDER) {
                    count++
                    val childDocId = cursor.getString(0) ?: continue
                    val name = cursor.getString(1) ?: continue
                    val mime = cursor.getString(2) ?: ""
                    val size = if (cursor.isNull(3)) 0L else cursor.getLong(3)
                    val lastMod = if (cursor.isNull(4)) 0L else cursor.getLong(4)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (!name.startsWith(".")) {
                            scanTreeForPdfs(treeRootUri, childDocId, depth + 1, dirPath + "/" + name, emit)
                        }
                    } else if (mime.equals("application/pdf", ignoreCase = true) ||
                        name.endsWith(".pdf", ignoreCase = true)
                    ) {
                        val docUri = DocumentsContract.buildDocumentUriUsingTree(treeRootUri, childDocId)
                        emit(docUri.toString(), name, size, lastMod, "folder", dirPath)
                    }
                }
            }
        } catch (_: Exception) {
            // A folder that became inaccessible (revoked permission, unmounted SD card, etc.)
            // is skipped instead of crashing the whole scan.
        }
    }

    inner class AndroidStorageBridge {

        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        )
                    }
                    folderPickerLauncher.launch(intent)
                } catch (_: Exception) {
                    notifyFolderPickResult(false, null)
                }
            }
        }

        @JavascriptInterface
        fun listFolders(): String {
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val uris = prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()
            val persisted = try {
                contentResolver.persistedUriPermissions
            } catch (_: Exception) {
                emptyList()
            }
            val sb = StringBuilder("[")
            var first = true
            for (u in uris) {
                val uri = try {
                    Uri.parse(u)
                } catch (_: Exception) {
                    continue
                }
                val stillGranted = persisted.any { it.uri == uri && it.isReadPermission }
                if (!stillGranted) continue
                if (!first) sb.append(",")
                first = false
                sb.append("{\"uri\":\"").append(jsonEscape(u))
                    .append("\",\"name\":\"").append(jsonEscape(folderDisplayName(uri)))
                    .append("\"}")
            }
            sb.append("]")
            return sb.toString()
        }

        @JavascriptInterface
        fun removeFolder(uriString: String) {
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val current = (prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()).toMutableSet()
            current.remove(uriString)
            prefs.edit().putStringSet(KEY_FOLDER_URIS, current).apply()
            try {
                contentResolver.releasePersistableUriPermission(
                    Uri.parse(uriString),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Already released or never granted — safe to ignore.
            }
        }

        @JavascriptInterface
        fun hasAllFilesAccess(): Boolean = hasAllFilesAccessInternal()

        /** Whole-storage scan is available only while MANAGE_EXTERNAL_STORAGE is declared in the manifest. */
        @JavascriptInterface
        fun allFilesScanSupported(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.R || try {
                packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
                    .requestedPermissions?.contains(Manifest.permission.MANAGE_EXTERNAL_STORAGE) == true
            } catch (_: Exception) { false }

        @JavascriptInterface
        fun requestAllFilesAccess() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:$packageName")
                        }
                        allFilesAccessLauncher.launch(intent)
                    } catch (_: Exception) {
                        try {
                            allFilesAccessLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                        } catch (_: Exception) {
                            notifyAllFilesAccessChanged()
                        }
                    }
                } else {
                    legacyStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
        }

        /**
         * Finds every PDF already reachable on the device — from picked folders and, if granted,
         * the whole shared storage — WITHOUT copying any file. Returns a JSON array of
         * {key, name, size, lastModified, source}. "key" is later passed to readExternalChunk().
         */
        private val scanRunning = java.util.concurrent.atomic.AtomicBoolean(false)

        // ---- covers for discovered PDFs: page 1 rendered straight from the file / document, one at a time on a background thread ----
        private val coverExec = java.util.concurrent.Executors.newSingleThreadExecutor()

        @JavascriptInterface
        fun coverAsync(id: String, key: String, widthPx: Int) {
            coverExec.execute {
                val json = try {
                    renderCoverJson(key, widthPx.coerceIn(120, 800))
                } catch (e: Throwable) {
                    JSONObject().put("err", e.javaClass.simpleName + ": " + (e.message ?: "")).toString()
                }
                runOnUiThread {
                    try {
                        webView.evaluateJavascript(
                            "if(window.__coverDone){window.__coverDone(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")}", null
                        )
                    } catch (_: Throwable) {
                    }
                }
            }
        }

        private fun renderCoverJson(key: String, widthPx: Int): String {
            val pfd: android.os.ParcelFileDescriptor = if (key.startsWith("content://")) {
                contentResolver.openFileDescriptor(Uri.parse(key), "r") ?: throw FileNotFoundException("cannot open file")
            } else {
                android.os.ParcelFileDescriptor.open(File(key), android.os.ParcelFileDescriptor.MODE_READ_ONLY)
            }
            try {
                val renderer = android.graphics.pdf.PdfRenderer(pfd)
                try {
                    val n = renderer.pageCount
                    if (n < 1) throw IllegalStateException("empty PDF")
                    val page = renderer.openPage(0)
                    try {
                        val w = widthPx
                        val h = (page.height.toFloat() / page.width.coerceAtLeast(1) * w).toInt().coerceIn(1, 4000)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val bos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
                        bmp.recycle()
                        return JSONObject().put("n", n)
                            .put("b64", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)).toString()
                    } finally {
                        try { page.close() } catch (_: Throwable) {}
                    }
                } finally {
                    try { renderer.close() } catch (_: Throwable) {}
                }
            } finally {
                try { pfd.close() } catch (_: Throwable) {}
            }
        }

        /**
         * Same scan as scanForPdfs(), but on a background thread. The JS side used to freeze while the
         * storage was walked; now the result is pushed back through window.__pdfScanDone(json).
         */
        @JavascriptInterface
        fun scanForPdfsAsync() {
            if (!scanRunning.compareAndSet(false, true)) return
            Thread {
                val json = try { scanForPdfs() } catch (_: Throwable) { "[]" }
                scanRunning.set(false)
                runOnUiThread {
                    try {
                        webView.evaluateJavascript(
                            "if(window.__pdfScanDone){window.__pdfScanDone(" + JSONObject.quote(json) + ")}", null
                        )
                    } catch (_: Throwable) {
                    }
                }
            }.start()
        }

        @JavascriptInterface
        fun scanForPdfs(): String {
            val out = StringBuilder("[")
            var first = true
            val emit: (String, String, Long, Long, String, String) -> Unit = { key, name, size, lastMod, source, folder ->
                if (!first) out.append(",")
                first = false
                out.append("{\"key\":\"").append(jsonEscape(key))
                    .append("\",\"name\":\"").append(jsonEscape(name))
                    .append("\",\"size\":").append(size)
                    .append(",\"lastModified\":").append(lastMod)
                    .append(",\"source\":\"").append(source)
                    .append("\",\"folder\":\"").append(jsonEscape(folder)).append("\"}")
            }

            // 1) Folders the user explicitly picked (works on every Android version, minimal permission)
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val treeUris = prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()
            val persisted = try {
                contentResolver.persistedUriPermissions
            } catch (_: Exception) {
                emptyList()
            }
            for (u in treeUris) {
                val treeUri = try {
                    Uri.parse(u)
                } catch (_: Exception) {
                    continue
                }
                if (persisted.none { it.uri == treeUri && it.isReadPermission }) continue
                try {
                    val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
                    // e.g. "primary:Download/Telegram" -> "Download/Telegram" (folder name used for grouping)
                    scanTreeForPdfs(treeUri, rootDocId, 0, rootDocId.substringAfter(':'), emit)
                } catch (_: Exception) {
                    // Skip this folder; never crash the whole scan for one bad entry.
                }
            }

            // 2) Whole-storage scan, only if the user granted "All files access"
            if (hasAllFilesAccessInternal()) {
                try {
                    var scanned = 0
                    val deadline = System.currentTimeMillis() + SCAN_BUDGET_MS
                    val seen = HashSet<String>()
                    val prioritized = HashSet<String>()
                    fun walk(dir: File, depth: Int) {
                        if (depth > MAX_FOLDER_DEPTH || scanned >= MAX_TOTAL_ALL_FILES_SCAN || System.currentTimeMillis() > deadline) return
                        val path = dir.absolutePath
                        // Android 11+ still blocks other apps' private folders even with
                        // "All files access" — skip them so we don't waste time on errors.
                        if (path.endsWith("/Android/data") || path.endsWith("/Android/obb")) return
                        // Folders already walked in the priority pass below are not walked twice.
                        if (depth > 0 && prioritized.contains(path)) return
                        val children = try {
                            dir.listFiles()
                        } catch (_: Exception) {
                            null
                        } ?: return
                        for (f in children) {
                            if (scanned >= MAX_TOTAL_ALL_FILES_SCAN) return
                            scanned++
                            if (f.isDirectory) {
                                if (!f.name.startsWith(".") && !isMediaOnlyDir(f.name)) walk(f, depth + 1)
                            } else if (f.name.endsWith(".pdf", ignoreCase = true)) {
                                if (seen.add(f.absolutePath)) {
                                    // 5th/6th argument: where it came from (library groups by this folder)
                                    emit(f.absolutePath, f.name, f.length(), f.lastModified(), "allfiles", path)
                                }
                            }
                        }
                    }
                    val root = Environment.getExternalStorageDirectory()
                    // Download / Telegram / WhatsApp live in a few well-known places. Scan them first so the
                    // overall entry limit of the whole-phone walk can never cut them off.
                    // (Android/media is last: it is the biggest one and holds Telegram's own "Telegram Documents" folder too)
                    for (rel in listOf("Download", "Documents", "Telegram", "WhatsApp", "Bluetooth", "Android/media")) {
                        val d = File(root, rel)
                        if (!d.isDirectory) continue
                        scanned = 0
                        walk(d, rel.count { it == '/' } + 1)
                        prioritized.add(d.absolutePath)
                    }
                    scanned = 0
                    walk(root, 0)
                } catch (_: Exception) {
                    // Never let a storage scan crash the app.
                }
            }

            out.append("]")
            return out.toString()
        }

        /**
         * Reads one chunk of an already-discovered PDF directly from its source
         * (content:// document or raw filesystem path) — the file is never duplicated
         * into app storage. Mirrors AndroidPdfBridge.readPdfChunk()'s chunking approach.
         */
        @JavascriptInterface
        fun readExternalChunk(key: String, offset: Int, length: Int): String? {
            return try {
                if (key.startsWith("content://")) {
                    val uri = Uri.parse(key)
                    contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                        FileInputStream(pfd.fileDescriptor).use { input ->
                            var skippedTotal = 0L
                            while (skippedTotal < offset) {
                                val skipped = input.skip((offset - skippedTotal))
                                if (skipped <= 0) break
                                skippedTotal += skipped
                            }
                            if (skippedTotal < offset) return null
                            val buffer = ByteArray(length)
                            val bytesRead = input.read(buffer)
                            if (bytesRead > 0) Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP) else null
                        }
                    }
                } else {
                    val file = File(key)
                    if (!file.exists() || offset >= file.length() || offset < 0) return null
                    RandomAccessFile(file, "r").use { raf ->
                        raf.seek(offset.toLong())
                        val remaining = file.length() - offset
                        val toRead = if (remaining < length) remaining.toInt() else length
                        val buffer = ByteArray(toRead)
                        val bytesRead = raf.read(buffer)
                        if (bytesRead > 0) Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP) else null
                    }
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    /**
     * Saves a file straight into the device's Downloads folder. Added because the WebView's
     * usual `<a download>` click on a blob: URL does not actually save anything on Android
     * (WebView has no download handler for blob: links) — files "downloaded" from the PDF
     * viewer or note export just silently disappeared. This bridge writes real bytes to
     * Downloads via MediaStore (Android 10+) or, on very old Android, directly to the
     * public Downloads directory, so a Toast/"Saved" confirmation is honest.
     */
    inner class AndroidSaveBridge {
        // ---- staged (chunked) files: big PDFs are sent in small base64 pieces, never as one giant string ----
        private val staged: HashMap<String, Pair<File, String>> get() = stagedFiles

        /** Starts a temp file in the app cache; returns its id. */
        @JavascriptInterface
        fun beginFile(filename: String, mime: String): String {
            return try {
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                val safe = filename.replace(Regex("[\\\\/:*?\"<>|]+"), "_").ifBlank { "docera-file" }
                val id = System.nanoTime().toString()
                val f = File(File(dir, id).apply { mkdirs() }, safe)
                f.writeBytes(ByteArray(0))
                synchronized(staged) { staged[id] = f to mime.ifBlank { "application/octet-stream" } }
                id
            } catch (e: Exception) {
                "ERR:" + (e.localizedMessage ?: "begin failed")
            }
        }

        /** Appends one base64 piece. Returns "ok" or an error text. */
        @JavascriptInterface
        fun appendChunk(id: String, b64: String): String {
            return try {
                val f = synchronized(staged) { staged[id]?.first } ?: return "unknown file"
                FileOutputStream(f, true).use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "write failed"
            }
        }

        /** Copies the staged file into Downloads and drops the temp copy. Returns "ok" or an error text. */
        @JavascriptInterface
        fun finishSave(id: String): String {
            val (f, mime) = synchronized(staged) { staged.remove(id) } ?: return "unknown file"
            return try {
                val bytes = f.readBytes()
                val r = saveBase64(Base64.encodeToString(bytes, Base64.NO_WRAP), f.name, mime)
                r
            } catch (e: Exception) {
                e.localizedMessage ?: "Save failed"
            } finally {
                try { f.parentFile?.deleteRecursively() } catch (_: Exception) {}
            }
        }

        /** Opens the Android share sheet for one or more staged files (ids separated by commas). */
        @JavascriptInterface
        fun shareStaged(ids: String, title: String): String {
            return try {
                val items = ids.split(",").mapNotNull { synchronized(staged) { staged[it.trim()] } }
                if (items.isEmpty()) return "no files"
                val uris = ArrayList<Uri>()
                for ((f, _) in items) uris.add(FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f))
                val mimes = items.map { it.second }.distinct()
                val mime = if (mimes.size == 1) mimes[0] else "*/*"
                val send = if (uris.size == 1) {
                    Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
                } else {
                    Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
                send.type = mime
                if (title.isNotBlank()) send.putExtra(Intent.EXTRA_SUBJECT, title)
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(send, title.ifBlank { null })
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                runOnUiThread {
                    try { startActivity(chooser) } catch (_: Exception) {}
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Share failed"
            }
        }

        /** Opens the file manager's "Save as" screen for a staged file; the result comes back via window.__saveAsDone(ok,msg). */
        @JavascriptInterface
        fun saveAs(id: String, filename: String, mime: String): String {
            return try {
                if (synchronized(staged) { staged[id] } == null) return "unknown file"
                pendingSaveId = id
                runOnUiThread {
                    try {
                        saveAsLauncher.launch(Pair(filename.ifBlank { "docera-file" }, mime))
                    } catch (e: Exception) {
                        pendingSaveId = null
                    }
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Could not open the file manager"
            }
        }

        /** "Open with": lets the user pick ANOTHER app (not Docera) to view the staged file. */
        @JavascriptInterface
        fun openStaged(id: String, title: String): String {
            return try {
                val (f, mime) = synchronized(staged) { staged[id] } ?: return "unknown file"
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                val view = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    clipData = ClipData.newRawUri("file", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(view, title.ifBlank { null }).apply {
                    clipData = ClipData.newRawUri("file", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    // hide Docera itself from the list - the point is to open the PDF somewhere else
                    putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(this@MainActivity, MainActivity::class.java)))
                }
                runOnUiThread {
                    try { startActivity(chooser) } catch (_: ActivityNotFoundException) {} catch (_: Exception) {}
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Could not open"
            }
        }

        /** Share plain text (a note) through the Android share sheet. */
        @JavascriptInterface
        fun shareText(text: String, title: String): String {
            return try {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    if (title.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, title)
                }
                runOnUiThread {
                    try { startActivity(Intent.createChooser(send, title.ifBlank { null })) } catch (_: Exception) {}
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Share failed"
            }
        }

        /** Old shared temp files are removed when the app starts a new export. */
        @JavascriptInterface
        fun cleanTemp() {
            try {
                val dir = File(cacheDir, "shared")
                val keep = synchronized(staged) { staged.values.map { it.first.parentFile?.name }.toSet() }
                dir.listFiles()?.forEach { if (it.name !in keep) it.deleteRecursively() }
            } catch (_: Exception) {}
        }

        /** Returns "ok" on success, or an error message string. */
        @JavascriptInterface
        fun saveBase64(base64: String, filename: String, mime: String): String {
            return try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val safeName = filename.ifBlank { "docera-file" }
                val safeMime = mime.ifBlank { "application/octet-stream" }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                        put(MediaStore.MediaColumns.MIME_TYPE, safeMime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: return "Could not create file"
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: return "Could not open file for writing"
                    "ok"
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!dir.exists()) dir.mkdirs()
                    var out = File(dir, safeName)
                    if (out.exists()) {
                        val dot = safeName.lastIndexOf('.')
                        val base = if (dot > 0) safeName.substring(0, dot) else safeName
                        val ext = if (dot > 0) safeName.substring(dot) else ""
                        var i = 1
                        while (out.exists()) {
                            out = File(dir, "$base ($i)$ext")
                            i++
                        }
                    }
                    out.writeBytes(bytes)
                    // Make it show up immediately in the Downloads / Files app and Media Store.
                    try {
                        sendBroadcast(
                            Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(out))
                        )
                    } catch (_: Exception) {
                    }
                    "ok"
                }
            } catch (e: Exception) {
                e.localizedMessage ?: "Save failed"
            }
        }
    }

    /**
     * archive.org: search + download, done natively (a WebView fetch to another site is blocked by CORS).
     * Only items that are free to download are offered; lending-only (borrow / DRM) books are left out.
     */
    inner class AndroidArchiveBridge {
        private val exec = java.util.concurrent.Executors.newFixedThreadPool(2)
        private val cancelled = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
        private val ua = "Docera/1.0 (Android PDF reader)"

        private fun callJs(code: String) {
            runOnUiThread {
                try { webView.evaluateJavascript(code, null) } catch (_: Throwable) {}
            }
        }

        private fun open(url: String): java.net.HttpURLConnection {
            val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", ua)
            return c
        }

        private fun getText(url: String): String {
            val c = open(url)
            try {
                if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                try { c.disconnect() } catch (_: Throwable) {}
            }
        }

        private fun flat(v: Any?): String = when {
            v == null || v == JSONObject.NULL -> ""
            v is JSONArray -> (0 until v.length()).joinToString(", ") { v.optString(it) }
            else -> v.toString()
        }

        @JavascriptInterface
        fun search(reqId: String, query: String) {
            exec.execute {
                val out = try {
                    val words = query.trim().split(Regex("\\s+"))
                        .map { it.replace(Regex("[^\\p{L}\\p{N}'-]"), "") }
                        .filter { it.isNotEmpty() }.take(8)
                    if (words.isEmpty()) throw IllegalArgumentException("Type a book name")
                    fun query(withFormat: Boolean): JSONArray {
                        val q = "(" + words.joinToString(" AND ") + ") AND mediatype:texts" +
                            (if (withFormat) " AND format:pdf" else "") + " AND NOT access-restricted-item:true"
                        val url = "https://archive.org/advancedsearch.php?q=" + java.net.URLEncoder.encode(q, "UTF-8") +
                            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=year&fl%5B%5D=downloads&rows=30&page=1&output=json"
                        return JSONObject(getText(url)).getJSONObject("response").getJSONArray("docs")
                    }
                    // PDF-only first; if that finds nothing, try again without the format filter (the download step still looks for a PDF)
                    var docs = query(true)
                    if (docs.length() == 0) docs = query(false)
                    val arr = JSONArray()
                    for (i in 0 until docs.length()) {
                        val d = docs.getJSONObject(i)
                        val id = d.optString("identifier")
                        if (id.isBlank()) continue
                        arr.put(
                            JSONObject().put("id", id).put("title", flat(d.opt("title")).ifBlank { id })
                                .put("creator", flat(d.opt("creator"))).put("year", flat(d.opt("year")))
                        )
                    }
                    JSONObject().put("items", arr).toString()
                } catch (e: Throwable) {
                    JSONObject().put("err", (e.message ?: e.javaClass.simpleName)).toString()
                }
                callJs("if(window.__arcSearchDone)window.__arcSearchDone(" + JSONObject.quote(reqId) + "," + JSONObject.quote(out) + ")")
            }
        }

        @JavascriptInterface
        fun cancel(reqId: String) { cancelled[reqId] = true }

        /** Download and keep the PDF in Downloads/Docera. */
        @JavascriptInterface
        fun download(reqId: String, identifier: String, title: String) = startJob(reqId, identifier, title, true)

        /** "Read": fetch the PDF into the app's own private storage (not Downloads) so it can be opened in the viewer. */
        @JavascriptInterface
        fun read(reqId: String, identifier: String, title: String) = startJob(reqId, identifier, title, false)

        private fun privDir(): File = File(filesDir, "archive").also { if (!it.exists()) it.mkdirs() }
        private fun isPriv(f: File): Boolean = try {
            f.canonicalPath.startsWith(privDir().canonicalPath + File.separator)
        } catch (_: Throwable) { false }

        /** Moves a private "read" copy into Downloads/Docera (no new download needed). Answers through __arcDone. */
        @JavascriptInterface
        fun keep(reqId: String, key: String, name: String) {
            exec.execute {
                val out = try {
                    val f = File(key)
                    if (!f.exists() || !isPriv(f)) throw IllegalStateException("The saved copy was not found.")
                    val safe = name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), " ").trim().ifBlank { "Book.pdf" }
                    val fileName = if (safe.endsWith(".pdf", true)) safe else "$safe.pdf"
                    val saved = saveToDownloads(f, fileName)
                    JSONObject().put("ok", true).put("key", saved).put("name", fileName).put("size", f.length()).toString()
                } catch (e: Throwable) {
                    JSONObject().put("err", (e.message ?: e.javaClass.simpleName)).toString()
                }
                callJs("if(window.__arcDone)window.__arcDone(" + JSONObject.quote(reqId) + "," + JSONObject.quote(out) + ")")
            }
        }

        /** Deletes a private "read" copy (only files inside the app's own archive folder). */
        @JavascriptInterface
        fun dropPrivate(key: String): String {
            return try {
                val f = File(key)
                if (isPriv(f)) { f.delete(); "ok" } else "not private"
            } catch (e: Throwable) { e.message ?: "error" }
        }

        private fun startJob(reqId: String, identifier: String, title: String, toDownloads: Boolean) {
            cancelled.remove(reqId)
            exec.execute {
                var tmp: File? = null
                val out = try {
                    val enc = java.net.URLEncoder.encode(identifier, "UTF-8")
                    val meta = JSONObject(getText("https://archive.org/metadata/$enc"))
                    val md = meta.optJSONObject("metadata")
                    if (md != null && md.optString("access-restricted-item") == "true")
                        throw IllegalStateException("This book is lending-only on archive.org, it cannot be downloaded.")
                    val files = meta.optJSONArray("files") ?: throw IllegalStateException("No files found for this book.")
                    var best: String? = null
                    var bestScore = -1
                    for (i in 0 until files.length()) {
                        val f = files.getJSONObject(i)
                        val name = f.optString("name")
                        val fmt = f.optString("format")
                        if (f.optString("private") == "true") continue
                        if (!name.endsWith(".pdf", true) && !fmt.contains("PDF", true)) continue
                        val score = when {
                            fmt.equals("Text PDF", true) -> 3
                            fmt.equals("Image Container PDF", true) -> 2
                            else -> 1
                        }
                        if (score > bestScore) { bestScore = score; best = name }
                    }
                    val fileOnArchive = best ?: throw IllegalStateException("This book has no PDF file.")
                    val url = "https://archive.org/download/$enc/" +
                        fileOnArchive.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                    val c = open(url)
                    val file = File(cacheDir, "arc_" + reqId.filter { it.isLetterOrDigit() } + ".pdf")
                    tmp = file
                    var got = 0L
                    try {
                        if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
                        val total = c.contentLengthLong
                        var last = 0L
                        var first = true
                        c.inputStream.use { input ->
                            java.io.FileOutputStream(file).use { os ->
                                val buf = ByteArray(64 * 1024)
                                while (true) {
                                    if (cancelled[reqId] == true) throw java.io.InterruptedIOException("cancelled")
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    if (first) {
                                        first = false
                                        if (n < 4 || buf[0] != '%'.code.toByte() || buf[1] != 'P'.code.toByte() ||
                                            buf[2] != 'D'.code.toByte() || buf[3] != 'F'.code.toByte()
                                        ) throw IllegalStateException("archive.org did not send a PDF (the book may need a login).")
                                    }
                                    os.write(buf, 0, n)
                                    got += n
                                    val now = System.currentTimeMillis()
                                    if (now - last > 300) {
                                        last = now
                                        callJs("if(window.__arcProg)window.__arcProg(" + JSONObject.quote(reqId) + "," + got + "," + total + ")")
                                    }
                                }
                            }
                        }
                    } finally {
                        try { c.disconnect() } catch (_: Throwable) {}
                    }
                    if (got < 100) throw IllegalStateException("The downloaded file is empty.")
                    val safe = title.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), " ").trim()
                        .replace(Regex("\\s+"), " ").take(80).ifBlank { identifier }
                    val fileName = "$safe.pdf"
                    val key = if (toDownloads) saveToDownloads(file, fileName) else {
                        val dest = File(privDir(), identifier.filter { it.isLetterOrDigit() || it == '-' || it == '_' || it == '.' }.ifBlank { "book" } + ".pdf")
                        file.copyTo(dest, overwrite = true)
                        dest.absolutePath
                    }
                    JSONObject().put("ok", true).put("key", key).put("name", fileName).put("size", got).toString()
                } catch (e: java.io.InterruptedIOException) {
                    JSONObject().put("err", "cancelled").toString()
                } catch (e: Throwable) {
                    JSONObject().put("err", (e.message ?: e.javaClass.simpleName)).toString()
                } finally {
                    try { tmp?.delete() } catch (_: Throwable) {}
                    cancelled.remove(reqId)
                }
                callJs("if(window.__arcDone)window.__arcDone(" + JSONObject.quote(reqId) + "," + JSONObject.quote(out) + ")")
            }
        }

        /** Copies the finished download into Downloads/Docera. Returns the real file path when it can be read (same key the
         *  storage scan uses), otherwise the content:// uri. */
        private fun saveToDownloads(src: File, fileName: String): String {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Docera")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw java.io.IOException("Could not create the file in Downloads")
                val os = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Could not write the file")
                os.use { o -> FileInputStream(src).use { it.copyTo(o) } }
                try {
                    contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val path = c.getString(0)
                            if (!path.isNullOrBlank() && File(path).canRead()) return path
                        }
                    }
                } catch (_: Throwable) {}
                return uri.toString()
            }
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Docera")
            if (!dir.exists()) dir.mkdirs()
            var out = File(dir, fileName)
            var i = 1
            while (out.exists()) {
                out = File(dir, fileName.removeSuffix(".pdf") + " ($i).pdf")
                i++
            }
            src.copyTo(out)
            try { sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(out))) } catch (_: Throwable) {}
            return out.absolutePath
        }
    }
}
