package com.docera.parwez

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ext.SdkExtensions
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Native PDF engine. Android's PdfRenderer is PDFium (the Chromium engine) under the hood, so PDFs are
 * rasterised natively: no JS worker, no file:// worker problems, much less memory than pdf.js.
 *
 * The WebView talks to it in two ways:
 *  - [PdfEngineBridge] (window.AndroidPdfEngine): small calls to stage + open a document.
 *  - https://docera.pdf/... requests, answered by [handle] from WebViewClient.shouldInterceptRequest:
 *        /size?k=KEY&p=PAGE     -> JSON [widthPt,heightPt]
 *        /sizes?k=KEY           -> JSON [[w,h],...] for every page
 *        /img?k=KEY&p=PAGE&w=PX -> JPEG of the page, PX pixels wide
 *        /tile?k=KEY&p=PAGE&l&t&r&b&w=PX -> JPEG of just a part of the page (l,t,r,b = 0..1 of the page), PX pixels wide
 *        /sel?k=KEY&p=PAGE&x1&y1&x2&y2 -> JSON {text,rects} of the text between two points (0..1 of the page)
 *        /find?k=KEY&q=TEXT     -> JSON {hits:[{p,r:[[l,t,r,b]..]}]} for every match (rects 0..1 of the page)
 *  Text select/search use PdfRenderer's own PDFium text API (Android 15+ / SDK extension 13+).
 */
object NativePdfEngine {
    const val HOST = "docera.pdf"
    private const val MAX_OPEN = 3
    private const val MAX_PIXELS = 12_000_000L

    private class Doc(val key: String, val file: File, val pfd: ParcelFileDescriptor, val renderer: PdfRenderer) {
        val sizes = HashMap<Int, IntArray>()
        val lock = Any()
    }

    private class Pending(val file: File, val out: FileOutputStream)

    private val docs = LinkedHashMap<String, Doc>()      // access-ordered by hand (see touch())
    private val pending = HashMap<String, Pending>()
    private val global = Any()

    private fun dir(ctx: Context): File = File(ctx.cacheDir, "nativepdf").apply { mkdirs() }

    /** Called once at app start: removes files left over from a previous run. */
    fun cleanup(ctx: Context) {
        synchronized(global) {
            docs.values.forEach { closeDoc(it) }
            docs.clear()
            pending.values.forEach { try { it.out.close() } catch (_: Throwable) {} }
            pending.clear()
        }
        try { dir(ctx).listFiles()?.forEach { it.delete() } } catch (_: Throwable) {}
    }

    private fun safeName(key: String): String =
        Integer.toHexString(key.hashCode()) + "_" + key.length + ".pdf"

    fun has(key: String): Int = synchronized(global) {
        val d = docs[key] ?: return 0
        docs.remove(key); docs[key] = d            // touch: most recently used goes last
        d.renderer.pageCount
    }

    fun begin(ctx: Context, key: String): String = synchronized(global) {
        try {
            pending.remove(key)?.let { try { it.out.close() } catch (_: Throwable) {} }
            val f = File(dir(ctx), safeName(key))
            pending[key] = Pending(f, FileOutputStream(f, false))
            "ok"
        } catch (e: Throwable) {
            "ERR:" + (e.message ?: "begin failed")
        }
    }

    fun append(key: String, b64: String): String = synchronized(global) {
        try {
            val p = pending[key] ?: return "ERR:unknown"
            p.out.write(Base64.decode(b64, Base64.DEFAULT))
            "ok"
        } catch (e: Throwable) {
            "ERR:" + (e.message ?: "write failed")
        }
    }

    /** Opens the staged file. Returns the page count as text, or "ERR:...". */
    fun open(key: String): String = synchronized(global) {
        val p = pending.remove(key) ?: return "ERR:unknown"
        try {
            try { p.out.flush(); p.out.close() } catch (_: Throwable) {}
            docs.remove(key)?.let { closeDoc(it) }
            val pfd = ParcelFileDescriptor.open(p.file, ParcelFileDescriptor.MODE_READ_ONLY)
            val r = try {
                PdfRenderer(pfd)
            } catch (e: Throwable) {
                try { pfd.close() } catch (_: Throwable) {}
                throw e
            }
            docs[key] = Doc(key, p.file, pfd, r)
            while (docs.size > MAX_OPEN) {
                val oldest = docs.keys.first()
                docs.remove(oldest)?.let { closeDoc(it) }
            }
            r.pageCount.toString()
        } catch (e: Throwable) {
            try { p.file.delete() } catch (_: Throwable) {}
            "ERR:" + (e.javaClass.simpleName + ": " + (e.message ?: ""))
        }
    }

    fun close(key: String) = synchronized(global) {
        docs.remove(key)?.let { closeDoc(it) }
        Unit
    }

    private fun closeDoc(d: Doc) {
        synchronized(d.lock) {
            try { d.renderer.close() } catch (_: Throwable) {}
            try { d.pfd.close() } catch (_: Throwable) {}
            try { d.file.delete() } catch (_: Throwable) {}
        }
    }

    private fun docOf(key: String): Doc? = synchronized(global) { docs[key] }

    private fun sizeOf(d: Doc, page: Int): IntArray = synchronized(d.lock) {
        d.sizes[page] ?: run {
            val pg = d.renderer.openPage(page - 1)
            try {
                val s = intArrayOf(pg.width, pg.height)
                d.sizes[page] = s
                s
            } finally {
                pg.close()
            }
        }
    }

    private fun renderJpeg(d: Doc, page: Int, widthPx: Int): ByteArray = synchronized(d.lock) {
        val pg = d.renderer.openPage(page - 1)
        try {
            val pw = pg.width.coerceAtLeast(1)
            val ph = pg.height.coerceAtLeast(1)
            d.sizes[page] = intArrayOf(pw, ph)
            var w = widthPx.coerceIn(16, 8000)
            var h = (w.toLong() * ph / pw).toInt().coerceAtLeast(1)
            if (w.toLong() * h > MAX_PIXELS) {
                val k = Math.sqrt(MAX_PIXELS.toDouble() / (w.toDouble() * h))
                w = (w * k).toInt().coerceAtLeast(16)
                h = (h * k).toInt().coerceAtLeast(1)
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            try {
                bmp.eraseColor(Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                val bos = ByteArrayOutputStream(w * h / 6)
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos)
                bos.toByteArray()
            } finally {
                bmp.recycle()
            }
        } finally {
            pg.close()
        }
    }

    /** Only a part of a page (fractions of the page), drawn at full resolution: this is what keeps zoomed text sharp. */
    private fun renderTileJpeg(d: Doc, page: Int, l: Float, t: Float, r: Float, b: Float, widthPx: Int): ByteArray = synchronized(d.lock) {
        val pg = d.renderer.openPage(page - 1)
        try {
            val pw = pg.width.coerceAtLeast(1).toFloat()
            val ph = pg.height.coerceAtLeast(1).toFloat()
            val fl = l.coerceIn(0f, 0.999f)
            val ft = t.coerceIn(0f, 0.999f)
            val fr = r.coerceIn(fl + 0.001f, 1f)
            val fb = b.coerceIn(ft + 0.001f, 1f)
            var w = widthPx.coerceIn(16, 6000)
            var h = (w.toDouble() * ((fb - ft) * ph) / ((fr - fl) * pw)).toInt().coerceAtLeast(1)
            if (w.toLong() * h > MAX_PIXELS) {
                val k = Math.sqrt(MAX_PIXELS.toDouble() / (w.toDouble() * h))
                w = (w * k).toInt().coerceAtLeast(16)
                h = (h * k).toInt().coerceAtLeast(1)
            }
            val sx = w / ((fr - fl) * pw)
            val sy = h / ((fb - ft) * ph)
            val m = Matrix()
            m.setScale(sx, sy)
            m.postTranslate(-fl * pw * sx, -ft * ph * sy)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            try {
                bmp.eraseColor(Color.WHITE)
                pg.render(bmp, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                val bos = ByteArrayOutputStream(w * h / 6)
                bmp.compress(Bitmap.CompressFormat.JPEG, 92, bos)
                bos.toByteArray()
            } finally {
                bmp.recycle()
            }
        } finally {
            pg.close()
        }
    }

    private fun reply(mime: String, status: Int, body: ByteArray): WebResourceResponse {
        val headers = HashMap<String, String>()
        headers["Access-Control-Allow-Origin"] = "*"
        headers["Cache-Control"] = "no-store"
        return WebResourceResponse(
            mime, "utf-8", status, if (status == 200) "OK" else "Error", headers, ByteArrayInputStream(body)
        )
    }

    /** Answers one intercepted https://docera.pdf/... request. Runs on a WebView worker thread. */
    fun handle(u: Uri): WebResourceResponse {
        return try {
            val key = u.getQueryParameter("k") ?: return reply("text/plain", 400, "no key".toByteArray())
            val d = docOf(key) ?: return reply("text/plain", 404, "not open".toByteArray())
            when (u.path) {
                "/size" -> {
                    val p = (u.getQueryParameter("p") ?: "1").toInt().coerceIn(1, d.renderer.pageCount)
                    val s = sizeOf(d, p)
                    reply("application/json", 200, "[${s[0]},${s[1]}]".toByteArray())
                }
                "/sizes" -> {
                    val sb = StringBuilder("[")
                    for (i in 1..d.renderer.pageCount) {
                        val s = sizeOf(d, i)
                        if (i > 1) sb.append(',')
                        sb.append('[').append(s[0]).append(',').append(s[1]).append(']')
                    }
                    sb.append(']')
                    reply("application/json", 200, sb.toString().toByteArray())
                }
                "/img" -> {
                    val p = (u.getQueryParameter("p") ?: "1").toInt().coerceIn(1, d.renderer.pageCount)
                    val w = (u.getQueryParameter("w") ?: "800").toInt()
                    reply("image/jpeg", 200, renderJpeg(d, p, w))
                }
                "/tile" -> {
                    val p = (u.getQueryParameter("p") ?: "1").toInt().coerceIn(1, d.renderer.pageCount)
                    fun f(n: String, def: String) = (u.getQueryParameter(n) ?: def).toFloat()
                    val w = (u.getQueryParameter("w") ?: "1000").toInt()
                    reply("image/jpeg", 200, renderTileJpeg(d, p, f("l", "0"), f("t", "0"), f("r", "1"), f("b", "1"), w))
                }
                "/sel" -> {
                    val p = (u.getQueryParameter("p") ?: "1").toInt().coerceIn(1, d.renderer.pageCount)
                    fun f(n: String) = (u.getQueryParameter(n) ?: "0").toFloat()
                    reply("application/json", 200,
                        PdfTextApi.select(d.renderer, d.lock, p, f("x1"), f("y1"), f("x2"), f("y2")).toByteArray())
                }
                "/find" -> {
                    val q = (u.getQueryParameter("q") ?: "").trim()
                    reply("application/json", 200, PdfTextApi.find(d.renderer, d.lock, q).toByteArray())
                }
                else -> reply("text/plain", 404, "bad path".toByteArray())
            }
        } catch (e: Throwable) {
            reply("text/plain", 500, (e.message ?: e.javaClass.simpleName).toByteArray())
        }
    }
}

/** window.AndroidPdfEngine — see NativePdfEngine. */
class PdfEngineBridge(private val ctx: Context) {
    @JavascriptInterface
    fun has(key: String): Int = NativePdfEngine.has(key)

    @JavascriptInterface
    fun begin(key: String): String = NativePdfEngine.begin(ctx, key)

    @JavascriptInterface
    fun append(key: String, b64: String): String = NativePdfEngine.append(key, b64)

    @JavascriptInterface
    fun open(key: String): String = NativePdfEngine.open(key)

    @JavascriptInterface
    fun close(key: String) = NativePdfEngine.close(key)

    /** true when this phone's PdfRenderer can give text (select / copy / search). */
    @JavascriptInterface
    fun textOK(): Boolean = PdfTextApi.supported()

    @JavascriptInterface
    fun copy(text: String): String {
        Handler(Looper.getMainLooper()).post {
            try {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Docera", text))
            } catch (_: Throwable) {}
        }
        return "ok"
    }
}

/**
 * PDFium text features through the platform PdfRenderer (added in Android 15 / SDK extension 13).
 * Kept in its own object so older phones never load the new classes. All coordinates going in and
 * out are fractions (0..1) of the page width/height, so the WebView never has to know PDF units.
 */
object PdfTextApi {
    fun supported(): Boolean = try {
        Build.VERSION.SDK_INT >= 35 ||
            (Build.VERSION.SDK_INT >= 30 && SdkExtensions.getExtensionVersion(Build.VERSION_CODES.S) >= 13)
    } catch (_: Throwable) { false }

    private fun rectJson(l: Float, t: Float, r: Float, b: Float, w: Float, h: Float) =
        JSONArray().put((l / w).toDouble()).put((t / h).toDouble()).put((r / w).toDouble()).put((b / h).toDouble())

    /** Text between two points on one page. Same point twice = the word under it. */
    @SuppressLint("NewApi")
    fun select(renderer: PdfRenderer, lock: Any, page: Int, x1: Float, y1: Float, x2: Float, y2: Float): String {
        val empty = JSONObject().put("text", "").put("rects", JSONArray()).toString()
        if (!supported()) return empty
        synchronized(lock) {
            val pg = renderer.openPage(page - 1)
            try {
                val w = pg.width.toFloat().coerceAtLeast(1f)
                val h = pg.height.toFloat().coerceAtLeast(1f)
                fun pt(nx: Float, ny: Float) = Point((nx.coerceIn(0f, 1f) * w).toInt(), (ny.coerceIn(0f, 1f) * h).toInt())
                fun run(a: Point, b: Point): JSONObject? {
                    val sel = pg.selectContent(
                        android.graphics.pdf.models.selection.SelectionBoundary(a),
                        android.graphics.pdf.models.selection.SelectionBoundary(b)
                    ) ?: return null
                    val parts = sel.selectedTextContents
                    val text = parts.joinToString("\n") { it.text }
                    val rects = JSONArray()
                    for (tc in parts) for (r in tc.bounds) rects.put(rectJson(r.left, r.top, r.right, r.bottom, w, h))
                    return JSONObject().put("text", text).put("rects", rects)
                }
                val a = pt(x1, y1)
                val b = pt(x2, y2)
                var out = run(a, b)
                if ((out == null || out.getString("text").isBlank()) && a.x == b.x && a.y == b.y) {
                    out = run(a, Point(b.x + 1, b.y))      // some builds need two different points to pick a word
                }
                return (out ?: JSONObject().put("text", "").put("rects", JSONArray())).toString()
            } finally {
                pg.close()
            }
        }
    }

    /** Every match of [q] in the document (capped), one page at a time so rendering can interleave. */
    @SuppressLint("NewApi")
    fun find(renderer: PdfRenderer, lock: Any, q: String, maxHits: Int = 500): String {
        val hits = JSONArray()
        if (!supported() || q.isEmpty()) return JSONObject().put("hits", hits).put("capped", false).toString()
        var total = 0
        val pages = renderer.pageCount
        var i = 0
        while (i < pages && total < maxHits) {
            synchronized(lock) {
                val pg = renderer.openPage(i)
                try {
                    val w = pg.width.toFloat().coerceAtLeast(1f)
                    val h = pg.height.toFloat().coerceAtLeast(1f)
                    for (m in pg.searchText(q)) {
                        val rs = JSONArray()
                        for (r in m.bounds) rs.put(rectJson(r.left, r.top, r.right, r.bottom, w, h))
                        if (rs.length() > 0) {
                            hits.put(JSONObject().put("p", i + 1).put("r", rs))
                            total++
                            if (total >= maxHits) break
                        }
                    }
                } finally {
                    pg.close()
                }
            }
            i++
        }
        return JSONObject().put("hits", hits).put("capped", total >= maxHits).toString()
    }
}
