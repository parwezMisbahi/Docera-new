package com.docera.parwez;

import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * window.AndroidTr: translates selected text of the reader. The request goes out from the phone side
 * (so the page has no web-security limits to fight) and the answer comes back as window.__trEv(id, rawJson).
 * Only Google's translate host is ever contacted.
 */
public final class TranslateBridge {
    public interface JsRunner { void run(String code); }

    private static final int MAX_CHARS = 1500;
    private static final int MAX_BYTES = 300 * 1024;
    private final JsRunner js;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);

    public TranslateBridge(JsRunner js) { this.js = js; }

    private static String q(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c == '\n') b.append("\\n");
            else if (c == '\r') b.append("\\r");
            else if (c < 32 || c == 0x2028 || c == 0x2029) b.append(String.format("\\u%04x", (int) c));
            else b.append(c);
        }
        return b.append('"').toString();
    }

    private static boolean goodLang(String l) {
        if (l == null || l.length() < 2 || l.length() > 8) return false;
        for (int i = 0; i < l.length(); i++) {
            char c = l.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '-')) return false;
        }
        return true;
    }

    private static String fetch(String text, String tl) throws Exception {
        String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + tl
                + "&dt=t&dt=bd&q=" + URLEncoder.encode(text, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(8000);
            c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            if (c.getResponseCode() != 200) throw new Exception("http " + c.getResponseCode());
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > MAX_BYTES) throw new Exception("too large");
            }
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    @JavascriptInterface
    public boolean ok() { return true; }

    /** Starts a translation. The answer arrives as window.__trEv(id, json) (json is null when it failed). */
    @JavascriptInterface
    public void translate(final String id, final String text, final String tl) {
        if (id == null || text == null || !goodLang(tl)) return;
        final String t = text.length() > MAX_CHARS ? text.substring(0, MAX_CHARS) : text;
        pool.execute(new Runnable() {
            @Override public void run() {
                String out;
                try { out = fetch(t, tl); } catch (Throwable e) { out = null; }
                js.run("window.__trEv&&window.__trEv(" + q(id) + "," + (out == null ? "null" : q(out)) + ")");
            }
        });
    }
}
