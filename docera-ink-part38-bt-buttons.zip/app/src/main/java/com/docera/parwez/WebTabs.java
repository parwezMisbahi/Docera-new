package com.docera.parwez;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Website tabs of the PDF reader. Every site gets its own real WebView laid over the reader area (so any site works,
 * not only ones that allow being framed) and it has NO JavaScript bridges, so a website can never reach the app's
 * own functions. The page (index.html) decides where the view goes and when it is hidden.
 */
public final class WebTabs {
    public interface JsRunner { void run(String code); }

    private static final int MAX_LIVE = 4;
    private final Activity act;
    private final JsRunner js;
    private final LinkedHashMap<String, WebView> views = new LinkedHashMap<String, WebView>();
    /** tab id -> the registered domain that was pasted; the tab only follows links inside it */
    private final HashMap<String, String> allowed = new HashMap<String, String>();
    /** tabs whose first page has not finished loading yet: a redirect right after pasting (short link, www / country change) is followed */
    private final HashSet<String> settling = new HashSet<String>();
    private String visibleId = null;
    private boolean suspended = false;

    public WebTabs(Activity act, JsRunner js) {
        this.act = act;
        this.js = js;
    }

    private static String q(String s) {
        if (s == null) s = "";
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') { b.append('\\').append(c); }
            else if (c == '\n') b.append("\\n");
            else if (c == '\r') b.append("\\r");
            else if (c < 32 || c == 0x2028 || c == 0x2029) b.append(String.format("\\u%04x", (int) c));
            else b.append(c);
        }
        return b.append('"').toString();
    }

    private void event(String id, String url, String title, int progress) {
        js.run("window.__webEv&&window.__webEv(" + q(id) + "," + q(url) + "," + q(title) + "," + progress + ")");
    }

    private static String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? "" : h;
        } catch (Throwable e) {
            return "";
        }
    }

    /** "" when the address is fine, otherwise why it is blocked: "social", "youtube" or "adult". */
    public String check(String url) {
        return SiteGuard.reason(hostOf(url));
    }

    private void blocked(String id, String host, String why, String url) {
        js.run("window.__webBlocked&&window.__webBlocked(" + q(id) + "," + q(host) + "," + q(why) + "," + q(url) + ")");
    }

    private static boolean webUrl(String u) {
        if (u == null) return false;
        String l = u.toLowerCase();
        return l.startsWith("https://") || l.startsWith("http://");
    }

    private void applyVisibility() {
        for (Map.Entry<String, WebView> e : views.entrySet()) {
            WebView v = e.getValue();
            boolean on = e.getKey().equals(visibleId) && !suspended;
            v.setVisibility(on ? View.VISIBLE : View.GONE);
            if (on) v.onResume(); else v.onPause();
        }
    }

    private WebView create(final String id) {
        final WebView wv = new WebView(act);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        try { s.setUserAgentString(s.getUserAgentString().replace("; wv", "")); } catch (Throwable ignored) {}
        try { CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Throwable ignored) {}
        wv.setBackgroundColor(0xFFFFFFFF);
        wv.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                try {
                    String h = request.getUrl().getHost();
                    if (SiteGuard.reason(h).length() > 0) { // social media, YouTube and adult sites never load, not even as a picture or video inside another page
                        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                } catch (Throwable ignored) {}
                return super.shouldInterceptRequest(view, request);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                if (webUrl(u)) {
                    String host = request.getUrl().getHost();
                    String why = SiteGuard.reason(host);
                    if (why.length() > 0) { blocked(id, host, why, u); return true; }
                    if (request.isForMainFrame() && !SiteGuard.sameSite(allowed.get(id), host)) {
                        if (settling.contains(id) && request.isRedirect()) { // a short link / redirect right after pasting: the site it leads to becomes this tab's site
                            allowed.put(id, SiteGuard.baseDomain(host));
                            return false;
                        }
                        blocked(id, host, "other", u);
                        return true;
                    }
                    return false;
                }
                if ("about:blank".equals(u)) return false;
                String sc = request.getUrl().getScheme();
                if ("mailto".equals(sc) || "tel".equals(sc) || "sms".equals(sc)) {
                    try { act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (ActivityNotFoundException ignored) {}
                }
                return true; // any other scheme (file:, content:, intent:, javascript:) is blocked
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { event(id, url, view.getTitle(), 5); }
            @Override public void onPageFinished(WebView view, String url) { settling.remove(id); event(id, url, view.getTitle(), 100); }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) { event(id, view.getUrl(), view.getTitle(), p); }
            @Override public void onReceivedTitle(WebView view, String title) { event(id, view.getUrl(), title, -1); }
        });
        wv.setDownloadListener(new android.webkit.DownloadListener() {
            @Override public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                if (!webUrl(url)) return;
                try { act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable ignored) {}
            }
        });
        return wv;
    }

    private void destroy(WebView wv) {
        try { wv.stopLoading(); } catch (Throwable ignored) {}
        try {
            if (wv.getParent() instanceof FrameLayout) ((FrameLayout) wv.getParent()).removeView(wv);
        } catch (Throwable ignored) {}
        try { wv.destroy(); } catch (Throwable ignored) {}
    }

    /** Creates the tab's WebView and starts loading the first time only. */
    public void open(final String id, final String url) {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            if (id == null || !webUrl(url) || views.containsKey(id)) return;
            String host = hostOf(url), why = SiteGuard.reason(host);
            if (why.length() > 0) { blocked(id, host, why, url); return; }
            allowed.put(id, SiteGuard.baseDomain(host));
            settling.add(id);
            WebView wv = create(id);
            views.put(id, wv);
            wv.loadUrl(url);
            if (views.size() > MAX_LIVE) {
                ArrayList<String> keys = new ArrayList<String>(views.keySet());
                for (String k : keys) {
                    if (views.size() <= MAX_LIVE) break;
                    if (k.equals(id) || k.equals(visibleId)) continue;
                    destroy(views.remove(k));
                }
            }
        }});
    }

    /** Puts the tab's view at the given rectangle (device pixels, relative to the page) and hides all the others. */
    public void show(final String id, final int l, final int t, final int w, final int h) {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            WebView wv = views.get(id);
            if (wv == null) return;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.max(1, w), Math.max(1, h));
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.leftMargin = Math.max(0, l);
            lp.topMargin = Math.max(0, t);
            if (wv.getParent() == null) act.addContentView(wv, lp); else wv.setLayoutParams(lp);
            visibleId = id;
            suspended = false;
            applyVisibility();
        }});
    }

    /** Hides the visible web view without closing it (a dropdown or dialog is open, or the reader tab was left). */
    public void suspend(final boolean off) {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            suspended = off;
            applyVisibility();
        }});
    }

    public void hide() {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            visibleId = null;
            applyVisibility();
        }});
    }

    public void remove(final String id) {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            WebView wv = views.remove(id);
            allowed.remove(id);
            settling.remove(id);
            if (wv != null) destroy(wv);
            if (id != null && id.equals(visibleId)) visibleId = null;
        }});
    }

    public void reload(final String id) {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            WebView wv = views.get(id);
            if (wv != null) wv.reload();
        }});
    }

    public void load(final String id, final String url) {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            WebView wv = views.get(id);
            if (wv == null || !webUrl(url)) return;
            String host = hostOf(url), why = SiteGuard.reason(host);
            if (why.length() > 0) { blocked(id, host, why, url); return; }
            settling.add(id);
            allowed.put(id, SiteGuard.baseDomain(host)); // pasting a new link in the address bar is a new site for this tab
            wv.loadUrl(url);
        }});
    }

    /** Page url of a tab, "" if it has none. */
    public String currentUrl(String id) {
        WebView wv = views.get(id);
        String u = wv == null ? null : wv.getUrl();
        return u == null ? "" : u;
    }

    public void openExternally(final String id) {
        act.runOnUiThread(new Runnable() { @Override public void run() {
            WebView wv = views.get(id);
            String u = wv == null ? null : wv.getUrl();
            if (!webUrl(u)) return;
            try { act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Throwable ignored) {}
        }});
    }

    /** Android Back: goes back inside the visible site if it can. Returns true when it did. Main thread. */
    public boolean handleBack() {
        if (visibleId == null || suspended) return false;
        WebView wv = views.get(visibleId);
        if (wv != null && wv.getVisibility() == View.VISIBLE && wv.canGoBack()) { wv.goBack(); return true; }
        return false;
    }

    /** App went to the background: pause everything and hide (the page shows them again once its lock state is known). */
    public void appPaused() {
        suspended = true;
        applyVisibility();
    }

    public void destroyAll() {
        for (WebView wv : new ArrayList<WebView>(views.values())) destroy(wv);
        views.clear();
        allowed.clear();
        settling.clear();
        visibleId = null;
    }
}
