package com.docera.parwez;

import java.util.Locale;

/**
 * Rules of the reader's website tabs.
 *  - reason(host): "" when the site is fine, otherwise "social", "youtube" or "adult" (these are always blocked).
 *  - sameSite(a, b): a tab only follows links inside the site that was pasted (same registered domain, any subdomain).
 * Pure Java so it can be tested without a phone.
 */
public final class SiteGuard {
    private SiteGuard() {}

    private static final String[] SOCIAL = {
        "instagram.com", "cdninstagram.com", "facebook.com", "facebook.net", "fb.com", "fb.me", "fbcdn.net", "messenger.com",
        "whatsapp.com", "whatsapp.net", "wa.me", "twitter.com", "x.com", "t.co", "twimg.com", "tiktok.com", "tiktokv.com",
        "snapchat.com", "pinterest.com", "pinimg.com", "reddit.com", "redd.it", "redditmedia.com", "linkedin.com", "tumblr.com",
        "discord.com", "discord.gg", "discordapp.com", "telegram.org", "telegram.me", "t.me", "threads.net", "wechat.com",
        "weibo.com", "vk.com", "ok.ru", "likee.video", "kwai.com", "sharechat.com", "kooapp.com", "myjosh.in", "roposo.com",
        "tinder.com", "bumble.com", "badoo.com", "omegle.com", "ome.tv", "bigo.tv", "twitch.tv", "kick.com", "clubhouse.com",
        "line.me", "viber.com", "signal.org", "mastodon.social", "bsky.app", "bluesky.social", "gab.com", "truthsocial.com"
    };

    private static final String[] YOUTUBE = {
        "youtube.com", "youtu.be", "youtube-nocookie.com", "youtubekids.com", "googlevideo.com", "ytimg.com", "yt.be"
    };

    /** well known adult sites (exact registered domains) */
    private static final String[] ADULT = {
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com", "spankbang.com", "brazzers.com",
        "chaturbate.com", "stripchat.com", "bongacams.com", "cam4.com", "livejasmin.com", "onlyfans.com", "fansly.com",
        "rule34.xxx", "e621.net", "nhentai.net", "hentaihaven.xxx", "motherless.com", "tube8.com", "eporner.com", "hqporner.com",
        "beeg.com", "txxx.com", "tnaflix.com", "drtuber.com", "sunporno.com", "porntrex.com", "4tube.com", "hclips.com",
        "vporn.com", "xtube.com", "erome.com", "fapello.com", "thothub.to", "camsoda.com", "myfreecams.com", "bangbros.com",
        "realitykings.com", "naughtyamerica.com", "pornone.com", "xxxbunker.com", "efukt.com", "heavy-r.com", "sex.com",
        "literotica.com", "fapello.is", "spankwire.com", "keezmovies.com", "porn.com", "pornhd.com", "yespornplease.com",
        "xvideos2.com", "xnxx2.com", "hotmovies.com", "adultfriendfinder.com", "ashleymadison.com"
    };

    /** long, unambiguous words: a host label that CONTAINS one of these is adult */
    private static final String[] ADULT_STRONG = {
        "pornhub", "xvideos", "xnxx", "xhamster", "onlyfans", "chaturbate", "stripchat", "redtube", "youporn", "spankbang",
        "brazzers", "bongacams", "livejasmin", "hentai", "camgirl", "sexcam", "sextube", "sexvid", "sexchat", "sexfilm"
    };

    /** short words that are only adult when they stand alone ("best-xxx-site", "xxx.com"), so xxxlutz.com or milford.com are fine */
    private static final String[] ADULT_TOKENS = { "xxx", "nsfw", "milf", "bdsm", "fetish", "nudes", "erotica", "porno" };

    private static final java.util.concurrent.ConcurrentHashMap<String, String> CACHE = new java.util.concurrent.ConcurrentHashMap<String, String>();

    private static String clean(String host) {
        if (host == null) return "";
        String h = host.trim().toLowerCase(Locale.ROOT);
        while (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        return h;
    }

    private static boolean inList(String h, String[] list) {
        for (String d : list) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    /** "" = allowed, otherwise "social", "youtube" or "adult". Called for every request of a web tab, so answers are remembered. */
    public static String reason(String host) {
        String h = clean(host);
        if (h.length() == 0) return "";
        String c = CACHE.get(h);
        if (c != null) return c;
        String r = compute(h);
        if (CACHE.size() > 4000) CACHE.clear();
        CACHE.put(h, r);
        return r;
    }

    private static String compute(String h) {
        if (inList(h, YOUTUBE)) return "youtube";
        if (inList(h, SOCIAL)) return "social";
        if (inList(h, ADULT)) return "adult";
        for (String label : h.split("\\.")) {
            if (label.contains("porn") && !label.contains("sporn")) return "adult";
            for (String w : ADULT_STRONG) {
                if (label.contains(w)) return "adult";
            }
            for (String tok : label.split("-")) {
                for (String w : ADULT_TOKENS) {
                    if (tok.equals(w)) return "adult";
                }
            }
        }
        return "";
    }

    private static boolean twoLevelSuffix(String sld, String tld) {
        if (tld.length() != 2) return false;
        switch (sld) {
            case "co": case "com": case "org": case "net": case "gov": case "edu": case "ac": case "or": case "ne": case "go":
            case "nic": case "res": case "sch": case "mil": case "ltd": case "plc":
                return true;
            default:
                return false;
        }
    }

    /** Registered domain without a public-suffix list: last two labels, or last three for co.in / com.au / ac.uk style endings. */
    public static String baseDomain(String host) {
        String h = clean(host);
        if (h.length() == 0) return "";
        String[] p = h.split("\\.");
        int n = p.length;
        if (n <= 2) return h;
        boolean ip = true;
        for (String s : p) { if (!s.matches("[0-9]+")) { ip = false; break; } }
        if (ip) return h;
        if (twoLevelSuffix(p[n - 2], p[n - 1])) return p[n - 3] + "." + p[n - 2] + "." + p[n - 1];
        return p[n - 2] + "." + p[n - 1];
    }

    private static String brand(String base) {
        int i = base.indexOf('.');
        return i < 0 ? base : base.substring(0, i);
    }

    /**
     * True for the pasted site itself: the same registered domain (any subdomain), or the same name under another country ending
     * (google.com opens google.co.in, amazon.com opens amazon.in). Anything else is a different site.
     */
    public static boolean sameSite(String allowedBase, String host) {
        if (allowedBase == null || allowedBase.length() == 0) return true;
        String b = baseDomain(host);
        if (b.equals(allowedBase)) return true;
        String x = brand(b), y = brand(allowedBase);
        return x.length() >= 3 && x.equals(y) && !x.matches("[0-9]+");
    }
}
