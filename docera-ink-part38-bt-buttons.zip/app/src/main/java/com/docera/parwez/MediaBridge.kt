package com.docera.parwez

import android.content.Context
import android.webkit.JavascriptInterface

/** JS side of the background-video notification (window.AndroidMedia). */
class MediaBridge(private val ctx: Context) {
    @JavascriptInterface
    fun show(title: String?, playing: Boolean) {
        MediaPlayService.show(ctx, title ?: "", playing)
    }

    @JavascriptInterface
    fun stop() {
        MediaPlayService.stop(ctx)
    }
}
