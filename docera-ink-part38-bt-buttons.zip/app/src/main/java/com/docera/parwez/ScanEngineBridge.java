package com.docera.parwez;

import android.content.Context;
import android.webkit.JavascriptInterface;

/** window.AndroidScan: stages a captured JPEG for the native scanner (see ScanEngine). */
public final class ScanEngineBridge {
    private final Context ctx;

    public ScanEngineBridge(Context c) { ctx = c.getApplicationContext(); }

    @JavascriptInterface
    public boolean ok() { return true; }

    @JavascriptInterface
    public String begin(String key) { return ScanEngine.begin(ctx, key); }

    @JavascriptInterface
    public String append(String key, String b64) { return ScanEngine.append(key, b64); }

    @JavascriptInterface
    public String end(String key) { return ScanEngine.end(key); }

    @JavascriptInterface
    public void clear() { ScanEngine.clear(); }
}
