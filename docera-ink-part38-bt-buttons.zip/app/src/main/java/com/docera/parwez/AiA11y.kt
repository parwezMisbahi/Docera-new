package com.docera.parwez

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Used only as a fallback for the PDF Assistant (Translate / Summary / Explain / Research / Extract text):
 * when there is no API key, or the direct API call fails, this service types the prompt into whichever AI app
 * the person picked in Settings -> PDF Assistant, waits for its reply, and taps "Copy" on it.
 * It does nothing else and does nothing unless MainActivity asks it to (see AndroidAiA11yBridge).
 */
class AiA11y : AccessibilityService() {
    companion object { @Volatile var inst: AiA11y? = null }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { h.removeCallbacksAndMessages(null); inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun all(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) { if (n == null) return; out.add(n); for (i in 0 until n.childCount) walk(n.getChild(i)) }
        val r = rootInActiveWindow
        if (r != null) walk(r) else windows.forEach { w -> w.root?.let { walk(it) } }
        return out
    }
    private fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) { if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true; c = c.parent }
        return false
    }
    private fun gesture(g: GestureDescription) { try { dispatchGesture(g, null, null) } catch (_: Exception) {} }
    private fun tapXY(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build())
    }
    private fun tap(n: AccessibilityNodeInfo): Boolean {
        if (click(n)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        tapXY(r.exactCenterX(), r.exactCenterY()); return true
    }
    private fun setText(n: AccessibilityNodeInfo, s: String) = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
        Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s) })
    private fun retry(t: Int, d: Long, f: () -> Boolean, done: (Boolean) -> Unit) {
        if (f()) done(true) else if (t <= 1) done(false) else h.postDelayed({ retry(t - 1, d, f, done) }, d)
    }
    private fun scroll(down: Boolean) {
        val ok = all().firstOrNull { it.isScrollable }?.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
        if (!ok) {
            val m = resources.displayMetrics; val x = m.widthPixels / 2f; val a = m.heightPixels * 0.7f; val b = m.heightPixels * 0.3f
            val p = Path().apply { if (down) { moveTo(x, a); lineTo(x, b) } else { moveTo(x, b); lineTo(x, a) } }
            gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build())
        }
    }
    private fun bigSwipeDown() {
        val m = resources.displayMetrics; val x = m.widthPixels / 2f
        val p = Path().apply { moveTo(x, m.heightPixels * 0.80f); lineTo(x, m.heightPixels * 0.22f) }
        gesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build())
    }
    private fun label(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.contentDescription, n.text).map { it.toString().lowercase().trim() }

    /** Types the prompt into the AI app's message box and taps Send. Keeps retrying for ~24s before giving up -
        a cold-starting app, a sign-in check, or an update dialog can all delay the message box showing up. */
    fun askAi(t: String, startDelay: Long, cb: (Boolean) -> Unit) {
        val key = t.lowercase().take(25)
        h.postDelayed({
            retry(30, 800, {
                val n = all()
                val e = n.firstOrNull { it.isEditable && it.isFocused } ?: n.lastOrNull { it.isEditable }
                e?.let { setText(it, t) } ?: false
            }) { ok ->
                if (!ok) cb(false) else h.postDelayed({
                    retry(20, 600, {
                        val n = all()
                        val busy = n.any { nd -> label(nd).any { s -> s == "stop" || s.startsWith("stop ") } }
                        val ed = n.firstOrNull { it.isEditable }
                        val cleared = ed != null && ed.text?.toString()?.lowercase()?.contains(key) != true
                        if (busy || cleared) true
                        else n.firstOrNull { nd -> !nd.isEditable && label(nd).any { s -> s == "send" || s.startsWith("send ") || s == "submit" } }?.let { tap(it) } ?: false
                    }, cb)
                }, 700)
            }
        }, startDelay)
    }

    /** Waits for the reply to finish: screen text stops changing and no "Stop" button is visible for a while. */
    fun waitReplyDone(maxMs: Long, cb: (Boolean) -> Unit) {
        val t0 = System.currentTimeMillis()
        fun sigNow(): Int = all().filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
        val base = sigNow()
        var last = base; var same = 0; var changed = false
        val r = object : Runnable {
            override fun run() {
                val n = all()
                val busy = n.any { nd -> label(nd).any { s -> s == "stop" || s.startsWith("stop gen") || s.startsWith("stop stream") || s.startsWith("stop resp") } }
                val sig = n.filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
                val el = System.currentTimeMillis() - t0
                if (sig != base) changed = true
                if (!busy && sig == last && (changed || el > 30000)) same++ else same = 0
                last = sig
                when {
                    same >= 5 && el > 8000 -> cb(true)
                    el > maxMs -> cb(true)
                    else -> h.postDelayed(this, 1200)
                }
            }
        }
        h.postDelayed(r, 4000)
    }

    /** Taps the reply's "Copy" button, scrolling down to find it on a long answer (up to ~40 tries). */
    fun tapLastCopy(cb: (Boolean) -> Unit) {
        val exact = setOf("copy", "copy message", "copy response", "copy reply", "copy text", "copy answer")
        var tries = 0; var lastSig = 0; var still = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                val n = all()
                val copies = n.filter { nd -> !nd.isEditable && label(nd).any { it.length < 24 && (it in exact || it.startsWith("copy")) } }
                fun top(nd: AccessibilityNodeInfo): Int { val rc = Rect(); nd.getBoundsInScreen(rc); return rc.top }
                val exactHit = copies.filter { nd -> label(nd).any { it in exact } }.maxByOrNull { top(it) }
                val sig = n.filter { !it.isEditable }.mapNotNull { it.text?.toString() }.joinToString("|").hashCode()
                still = if (sig == lastSig) still + 1 else 0
                lastSig = sig
                val atEnd = still >= 2
                val hit = exactHit ?: if (atEnd) copies.maxByOrNull { top(it) } else null
                if (hit != null && tap(hit)) { cb(true); return }
                if (tries >= 40 || still >= 5) { cb(false); return }
                if (tries % 2 == 1) bigSwipeDown() else scroll(true)
                h.postDelayed(this, 900)
            }
        }
        r.run()
    }
}
