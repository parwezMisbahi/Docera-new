package com.docera.parwez

import android.webkit.JavascriptInterface
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.DigitalInkRecognizer
import com.google.mlkit.vision.digitalink.DigitalInkRecognizerOptions
import com.google.mlkit.vision.digitalink.Ink
import org.json.JSONArray
import org.json.JSONObject

/**
 * Handwriting -> text for the "write over the PDF / video" layer (window.AndroidInk).
 *
 * The page captures the strokes (pointer events) and hands them over as JSON; ML Kit Digital Ink recognises them
 * on the phone. Only the language model is downloaded (once, ~20 MB), after that it works offline.
 *
 *   status(lang)                      -> "ready" | "missing" | "unsupported"
 *   ensure(lang)                      -> downloads the model if needed; reports through window.__inkModel(lang, state, msg)
 *                                        state = "ready" | "downloading" | "error"
 *   recognize(reqId, lang, strokes, w, h, pre)
 *        strokes = [[[x,y,t],[x,y,t],...], ...]   (t in ms, any origin; x,y in CSS px)
 *        w,h     = size of the writing area in px,  pre = text already written before (helps accuracy)
 *                                      -> window.__inkResult(reqId, "<json>")   json = {c:["best","2nd",...]} or {err:"..."}
 *   close()                           -> frees the recognizers
 *
 * [js] must run a JavaScript snippet on the page (any thread).
 */
class InkBridge(private val js: (String) -> Unit) {

    private val manager = RemoteModelManager.getInstance()
    private val models = HashMap<String, DigitalInkRecognitionModel>()
    private val recognizers = HashMap<String, DigitalInkRecognizer>()
    private val ready = HashSet<String>()
    private val downloading = HashSet<String>()

    private fun q(s: String) = JSONObject.quote(s)

    private fun model(lang: String): DigitalInkRecognitionModel? {
        models[lang]?.let { return it }
        val id = try { DigitalInkRecognitionModelIdentifier.fromLanguageTag(lang) } catch (_: Exception) { null } ?: return null
        val m = DigitalInkRecognitionModel.builder(id).build()
        models[lang] = m
        return m
    }

    private fun tell(lang: String, state: String, msg: String = "") =
        js("window.__inkModel&&window.__inkModel(${q(lang)},${q(state)},${q(msg)})")

    private fun activate(lang: String, m: DigitalInkRecognitionModel) {
        synchronized(this) {
            if (recognizers[lang] == null) {
                recognizers[lang] = DigitalInkRecognition.getClient(DigitalInkRecognizerOptions.builder(m).build())
            }
            ready.add(lang)
            downloading.remove(lang)
        }
        tell(lang, "ready")
    }

    @JavascriptInterface
    fun status(lang: String): String {
        if (synchronized(this) { lang in ready }) return "ready"
        return if (model(lang) == null) "unsupported" else "missing"
    }

    @JavascriptInterface
    fun ensure(lang: String) {
        val m = model(lang) ?: return tell(lang, "error", "language not supported")
        synchronized(this) {
            if (lang in ready) { tell(lang, "ready"); return }
            if (lang in downloading) return
            downloading.add(lang)
        }
        manager.isModelDownloaded(m)
            .addOnSuccessListener { have ->
                if (have) {
                    activate(lang, m)
                } else {
                    tell(lang, "downloading")
                    manager.download(m, DownloadConditions.Builder().build())
                        .addOnSuccessListener { activate(lang, m) }
                        .addOnFailureListener {
                            synchronized(this) { downloading.remove(lang) }
                            tell(lang, "error", it.message ?: "download failed (internet needed the first time)")
                        }
                }
            }
            .addOnFailureListener {
                synchronized(this) { downloading.remove(lang) }
                tell(lang, "error", it.message ?: "model check failed")
            }
    }

    @JavascriptInterface
    fun recognize(reqId: String, lang: String, strokes: String, w: Float, h: Float, pre: String) {
        fun done(o: JSONObject) = js("window.__inkResult&&window.__inkResult(${q(reqId)},${q(o.toString())})")
        val rec = synchronized(this) { recognizers[lang] }
        if (rec == null) {
            done(JSONObject().put("err", "model not ready"))
            ensure(lang)
            return
        }
        try {
            val b = Ink.builder()
            val arr = JSONArray(strokes)
            for (i in 0 until arr.length()) {
                val pts = arr.getJSONArray(i)
                val sb = Ink.Stroke.builder()
                for (j in 0 until pts.length()) {
                    val p = pts.getJSONArray(j)
                    sb.addPoint(Ink.Point.create(p.getDouble(0).toFloat(), p.getDouble(1).toFloat(), p.getLong(2)))
                }
                b.addStroke(sb.build())
            }
            val ink = b.build()
            if (ink.strokes.isEmpty()) return done(JSONObject().put("c", JSONArray()))
            // exactly like InkTest: the ink alone (a guessed writing area / pre-context made the result worse)
            rec.recognize(ink)
                .addOnSuccessListener { r ->
                    val c = JSONArray()
                    r.candidates.forEach { c.put(it.text) }
                    done(JSONObject().put("c", c))
                }
                .addOnFailureListener { done(JSONObject().put("err", it.message ?: "recognition failed")) }
        } catch (e: Throwable) {
            done(JSONObject().put("err", e.message ?: e.javaClass.simpleName))
        }
    }

    @JavascriptInterface
    fun close() {
        synchronized(this) {
            recognizers.values.forEach { try { it.close() } catch (_: Throwable) {} }
            recognizers.clear()
            ready.clear()
        }
    }
}
