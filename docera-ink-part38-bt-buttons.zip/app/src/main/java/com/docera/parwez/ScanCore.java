package com.docera.parwez;

/**
 * Pixel maths of the page scanner (perspective warp, shadow removal, colour / gray / B&W styles).
 * It is a line-by-line port of scWarp / scEnhanceData / scRotData from index.html, so the result looks
 * the same as the JavaScript version, but it runs on every CPU core. Pure Java, no Android classes.
 * Pixels are packed ARGB ints (the format of android.graphics.Bitmap.getPixels / setPixels).
 */
public final class ScanCore {
    private ScanCore() {}

    interface Job { void run(int from, int to); }

    /** Runs job(from,to) over 0..n split into up to [threads] ranges, one thread each, and waits for all. */
    static void par(int n, int threads, final Job job) {
        if (n <= 0) return;
        int t = Math.max(1, Math.min(threads, n));
        if (t == 1) { job.run(0, n); return; }
        final int step = (n + t - 1) / t;
        Thread[] ts = new Thread[t];
        final Throwable[] err = new Throwable[1];
        for (int i = 0; i < t; i++) {
            final int a = i * step;
            final int b = Math.min(n, a + step);
            if (a >= b) continue;
            ts[i] = new Thread(new Runnable() {
                @Override public void run() {
                    try { job.run(a, b); } catch (Throwable e) { synchronized (err) { err[0] = e; } }
                }
            });
            ts[i].start();
        }
        for (Thread th : ts) {
            if (th == null) continue;
            try { th.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        Throwable e = err[0];
        if (e != null) {
            if (e instanceof RuntimeException) throw (RuntimeException) e;
            if (e instanceof Error) throw (Error) e;
            throw new RuntimeException(e);
        }
    }

    /** 255*pow(v/255,e) from a 64-steps-per-level table with linear interpolation (error far below one level); v in 0..255. */
    private static final int LUT_STEPS = 64;
    private static float[] lut(double e) {
        float[] t = new float[255 * LUT_STEPS + 2];
        for (int i = 0; i < t.length; i++) t[i] = (float) (255 * Math.pow(Math.min(255.0, i / (double) LUT_STEPS) / 255, e));
        return t;
    }
    private static final float[] LUT_118 = lut(1.18), LUT_12 = lut(1.2);
    private static double curve(float[] t, double v) {
        double x = v * LUT_STEPS;
        int i = (int) x;
        double f = x - i;
        return t[i] + (t[i + 1] - t[i]) * f;
    }

    /** Uint8ClampedArray assignment: clamp to 0..255, round half to even. */
    private static int toClamped(double v) {
        if (!(v > 0)) return 0;
        if (v >= 255) return 255;
        return (int) Math.rint(v);
    }

    static double[] hom(double[] q) {
        double x0 = q[0], y0 = q[1], x1 = q[2], y1 = q[3], x2 = q[4], y2 = q[5], x3 = q[6], y3 = q[7];
        double dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3, dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
        double g = 0, h = 0;
        if (Math.abs(dx3) > 1e-9 || Math.abs(dy3) > 1e-9) {
            double den = dx1 * dy2 - dx2 * dy1;
            if (den == 0) den = 1e-9;
            g = (dx3 * dy2 - dx2 * dy3) / den;
            h = (dx1 * dy3 - dx3 * dy1) / den;
        }
        return new double[]{x1 - x0 + g * x1, x3 - x0 + h * x3, x0, y1 - y0 + g * y1, y3 - y0 + h * y3, y0, g, h};
    }

    /** Straightens the page: bilinear sampling of the quad q (x0,y0,..x3,y3 in source pixels) into ow x oh. */
    public static int[] warp(final int[] sd, final int sw, final int sh, double[] q, final int ow, final int oh, int threads) {
        double[] H = hom(q);
        final double a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
        final int[] o = new int[ow * oh];
        par(oh, threads, new Job() {
            @Override public void run(int from, int to) {
                for (int j = from; j < to; j++) {
                    double v = (j + .5) / oh;
                    for (int i = 0; i < ow; i++) {
                        double u = (i + .5) / ow;
                        double w = g * u + h * v + 1;
                        double sx = (a * u + b * v + c) / w - .5, sy = (d * u + e * v + f) / w - .5;
                        int x0 = (int) Math.floor(sx), y0 = (int) Math.floor(sy);
                        double fx = sx - x0, fy = sy - y0;
                        int x1 = x0 + 1, y1 = y0 + 1;
                        x0 = x0 < 0 ? 0 : x0 >= sw ? sw - 1 : x0;
                        x1 = x1 < 0 ? 0 : x1 >= sw ? sw - 1 : x1;
                        y0 = y0 < 0 ? 0 : y0 >= sh ? sh - 1 : y0;
                        y1 = y1 < 0 ? 0 : y1 >= sh ? sh - 1 : y1;
                        int c00 = sd[y0 * sw + x0], c10 = sd[y0 * sw + x1], c01 = sd[y1 * sw + x0], c11 = sd[y1 * sw + x1];
                        double w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
                        double r = ((c00 >> 16) & 255) * w00 + ((c10 >> 16) & 255) * w10 + ((c01 >> 16) & 255) * w01 + ((c11 >> 16) & 255) * w11;
                        double gg = ((c00 >> 8) & 255) * w00 + ((c10 >> 8) & 255) * w10 + ((c01 >> 8) & 255) * w01 + ((c11 >> 8) & 255) * w11;
                        double bb = (c00 & 255) * w00 + (c10 & 255) * w10 + (c01 & 255) * w01 + (c11 & 255) * w11;
                        o[j * ow + i] = 0xFF000000 | (toClamped(r) << 16) | (toClamped(gg) << 8) | toClamped(bb);
                    }
                }
            }
        });
        return o;
    }

    /** Rotates by 90 / 180 / 270 degrees. outWH receives the new width and height. */
    public static int[] rotate(int[] d, int w, int h, int rot, int[] outWH) {
        boolean odd = (rot % 180) != 0;
        int nw = odd ? h : w, nh = odd ? w : h;
        int[] o = new int[nw * nh];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int X, Y;
                if (rot == 90) { X = h - 1 - y; Y = x; }
                else if (rot == 180) { X = w - 1 - x; Y = h - 1 - y; }
                else { X = y; Y = w - 1 - x; }
                o[Y * nw + X] = d[y * w + x];
            }
        }
        outWH[0] = nw; outWH[1] = nh;
        return o;
    }

    /** Plain box blur (small grids only). Same as scBlur. */
    static void blur(float[] a, int w, int h, int r) {
        float[] t = new float[a.length];
        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                double s = 0; int c = 0;
                for (int k = -r; k <= r; k++) { int xx = x + k; if (xx < 0 || xx >= w) continue; s += a[row + xx]; c++; }
                t[row + x] = (float) (s / c);
            }
        }
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                double s = 0; int c = 0;
                for (int k = -r; k <= r; k++) { int yy = y + k; if (yy < 0 || yy >= h) continue; s += t[yy * w + x]; c++; }
                a[y * w + x] = (float) (s / c);
            }
        }
    }

    /** Sliding-window box blur for the full-size picture. Same as scBlurFast, rows / columns split over threads. */
    static void blurFast(final float[] a, final int w, final int h, final int r, int threads) {
        par(h, threads, new Job() {
            @Override public void run(int from, int to) {
                float[] t = new float[w];
                for (int y = from; y < to; y++) {
                    int o = y * w; double s = 0;
                    for (int x = 0; x <= Math.min(r, w - 1); x++) s += a[o + x];
                    for (int x = 0; x < w; x++) {
                        int lo = x - r, hi = x + r;
                        t[x] = (float) (s / (Math.min(w - 1, hi) - Math.max(0, lo) + 1));
                        if (hi + 1 < w) s += a[o + hi + 1];
                        if (lo >= 0) s -= a[o + lo];
                    }
                    System.arraycopy(t, 0, a, o, w);
                }
            }
        });
        par(w, threads, new Job() {
            @Override public void run(int from, int to) {
                float[] t = new float[h];
                for (int x = from; x < to; x++) {
                    double s = 0;
                    for (int y = 0; y <= Math.min(r, h - 1); y++) s += a[y * w + x];
                    for (int y = 0; y < h; y++) {
                        int lo = y - r, hi = y + r;
                        t[y] = (float) (s / (Math.min(h - 1, hi) - Math.max(0, lo) + 1));
                        if (hi + 1 < h) s += a[(hi + 1) * w + x];
                        if (lo >= 0) s -= a[lo * w + x];
                    }
                    for (int y = 0; y < h; y++) a[y * w + x] = t[y];
                }
            }
        });
    }

    /** Smooth paper-brightness correction for one row (bilinear over the block grid). Same as rowG. */
    private static void rowG(int y, float[] out, int w, int bw, int bh, int B, float[] gb, int[] xi, float[] xw) {
        double fy = Math.max(0, Math.min(bh - 1.001, (y + .5) / B - .5));
        int y0 = (int) fy;
        double wy = fy - y0;
        int r0 = y0 * bw, r1 = Math.min(y0 + 1, bh - 1) * bw;
        for (int x = 0; x < w; x++) {
            int x0 = xi[x], x1 = Math.min(x0 + 1, bw - 1);
            double wx = xw[x];
            out[x] = (float) ((gb[r0 + x0] * (1 - wx) + gb[r0 + x1] * wx) * (1 - wy) + (gb[r1 + x0] * (1 - wx) + gb[r1 + x1] * wx) * wy);
        }
    }

    /**
     * Removes shadows (divides by the paper brightness) and applies the style: "color", "gray" or "bw".
     * "orig" leaves the picture as it is. d is rewritten in place.
     */
    public static void enhance(final int[] d, final int w, final int h, final String mode, final int threads) {
        if ("orig".equals(mode)) return;
        final int n = w * h;
        final int B = Math.max(8, (int) Math.round(Math.max(w, h) / 70.0));
        final int bw = (w + B - 1) / B, bh = (h + B - 1) / B;
        final float[] bg = new float[bw * bh], L = new float[n];
        /* paper brightness per block */
        par(bh, threads, new Job() {
            @Override public void run(int b0, int b1) {
                for (int by = b0; by < b1; by++) {
                    int yEnd = Math.min(h, (by + 1) * B), row = by * bw;
                    for (int y = by * B; y < yEnd; y++) {
                        for (int x = 0; x < w; x++) {
                            int c = d[y * w + x];
                            double l = ((c >> 16) & 255) * .299 + ((c >> 8) & 255) * .587 + (c & 255) * .114;
                            int bi = row + x / B;
                            L[y * w + x] = (float) l;
                            if (l > bg[bi]) bg[bi] = (float) l;
                        }
                    }
                }
            }
        });
        blur(bg, bw, bh, 1);
        final float[] gb = new float[bw * bh];
        for (int i = 0; i < gb.length; i++) gb[i] = (float) (255 / Math.max(45, bg[i] * .97));
        final int[] xi = new int[w];
        final float[] xw = new float[w];
        for (int x = 0; x < w; x++) {
            double fx = Math.max(0, Math.min(bw - 1.001, (x + .5) / B - .5));
            xi[x] = (int) fx;
            xw[x] = (float) (fx - (int) fx);
        }
        final int[] hist = new int[256];
        final long[] hcBox = new long[1];
        par(h, threads, new Job() {
            @Override public void run(int from, int to) {
                float[] G = new float[w];
                int[] hl = new int[256];
                long hc = 0;
                for (int y = from; y < to; y++) {
                    rowG(y, G, w, bw, bh, B, gb, xi, xw);
                    int o = y * w;
                    for (int x = 0; x < w; x++) {
                        double v = (double) L[o + x] * G[x];
                        double c = v > 255 ? 255 : v;
                        L[o + x] = (float) c;
                        if (((x + y) & 3) == 0) { hl[(int) c]++; hc++; }
                    }
                }
                synchronized (hist) { for (int i = 0; i < 256; i++) hist[i] += hl[i]; hcBox[0] += hc; }
            }
        });
        /* too bright photo: stretch so the darkest ink becomes black again */
        int bp0 = 0; long acc = 0; double tgt = hcBox[0] * .004;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc >= tgt) { bp0 = i; break; } }
        final int bp = Math.min(bp0, 175);
        final double kk = bp > 6 ? 255.0 / (255 - bp) : 1;
        if (kk != 1) {
            par(n, threads, new Job() {
                @Override public void run(int from, int to) {
                    for (int i = from; i < to; i++) { double v = (L[i] - bp) * kk; L[i] = (float) (v < 0 ? 0 : v); }
                }
            });
        }
        final boolean isBw = "bw".equals(mode), isColor = "color".equals(mode);
        int r = isBw ? Math.max(1, (int) Math.round(Math.max(w, h) / 1500.0)) : 1;
        final float[] S = L.clone();
        blurFast(S, w, h, r, threads);
        /* local paper level on a coarse grid (to tell faint ink from grain) */
        final int CG = 4, gw = (w + CG - 1) / CG, gh = (h + CG - 1) / CG;
        final float[] M = new float[gw * gh];
        if (isBw) {
            final int[] Mc = new int[gw * gh];
            par(gh, threads, new Job() {
                @Override public void run(int g0, int g1) {
                    for (int gy = g0; gy < g1; gy++) {
                        int yEnd = Math.min(h, (gy + 1) * CG);
                        for (int y = gy * CG; y < yEnd; y++) {
                            for (int x = 0; x < w; x++) { int g = gy * gw + x / CG; M[g] += S[y * w + x]; Mc[g]++; }
                        }
                    }
                }
            });
            for (int i = 0; i < M.length; i++) M[i] /= (Mc[i] == 0 ? 1 : Mc[i]);
            blur(M, gw, gh, Math.max(3, (int) Math.round(Math.max(w, h) / (double) CG / 90)));
        }
        final boolean isGray = !isBw && !isColor;
        final double mixD = isBw ? .3 : "gray".equals(mode) ? .7 : .75;
        final byte[] O = isBw ? new byte[n] : null;
        par(h, threads, new Job() {
            @Override public void run(int from, int to) {
                float[] G = isColor ? new float[w] : null;
                for (int y = from; y < to; y++) {
                    if (isColor) rowG(y, G, w, bw, bh, B, gb, xi, xw);
                    int gy = (y / CG) * gw;
                    for (int x = 0; x < w; x++) {
                        int i = y * w + x;
                        double lo = L[i];
                        double ls = lo * mixD + S[i] * (1 - mixD);
                        if (isColor) {
                            int c = d[i];
                            double g = G[x], dl = ls - lo;
                            int[] ch = new int[3];
                            for (int k = 0; k < 3; k++) {
                                int src = k == 0 ? (c >> 16) & 255 : k == 1 ? (c >> 8) & 255 : c & 255;
                                double v = (src * g - bp) * kk + dl;
                                v = v < 0 ? 0 : v > 255 ? 255 : v;
                                ch[k] = toClamped(curve(LUT_118, v));
                            }
                            d[i] = 0xFF000000 | (ch[0] << 16) | (ch[1] << 8) | ch[2];
                        } else if (isBw) {
                            double t = (ls - 105) / (188 - 105); t = t < 0 ? 0 : t > 1 ? 1 : t;
                            double a1 = t * t * (3 - 2 * t);
                            double ratio = ls / Math.max(40, M[gy + x / CG]);
                            double u = (ratio - .78) / (.9 - .78); u = u < 0 ? 0 : u > 1 ? 1 : u;
                            double a2 = u * u * (3 - 2 * u);
                            O[i] = (byte) (int) (255 * (a1 < a2 ? a1 : a2));
                        } else {
                            ls = ls < 0 ? 0 : ls > 255 ? 255 : ls;
                            int l = toClamped(curve(LUT_12, ls));
                            d[i] = 0xFF000000 | (l << 16) | (l << 8) | l;
                        }
                    }
                }
            }
        });
        if (isBw) {
            /* remove lonely black specks (in place, top to bottom, exactly like the JS version) */
            for (int y = 1; y < h - 1; y++) {
                for (int x = 1; x < w - 1; x++) {
                    int i = y * w + x;
                    if ((O[i] & 255) < 128) {
                        int c = ((O[i - 1] & 255) < 128 ? 1 : 0) + ((O[i + 1] & 255) < 128 ? 1 : 0) + ((O[i - w] & 255) < 128 ? 1 : 0) + ((O[i + w] & 255) < 128 ? 1 : 0)
                            + ((O[i - w - 1] & 255) < 128 ? 1 : 0) + ((O[i - w + 1] & 255) < 128 ? 1 : 0) + ((O[i + w - 1] & 255) < 128 ? 1 : 0) + ((O[i + w + 1] & 255) < 128 ? 1 : 0);
                        if (c <= 1) O[i] = (byte) 255;
                    }
                }
            }
            for (int i = 0; i < n; i++) { int v = O[i] & 255; d[i] = 0xFF000000 | (v << 16) | (v << 8) | v; }
        }
    }
}
