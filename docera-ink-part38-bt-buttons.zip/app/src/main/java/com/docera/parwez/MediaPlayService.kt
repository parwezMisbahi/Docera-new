package com.docera.parwez

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Keeps a downloaded video playing with the screen locked / Docera in the background, and shows a
 * media notification (lock screen too) with Play / Pause and Remove. The video itself still plays
 * inside the WebView; this service only keeps the app alive and passes the button presses back.
 */
class MediaPlayService : Service() {

    companion object {
        /** true while a video is really playing (MainActivity then does not pause its WebView) */
        @Volatile
        var active: Boolean = false

        /** set by MainActivity: runs "play" / "pause" / "close" inside the page */
        @Volatile
        var sink: ((String) -> Unit)? = null

        private const val CHANNEL = "docera_media"
        private const val NOTIF_ID = 4102
        private const val A_SHOW = "docera.media.show"
        private const val A_TOGGLE = "docera.media.toggle"
        private const val A_CLOSE = "docera.media.close"

        fun show(ctx: Context, title: String, playing: Boolean) {
            try {
                val i = Intent(ctx, MediaPlayService::class.java).setAction(A_SHOW)
                    .putExtra("t", title).putExtra("p", playing)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, MediaPlayService::class.java))
            } catch (_: Throwable) {
            }
            active = false
        }
    }

    private var session: MediaSession? = null
    private var wake: PowerManager.WakeLock? = null
    private var title = ""
    private var playing = false
    private var fg = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_SHOW -> {
                title = intent.getStringExtra("t") ?: ""
                playing = intent.getBooleanExtra("p", false)
                post()
            }
            A_TOGGLE -> sink?.invoke(if (playing) "pause" else "play")
            A_CLOSE -> {
                sink?.invoke("close")
                shutdown()
            }
            else -> {
                // started without a command (should not happen): never leave an empty service running
                if (!fg) stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun pi(action: String, code: Int): PendingIntent {
        val i = Intent(this, MediaPlayService::class.java).setAction(action)
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun post() {
        active = playing
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Video playback", NotificationManager.IMPORTANCE_LOW))
        }
        if (session == null) {
            session = MediaSession(this, "DoceraVideo").apply {
                setCallback(object : MediaSession.Callback() {
                    override fun onPlay() { sink?.invoke("play") }
                    override fun onPause() { sink?.invoke("pause") }
                    override fun onStop() { sink?.invoke("close"); shutdown() }
                    override fun onSkipToNext() { sink?.invoke("next") }
                    override fun onSkipToPrevious() { sink?.invoke("prev") }
                })
                // Bluetooth headset / car / watch buttons (play, pause, next, previous) reach this session
                @Suppress("DEPRECATION")
                setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
                isActive = true
            }
        }
        val s = session!!
        s.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title).build())
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f)
                .build()
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        b.setSmallIcon(if (playing) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause)
            .setContentTitle(if (title.isEmpty()) "Docera" else title)
            .setContentText(if (playing) "Playing" else "Paused")
            .setContentIntent(open)
            .setDeleteIntent(pi(A_CLOSE, 3))
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(playing)
            .setShowWhen(false)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
                    if (playing) "Pause" else "Play",
                    pi(A_TOGGLE, 1)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Remove",
                    pi(A_CLOSE, 2)
                ).build()
            )
            .setStyle(Notification.MediaStyle().setMediaSession(s.sessionToken).setShowActionsInCompactView(0, 1))
        val n = b.build()
        if (playing) {
            if (!fg) {
                try {
                    if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                    else startForeground(NOTIF_ID, n)
                    fg = true
                } catch (_: Throwable) {
                    nm.notify(NOTIF_ID, n)
                }
            } else nm.notify(NOTIF_ID, n)
            holdWake(true)
        } else {
            // paused: the notification can be swiped away (that removes the video)
            if (fg) {
                try { stopForeground(false) } catch (_: Throwable) {}
                fg = false
            }
            nm.notify(NOTIF_ID, n)
            holdWake(false)
        }
    }

    private fun holdWake(on: Boolean) {
        try {
            if (on) {
                if (wake == null) {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "docera:video")
                }
                if (wake?.isHeld == false) wake?.acquire(6 * 60 * 60 * 1000L)
            } else if (wake?.isHeld == true) wake?.release()
        } catch (_: Throwable) {
        }
    }

    private fun shutdown() {
        active = false
        holdWake(false)
        try { session?.isActive = false; session?.release() } catch (_: Throwable) {}
        session = null
        try { stopForeground(true) } catch (_: Throwable) {}
        fg = false
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID) } catch (_: Throwable) {}
        stopSelf()
    }

    override fun onDestroy() {
        active = false
        holdWake(false)
        try { session?.release() } catch (_: Throwable) {}
        session = null
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
