package com.docera.parwez

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.app.NotificationCompat

/**
 * Bluetooth earbud / headset shortcuts.
 * Earbud touch gestures reach the phone as media keys (play/pause, next, previous).
 * While this service runs, Docera holds an active media session, so those keys come here
 * and are turned into Docera actions (new note, scan, continue last PDF).
 * Nothing else in the app is touched; the service only exists while the Settings switch is on.
 */
class BtShortcutService : Service() {
    companion object {
        const val PREFS = "docera_bt"
        private const val CH = "docera_bt"
        private const val CH_OPEN = "docera_bt_open"
        private const val NID = 7421
        private const val NID_OPEN = 7422

        /** Settings page "Test" mode: key names are reported instead of running actions. */
        @Volatile var learn = false
        @Volatile var listener: ((String) -> Unit)? = null

        fun enabled(ctx: Context) = ctx.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("on", false)
        fun setEnabled(ctx: Context, on: Boolean) {
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", on).apply()
        }
        fun get(ctx: Context, key: String, def: String = "none"): String =
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, def) ?: def
        fun put(ctx: Context, key: String, v: String) {
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, v).apply()
        }

        fun start(ctx: Context) {
            try {
                val i = Intent(ctx, BtShortcutService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) {
            }
        }
        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, BtShortcutService::class.java)) } catch (_: Throwable) {}
        }
    }

    private var session: MediaSession? = null
    private val h = Handler(Looper.getMainLooper())
    private var pendingSingle: Runnable? = null
    private var lastPp = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showForeground()
        if (session == null) setupSession()
        return START_STICKY
    }

    override fun onDestroy() {
        try { pendingSingle?.let { h.removeCallbacks(it) } } catch (_: Throwable) {}
        try { session?.isActive = false; session?.release() } catch (_: Throwable) {}
        session = null
        super.onDestroy()
    }

    private fun setupSession() {
        try {
            val s = MediaSession(this, "DoceraBt")
            s.setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    val ev: KeyEvent? = if (Build.VERSION.SDK_INT >= 33)
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                    else @Suppress("DEPRECATION") mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                    if (ev == null) return false
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) onKey(ev.keyCode)
                    return true
                }
            })
            s.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS
                    )
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build()
            )
            s.isActive = true
            session = s
        } catch (_: Throwable) {
        }
    }

    private fun onKey(code: Int) {
        when (code) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK -> playPause()
            KeyEvent.KEYCODE_MEDIA_NEXT -> trigger("next", "k_next")
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> trigger("previous", "k_prev")
            else -> {}
        }
    }

    /** Single tap (play/pause) vs quick double tap are told apart by a 450 ms window. */
    private fun playPause() {
        val now = System.currentTimeMillis()
        val p = pendingSingle
        if (p != null && now - lastPp < 450) {
            h.removeCallbacks(p); pendingSingle = null
            trigger("play/pause x2", "k_double")
            return
        }
        lastPp = now
        val r = Runnable { pendingSingle = null; trigger("play/pause", "k_single") }
        pendingSingle = r
        h.postDelayed(r, 450)
    }

    private fun trigger(name: String, key: String) {
        try { listener?.invoke(name) } catch (_: Throwable) {}
        if (learn) return
        val act = get(this, key)
        if (act == "none" || act.isEmpty()) return
        val i = Intent(this, MainActivity::class.java)
            .setAction(Intent.ACTION_MAIN)
            .putExtra("wa", act)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val canStart = Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this) || MainActivity.visible
        var started = false
        if (canStart) {
            try { startActivity(i); started = true } catch (_: Throwable) {}
        }
        if (!started) tapToOpen(i, act)
    }

    /** Android may block opening an app from the background: then show a one-tap notification. */
    private fun tapToOpen(i: Intent, act: String) {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26)
                nm.createNotificationChannel(NotificationChannel(CH_OPEN, "Docera earbud shortcut", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(this, 5, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val label = when (act) { "note" -> "Write a note"; "scan" -> "Scan to PDF"; else -> "Continue last PDF" }
            val n = NotificationCompat.Builder(this, CH_OPEN)
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("Docera: $label")
                .setContentText("Tap to open")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setAutoCancel(true)
                .setTimeoutAfter(15000)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(NID_OPEN, n)
        } catch (_: Throwable) {
        }
    }

    private fun showForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(CH, "Earbud shortcuts", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(
            this, 4, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Docera earbud shortcuts are on")
            .setContentText("Your earbud taps can open a note, scan or last PDF.")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NID, n)
        } catch (_: Throwable) {
            try { startForeground(NID, n) } catch (_: Throwable) {}
        }
    }
}
